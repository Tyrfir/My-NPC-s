<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  *---------------------------------------------------------------*/
class Achievements extends Sql {
	// Vari�veis do Banco de Dados
	public $dbh = false;
	
	// Vari�veis de Conquistas
	public $achievements = array();
	public $achievements_count = 0;
	public $achievements_total = 0;
	
	// Vari�veis de Lista
	public $achievement_list = array();
	public $achievement_list_count = 0;
	
	// Vari�veis de Alvos
	public $targets = array();
	
	// Vari�veis de Recompensas
	public $rewards = array();
	
	// Vari�veis para nome de Classes
	public $JobNames = array();
	
	public function __construct() {
		$this->dbh = Sql::Connection();
		$this->JobNames = require(dirname(dirname(__FILE__))."\config\JobName.php");
		return;
	}
	
	public function Load($account_id, $key = null, $status = 2, $pstatus = 2, $type = null, $target_type = null, $target = null, $target_opt = '=', $target_value = null, $ghost = null, $init = null, $end = null)
	{	
		if( is_null($init) )
			$init = 0;
		
		if( $end == null )
			$end = Config::$max_rows;
		
		$bind = array();
		$sqlpartial = "";
		if( $status < 2 )
		{
			$sqlpartial .= " AND a.status=?";
			$bind[] = $status;
		}
		
		if( !is_null($type) )
		{
			$sqlpartial .= " AND a.type=?";
			$bind[] = $type;
		}
		
		if( !is_null($key) )
		{
			$sqlpartial .= " AND (a.name LIKE ? OR a.desc LIKE ?)";
			$bind[] = "%$key%";
			$bind[] = "%$key%";
		}
		
		// Filtros de Buscas por Alvos
		if( !is_null($target_type) )
		{
			$sqlpartial .= " AND ((SELECT COUNT(*) FROM achievement_req AS r WHERE r.achievement_id=a.id AND r.type=?";
			$bind[] = $target_type;
			
			if( !is_null($target) )
			{
				$sqlpartial .= " AND r.target=?";
				if( ($check_mob = $this->getmobid($target)) != 0 )
					$target = $check_mob;
				else if( ($check_item = $this->getitemid($target)) != 0 )
					$target = $check_item;
				else if( ($check_classid = $this->getclassid($target)) != 0 )
					$target = $check_classid;
				
				$bind[] = $target;
			}
			
			if( !is_null($target_value) )
			{
				$sqlpartial .= " AND r.value" . $target_opt ."?";
				$bind[] = $target_value;
			}
			
			$sqlpartial .= ") > 0)";
		}
		
		if( $pstatus == 1 )
		{
			$sqlpartial .= " AND ((SELECT COUNT(*) FROM achievement_data AS d WHERE d.account_id=? AND d.achievement_id=a.id AND d.status=1) > 0)";
			$bind[] = $account_id;
		}
		else if( $pstatus == 0 )
		{
			if( $ghost !== null && $ghost < 2 ) {
				$sqlpartial .= " AND a.ghost=?";
				$bind[] = $ghost;
			}
			
			$sqlpartial .= " AND ((SELECT COUNT(*) FROM achievement_data AS d WHERE d.account_id=? AND d.achievement_id=a.id AND d.status=0) > 0)";
			$bind[] = $account_id;
		}
		else {
			if( $ghost !== null && $ghost < 2 ) {
				$sqlpartial .= " AND a.ghost=?";
				$bind[] = $ghost;
			}
		}
		
		/* Conta o total da consulta */
		$sql = sprintf("SELECT COUNT(*) FROM achievement_db AS a WHERE 1=1 %s", $sqlpartial);
		$sth = $this->dbh->prepare($sql);
		$sth->execute($bind);
		$this->achievements_total = $sth->fetchColumn();
		
		/* Efetua a consulta e separa os valores */
		$sql = sprintf("SELECT a.id, a.name, a.desc, a.type, a.icon, a.cutin FROM achievement_db AS a WHERE 1=1 %s ORDER BY a.name LIMIT %d,%d", $sqlpartial, $init, $end);
		$sth = $this->dbh->prepare($sql);
		$sth->execute($bind);
		
		unset($this->achievements);
		while( $a = $sth->fetch() )
		{
			$id = $a[0];
			$this->achievements['id'][] = $id;
			$this->achievements['name'][] = $a[1];
			$this->achievements['desc'][] = $a[2];
			$this->achievements['type'][] = $a[3];
			$this->achievements['icon'][] = $a[4];
			$this->achievements['cutin'][] = $a[5];
			
			$sql = "SELECT d.date_time, d.status FROM achievement_data AS d WHERE d.account_id=? AND d.achievement_id=? LIMIT 1";
			$data = $this->dbh->prepare($sql);
			$data->execute(array($account_id, $id));
			
			$data_date = "";
			$data_status = -1;
			if( $data->rowCount() )
			{
				$d = $data->fetch();
				$data_date = $d[0];
				$data_status = $d[1];
			}
			
			$this->achievements['status'][] = $data_status;
			$this->achievements['date'][] = date('d/m/Y �\s H:i:s\h\r\s',strtotime($data_date));
			
			$sql = "SELECT r.type, r.target, r.value FROM achievement_req AS r WHERE r.achievement_id=? AND r.status=1";
			$bind = array($id);
			
			$targets = $this->dbh->prepare($sql);
			$targets->execute($bind);
			
			$count = 0;
			while( $r = $targets->fetch() ) {
				$this->targets[$id]['type'][] = $r[0];
				$this->targets[$id]['target'][] = $r[1];
				$this->targets[$id]['value'][] = $r[2];
				
				if( $data_status )
				{
					$this->targets[$id]['progress'][] = $r[2];
					$count++;
					continue;
				}
				
				$sql = "SELECT p.value FROM achievement_progress AS p WHERE p.account_id=? AND p.achievement_id=? AND p.type=? AND p.target=? LIMIT 1";
				$bind = array($account_id, $id, $r[0], $r[1]);
				$progress = $this->dbh->prepare($sql);
				$progress->execute($bind);
				
				if( !$progress->rowCount() )
					$this->targets[$id]['progress'][] = 0;
				else {
					$p = $progress->fetch();
					$this->targets[$id]['progress'][] = $p[0];
				}
				$count++;
			}
			$this->targets[$id]['count'] = $count;
			
			$rewards = $this->dbh->prepare("SELECT r.object, r.value, r.desc, r.type, r.rate FROM achievement_rewards AS r WHERE r.achievement_id=? AND r.status=1 ORDER BY r.type ASC, r.desc ASC, r.value ASC");
			$rewards->execute(array($id));
		
			$count = 0;
			while( $r = $rewards->fetch() ) {
				$this->rewards[$id]['object'][] = $r[0];
				$this->rewards[$id]['value'][] = $r[1];
				$this->rewards[$id]['desc'][] = $r[2];
				$this->rewards[$id]['type'][] = $r[3];
				$rate = $r[4] * Config::$reward_rate / 10000;
				if( $rate > 100 )
				{
					$this->rewards[$id]['rate'][] = 100;
					$this->rewards[$id]['rate_percent'][] = 100;
				}
				else {
					$this->rewards[$id]['rate'][] = $r[4];
					$this->rewards[$id]['rate_percent'][] = $rate;
				}
				$count++;
			}
			$this->rewards[$id]['count'] = $count;
			$this->achievements_count++;
		}
		return $this->achievements_total;
	}
	
	// Carrega conquistas sem estar vinculado a uma account_id.
	//
	public function LoadFromID($achievement_id, $status = null, $target_status = null, $reward_status = null, $account_id = null)
	{
		// NULL Values set Defaults.
		if( is_null($status) )
			$status = 2;
		if( is_null($target_status) )
			$target_status = 2;
		if( is_null($reward_status) )
			$reward_status = 2;
		
		$bind = array();
		$sqlpartial = "";
		if( $status < 2 )
		{
			$sqlpartial .= " AND a.status=?";
			$bind[] = $status;
		}
		
		if( !is_null($achievement_id) )
		{
			$sqlpartial .= "AND a.id=?";
			$bind[] = $achievement_id;
		}
		
		/* Conta o total da consulta */
		$sql = sprintf("SELECT COUNT(*) FROM achievement_db AS a WHERE 1=1 %s", $sqlpartial);
		$sth = $this->dbh->prepare($sql);
		$sth->execute($bind);
		$this->achievements_total = $sth->fetchColumn();
		
		/* Efetua a consulta e separa os valores */
		$sql = sprintf("SELECT a.id, a.name, a.desc, a.type, a.icon, a.cutin, a.status FROM achievement_db AS a WHERE 1=1 %s ORDER BY a.name LIMIT 1", $sqlpartial);
		$sth = $this->dbh->prepare($sql);
		$sth->execute($bind);
		
		unset($this->achievements);
		while( $a = $sth->fetch() )
		{
			$bind = array();
			$id = $a[0];
			$this->achievements['id'][] = $id;
			$this->achievements['name'][] = $a[1];
			$this->achievements['desc'][] = $a[2];
			$this->achievements['type'][] = $a[3];
			$this->achievements['icon'][] = $a[4];
			$this->achievements['cutin'][] = $a[5];
			$this->achievements['status'][] = $a[6];
			
			if( !is_null($account_id) )
			{
				$sql = "SELECT d.date_time, d.status FROM achievement_data AS d WHERE d.account_id=? AND d.achievement_id=? LIMIT 1";
				$data = $this->dbh->prepare($sql);
				$data->execute(array($account_id, $id));
				
				$data_date = "";
				$data_status = -1;
				if( $data->rowCount() )
				{
					$d = $data->fetch();
					$data_date = $d[0];
					$data_status = $d[1];
				}
				
				$this->achievements['status'][] = $data_status;
				$this->achievements['date'][] = date('d/m/Y �\s H:i:s\h\r\s',strtotime($data_date));
			}
			
			$sql = "SELECT r.id, r.type, r.target, r.value, r.status FROM achievement_req AS r WHERE r.achievement_id=?";
			$bind[] = $id;
			
			if( $target_status < 2 ) {
				$sql .= " AND r.status=?";
				$bind[] = $target_status;
			}
			
			$targets = $this->dbh->prepare($sql);
			$targets->execute($bind);
			
			$count = 0;
			while( $r = $targets->fetch() ) {
				$this->targets[$id]['id'][] = $r[0];
				$this->targets[$id]['type'][] = $r[1];
				$this->targets[$id]['target'][] = $r[2];
				$this->targets[$id]['value'][] = $r[3];
				$this->targets[$id]['status'][] = $r[4];
	
				if( !is_null($account_id) && $data_status )
				{
					$this->targets[$id]['progress'][] = $r[3];
					$count++;
					continue;
				}
				
				$sql = "SELECT p.value FROM achievement_progress AS p WHERE p.account_id=? AND p.achievement_id=? AND p.type=? AND p.target=? LIMIT 1";
				$bind = array($account_id, $id, $r[1], $r[2]);
				$progress = $this->dbh->prepare($sql);
				$progress->execute($bind);
				
				if( !$progress->rowCount() )
					$this->targets[$id]['progress'][] = 0;
				else {
					$p = $progress->fetch();
					$this->targets[$id]['progress'][] = $p[0];
				}
				
				$count++;
			}
			$this->targets[$id]['count'] = $count;
			
			$bind = array();
			
			$sql = "SELECT r.id, r.object, r.value, r.desc, r.type, r.rate, r.status FROM achievement_rewards AS r WHERE r.achievement_id=?";
			$bind[] = $id;
		
			if( $reward_status < 2 ) {
				$sql .= " AND r.status=?";
				$bind[] = $reward_status;
			}
				
			$sql .= " ORDER BY r.type ASC, r.desc ASC, r.value ASC";
			$rewards = $this->dbh->prepare($sql);
			$rewards->execute($bind);
		
			$count = 0;
			while( $r = $rewards->fetch() ) {
				$this->rewards[$id]['id'][] = $r[0];
				$this->rewards[$id]['object'][] = $r[1];
				$this->rewards[$id]['value'][] = $r[2];
				$this->rewards[$id]['desc'][] = $r[3];
				$this->rewards[$id]['type'][] = $r[4];
				$this->rewards[$id]['status'][] = $r[6];
				$rate = $r[5] * Config::$reward_rate / 10000;
				if( $rate > 100 )
				{
					$this->rewards[$id]['rate'][] = 100;
					$this->rewards[$id]['rate_percent'][] = 100;
				}
				else {
					$this->rewards[$id]['rate'][] = $r[5];
					$this->rewards[$id]['rate_percent'][] = $rate;
				}
				$count++;
			}
			$this->rewards[$id]['count'] = $count;
			$this->achievements_count++;
		}
		return $this->achievements_total;
	}
	
	// Cria uma lista com todas Conquistas
	//
	public function CreateList()
	{
		$sth = $this->dbh->prepare("SELECT COUNT(*) FROM achievement_db AS a ORDER BY a.name");
		
		if( !$sth->execute() )
		{
			$this->achievement_list = array();
			$this->achievement_list_count = 0;
			return 0;
		}
		
		$this->achievement_list_count = $sth->fetchColumn();
		
		$sth = $this->dbh->prepare("SELECT a.id, a.name FROM achievement_db AS a ORDER BY a.name");
		
		if( !$sth->execute() )
		{
			$this->achievement_list = array();
			$this->achievement_list_count = 0;
			return 0;
		}
		
		$this->achievement_list = array();
		while( $a = $sth->fetch() )
		{
			$this->achievement_list[] = array('id' => $a[0], 'name' => $a[1]);
		}		
		return $this->achievement_list_count;
	}
	
	// Adiciona uma nova Conquistas
	//
	public function Create($name, $icon, $desc, $type, $ghost = 0, $status = 0)
	{
		$sth = $this->dbh->prepare("INSERT INTO `achievement_db` (`name`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES (?, ?, ?, ?, ?, ?)");
		if( !$sth->execute(array($name, $icon, $desc, $type, $ghost, $status)) )
			return false;
		
		$lastId = $this->dbh->lastInsertId();
		$cutin = sprintf("%s%d",Config::$cutin_prefix,($lastId+1));
		
		$sth = $this->dbh->prepare("UPDATE `achievement_db` SET cutin=? WHERE id=?");
		if( !$sth->execute(array($cutin, $lastId)) )
			return false;
		
		return $lastId;
	}
	
	// Remove uma Conquista
	//
	public function Remove($achievement_id)
	{
		$errors = array();
		$sth = $this->dbh->prepare("DELETE FROM `achievement_db` WHERE `id`=?");
		if( !$sth->execute(array($achievement_id)) )
			$errors[] = 0;
		else {
			$sth = $this->dbh->prepare("UPDATE achievement_ranking a JOIN achievement_data b ON a.account_id=b.account_id AND b.status=1 AND b.achievement_id=? SET a.score=a.score-1");
			if( !$sth->execute(array($achievement_id)) )
				$errors[] = 1;
			
			$sth = $this->dbh->prepare("DELETE FROM `achievement_data` WHERE `achievement_id`=?");
			if( !$sth->execute(array($achievement_id)) )
				$errors[] = 2;
			
			$sth = $this->dbh->prepare("DELETE FROM `achievement_progress` WHERE `achievement_id`=?");
			if( !$sth->execute(array($achievement_id)) )
				$errors[] = 3;
			
			$sth = $this->dbh->prepare("DELETE FROM `achievement_req` WHERE `achievement_id`=?");
			if( !$sth->execute(array($achievement_id)) )
				$errors[] = 4;
			
			$sth = $this->dbh->prepare("DELETE FROM `achievement_rewards` WHERE `achievement_id`=?");
			if( !$sth->execute(array($achievement_id)) )
				$errors[] = 5;
		}
		return $errors;
	}
	
	// Editar Conquista
	//
	public function Update($achievement_id, $name, $icon, $desc, $type, $ghost = 0, $status = 0)
	{
		$sth = $this->dbh->prepare("UPDATE `achievement_db` SET `name`=?, `icon`=?, `desc`=?, `type`=?, `ghost`=?, `status`=? WHERE `id`=?");
		if( !$sth->execute(array($name, $icon, $desc, $type, $ghost, $status, $achievement_id)) )
			return false;
		
		return true;
	}
	
	// Atualiza ou adiciona um novo alvo.
	//
	//	Return array(code, id);
	//
	public function AddTarget($achievement_id, $type, $target, $value, $status = 0)
	{
		$sth = $this->dbh->prepare("SELECT id FROM achievement_req WHERE achievement_id=? AND type=? AND target=? LIMIT 1");
		$sth->execute(array($achievement_id, $type, $target));
		
		if( $sth->rowCount() )
		{
			$update_id = $sth->fetch();
			$sth = $this->dbh->prepare("UPDATE achievement_req SET value=?, status=? WHERE achievement_id=? AND type=? AND target=?");
			return array(($sth->execute(array($value, $status, $achievement_id, $type, $target)) ? 2 : 0), $update_id[0]);
		}
		
		$sth = $this->dbh->prepare("INSERT INTO achievement_req (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (?, ?, ?, ?, ?)");
		if( $sth->execute(array($achievement_id, $type, $target, $value, $status)) )
		{
			$lastId = $this->dbh->lastInsertId();
			return array(3,$lastId);
		}
		return array(1,0);
	}
	
	// Remover Alvo de uma determinada conquista.
	//
	public function RemoveTarget($id)
	{
		$sth = $this->dbh->prepare("DELETE FROM achievement_req WHERE id=?");
		return $sth->execute(array($id)) ? true : false;
	}
	
	// Altera o Status de um determinado Alvo.
	public function ChangeTargetStatus($id, $status)
	{
		$sth = $this->dbh->prepare("UPDATE achievement_req SET status=? WHERE id=?");
		return $sth->execute(array($status, $id)) ? true : false;
	}
	
	// Adiciona uma recompensa.
	public function AddReward($achievement_id, $object, $value, $type, $rate, $desc, $status = 1)
	{
		$sth = $this->dbh->prepare("INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `rate`, `desc`, `status`) VALUES (?, ?, ?, ?, ?, ?, ?)");
		if( !$sth->execute(array($achievement_id, $object, $value, $type, $rate, $desc, $status)) )
			return false;
		
		$lastId = $this->dbh->lastInsertId();
		return $lastId;
	}
	
	// Remove uma recompensa.
	public function RemoveReward($id)
	{
		$sth = $this->dbh->prepare("DELETE FROM achievement_rewards WHERE id=?");
		return $sth->execute(array($id)) ? true : false;
	}
	
	// Altera a situa��o de uma recompensa.
	public function ChangeRewardStatus($id, $status)
	{
		$sth = $this->dbh->prepare("UPDATE achievement_rewards SET status=? WHERE id=?");
		return $sth->execute(array($status, $id)) ? true : false;
	}
	
	// Retorna com nome do item no item_db ou item_db2.
	//
	public function getitemname($item_id) {
		$sth = $this->dbh->prepare("SELECT name_japanese FROM item_db WHERE id=? LIMIT 1");
		$sth->execute(array($item_id));
		
		if( $sth->rowCount() )
		{
			$row = $sth->fetch();
			return $row[0];
		}
		
		$sth = $this->dbh->prepare("SELECT name_japanese FROM item_db2 WHERE id=? LIMIT 1");
		$sth->execute(array($item_id));
		
		if( $sth->rowCount() )
		{
			$row = $sth->fetch();
			return $row[0];
		}
		return;
	}
	
	// Retorna com nome do monstro no mob_db ou mob_db2.
	//
	public function getmobname($mob_id) {
		$sth = $this->dbh->prepare("SELECT iName FROM mob_db WHERE id=? LIMIT 1");
		$sth->execute(array($mob_id));
		
		if( $sth->rowCount() )
		{
			$row = $sth->fetch();
			return $row[0];
		}
		
		$sth = $this->dbh->prepare("SELECT iName FROM mob_db2 WHERE id=? LIMIT 1");
		$sth->execute(array($item_id));
		
		if( $sth->rowCount() )
		{
			$row = $sth->fetch();
			return $row[0];
		}
		return "Monstro ({$mob_id}) Desconhecido";
	}
	
	// Retorna com nome do mapa no achievement_mapname.
	//
	public function getmapname($map) {
		$sth = $this->dbh->prepare("SELECT name FROM achievement_mapname WHERE map=? LIMIT 1");
		$sth->execute(array($map));
		
		if( $sth->rowCount() )
		{
			$row = $sth->fetch();
			return $row[0];
		}
		
		return "Mapa ({$map}) Desconhecido";
	}
	
	// Pega o ID do Monstro pelo nome ou mesmo ID.
	//
	public function getmobid($search) {
		$sth = $this->dbh->prepare("SELECT ID FROM mob_db WHERE ID=? OR iName=? LIMIT 1");
		$sth->execute(array($search, $search));
		
		if( $sth->rowCount() )
		{
			$row = $sth->fetch();
			return $row[0];
		}
		
		$sth = $this->dbh->prepare("SELECT ID FROM mob_db2 WHERE ID=? OR iName=? LIMIT 1");
		$sth->execute(array($search, $search));
		
		if( $sth->rowCount() )
		{
			$row = $sth->fetch();
			return $row[0];
		}
		
		return false;
	}
	
	// Pega o ID do Item pelo nome ou mesmo ID.
	//
	public function getitemid($search) {
		$sth = $this->dbh->prepare("SELECT id FROM item_db WHERE id=? OR name_japanese=? LIMIT 1");
		$sth->execute(array($search, $search));
		
		if( $sth->rowCount() )
		{
			$row = $sth->fetch();
			return $row[0];
		}
		
		$sth = $this->dbh->prepare("SELECT id FROM item_db2 WHERE id=? OR name_japanese=? LIMIT 1");
		$sth->execute(array($search, $search));
		
		if( $sth->rowCount() )
		{
			$row = $sth->fetch();
			return $row[0];
		}
		
		return false;
	}
	
	// Pega o ID da Classe pelo nome ou mesmo ID.
	//
	public function getclassid($search) {
		if( isset($this->JobNames[$search]) )
			return $search;
		
		$key = array_search($search, $this->JobNames);
		
		if( is_null($key) )
			return false;
		
		return $key;
	}
	
	// Pega o mapa por seu nome ou descri��o.
	//
	public function getmapgat($search) {
		
		$sth = $this->dbh->prepare("SELECT map FROM achievement_mapname WHERE map=? OR name=? LIMIT 1");
		$sth->execute(array($search, $search));
		
		if( $sth->rowCount() )
		{
			$row = $sth->fetch();
			return $row[0];
		}
		return false;
	}
	
	// Pega uma conquista pelo seu nome ou id.
	//
	public function getachievementid($search)
	{
		$sth = $this->dbh->prepare("SELECT id FROM achievement_db WHERE id=? OR name=? LIMIT 1");
		$sth->execute(array($search, $search));
		
		if( $sth->rowCount() )
		{
			$row = $sth->fetch();
			return $row[0];
		}
		return false;
	}
	
	// Pega uma informa��o de uma determinada conquista
	//
	public function getInfo($achievement_id, $info)
	{
		$sql = sprintf("SELECT %s FROM achievement_db WHERE id=?", $info);
		$sth = $this->dbh->prepare($sql);
		$sth->execute(array($achievement_id));
		
		if( $sth->rowCount() )
		{
			$row = $sth->fetch();
			return $row[0];
		}
		return false;
	}
	
	// Destr�i a conex�o com o banco de dados.
	public function __destruct() {
		$this->dbh = null;
	}
}
?>