<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  *---------------------------------------------------------------*/
class Sql extends Config {
	public static $connection = false;
	
	public static function Connection() {
		try {
			$cc = sprintf("mysql:host=%s;dbname=%s", Config::$sqlServer['host'], Config::$sqlServer['base']);
			Sql::$connection = new PDO($cc, Config::$sqlServer['user'], Config::$sqlServer['pass']);
			Sql::$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			return Sql::$connection;
		} catch( PDOException $e ) {
			die('<style>body { background:#fff !important; }</style> <div class="container margin-15x-top"><div class="alert alert-danger"> <a href="#" class="close" data-dismiss="alert" aria-label="close" onClick="location.reload();">&times;</a><strong>Erro!</strong> <p>N�o foi poss�vel conectar com o banco de dados, reporte aos Desenvolvedores.</p><p>' . $e->getMessage() . '</div></div>');
		}
	}
	
	// Destr�i a conex�o com o banco de dados.
	public function __destruct() {
		Sql::$connection = null;
	}
}
?>