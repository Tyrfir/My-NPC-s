<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                       Sistema de Perfil                       .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 1.0  .
  *---------------------------------------------------------------*/
class Profile extends Sql {
	// Vari�veis do Banco de Dados
	public $dbh = false;
	
	public $name, $firstname, $lastname, $nickname, $sex, $age, $birthdate, $country, $state = null;
	public $email, $skype, $facebook, $youtube, $googleplus, $twitter, $linkedin, $instagram = null;
	public $rank, $progress, $total_db, $total, $avatar_url, $description = null;
	
	public $last_achievements = array();
	
	public function __construct() {
		$this->dbh = Sql::Connection();
		return;
	}
	
	public function Defaults() {
		$this->name = $this->firstname = $this->lastname = $this->nickname = $this->sex = $this->age = $this->birthdate = $this->country = $this->state = null;
		$this->email = $this->skype = $this->facebook = $this->youtube = $this->googleplus = $this->twitter = $this->linkedin = $this->instagram = null;
		$this->rank = $this->progress = $this->total_db = $this->total = $this->avatar_url = $this->description = null;
		$this->last_achievements = array();
	}

	// Requisita Informa��es do Perfil.
	//
	public function RequestData($account_id)
	{
		$this->Defaults();
		$sth = $this->dbh->prepare("SELECT `nickname`, `name`, `sex`, `birthdate`, `country`, `state`, `email`, `skype`, `facebook`, `twitter`, `googleplus`, `instagram`, `linkedin`, `youtube`, `avatar`, `description` FROM `creativesd_profile` WHERE `account_id`=? LIMIT 1");
		if( $sth->execute(array($account_id)) && $sth->rowCount() > 0 )
		{
			$request = $sth->fetch();
			
			// Obt�m o Nickname e Nome
			$this->nickname = $request[0];
			$this->name = $request[1];
			
			// Formata o Nome e Sobrenome
			$name = explode(" ",$request[1]);
			$this->firstname = $name[0];
			for( $i=1; $i < count($name); $i++ )
				$this->lastname .= $name[$i]. " ";
			
			// Obt�m o Sexo
			$this->sex = $request[2];
			
			// Cria o Formato da Data de anivers�rio.
			$date = date_create($request[3]);
			$this->birthdate = date_format($date, "d.m.Y");
			
			// Criando Idade
			$year = date("Y");
			$month = date("m");
			$day = date("d");
			$birthdate_format = explode(".", $this->birthdate);
			$this->age = $year-$birthdate_format[2];
			
			// Corre��o
			if( ($day < $birthdate_format[0] && $month <= $birthdate_format[1]) || $month < $birthdate_format[1] )
				$this->age--;
			
			// Obt�m Regi�o
			$this->country = $request[4];
			$this->state = $request[5];
			
			// Obt�m Contatos e Rede Sociais
			$this->email = $request[6];
			$this->skype = $request[7];
			$this->facebook = $request[8];
			$this->twitter = $request[9];
			$this->googleplus = $request[10];
			$this->instagram = $request[11];
			$this->linkedin = $request[12];
			$this->youtube = $request[13];
			
			// Obt�m Avatar e Descri��es
			$this->avatar_url = $request[14];
			$this->description = $request[15];
		}
		
		// Caso n�o haja informa��es necess�ria ele tenta criar um Perfil tempor�rio com informa��es da conta do jogador!
		if( !$this->nickname )
		{
			$sth = $this->dbh->prepare("SELECT `name`FROM `char` WHERE `account_id`=? ORDER BY `char_id` LIMIT 1");
			if( $sth->execute(array($account_id)) && $sth->rowCount() > 0 )
			{
				$request = $sth->fetch();
				$this->nickname = $request[0];
			}
		}
		
		if( $this->sex === null || $this->email === null || $this->birthdate === null )
		{
			$sth = $this->dbh->prepare("SELECT `sex`, `email`, `birthdate` FROM `login` WHERE `account_id`=? LIMIT 1");
			if( $sth->execute(array($account_id)) && $sth->rowCount() > 0 )
			{
				$request = $sth->fetch();
				if( $this->sex === null )
					$this->sex = $request[0]=='M'?0:1;
				
				if( $this->email === null )
					$this->email = $request[1];
				
				if( $this->birthdate === null && $request[2] != "0000-00-00" )
				{
					$date = date_create($request[2]);
					$this->birthdate = date_format($date, "d.m.Y");
					$year = date_format($date, "Y");
					$this->age = date("Y")-$year;
				}
			}
		}
		
		// Obt�m todas as conquistas para calcular o progresso do perfil.
		$total_achievements_db = 0;
		$total_achievements = 0;
		$sth = $this->dbh->prepare("SELECT COUNT(*) FROM `achievement_db` WHERE `status`='1'");
		if( $sth->execute() && $sth->rowCount() > 0 )
		{
			$request = $sth->fetch();
			$total_achievements_db = $request[0];
		}
		
		$sth = $this->dbh->prepare("SELECT COUNT(*) FROM `achievement_data` WHERE `account_id`=? AND `status`='1'");
		if( $sth->execute(array($account_id)) && $sth->rowCount() > 0 )
		{
			$request = $sth->fetch();
			$total_achievements = $request[0];
		}
		
		if( $total_achievements > $total_achievements_db )
			$total_achievements = $total_achievements_db;
		
		$this->progress = round(($total_achievements*100) / $total_achievements_db);
		$this->total_db = $total_achievements_db;
		$this->total = $total_achievements;
		
		$sth = $this->dbh->prepare("SELECT `score`, `lastupdate` FROM `achievement_ranking` WHERE `account_id`=? LIMIT 1");
		
		$score = null;
		if( $sth->execute(array($account_id)) && $sth->rowCount() > 0 )
		{
			$request = $sth->fetch();
			$myscore = $request[0];
			$lastupdate = $request[1];
			
			$sth = $this->dbh->prepare("SELECT COUNT(*) FROM `achievement_ranking` WHERE `account_id`!=? AND ((`score`>=? AND `lastupdate`<?) OR (`score`>?))");
			if( $sth->execute(array($account_id,$myscore,$lastupdate,$myscore)) && $sth->rowCount() > 0 )
			{
				$request = $sth->fetch();
				$score = $request[0]+1;
			}
		}
		
		if( $score !== null )
			$this->rank = $score;
		
		$sql = sprintf("SELECT `a`.`achievement_id`, `a`.`date_time`, `b`.`name`, `b`.`icon` FROM `achievement_data` AS a, `achievement_db` AS b WHERE `a`.`account_id`=? AND `a`.`status`='1' AND `a`.`achievement_id`=`b`.`id` ORDER BY `a`.`date_time` DESC");
		$sth = $this->dbh->prepare($sql);
		if( $sth->execute(array($account_id)) && $sth->rowCount() > 0  )
			$this->last_achievements = $sth->fetchall();
		
		return true;
	}
	
	// Checagem de duplicatas.
	//
	//	<type>
	//		0: Nome
	//		1: Nickname
	//		2: E-mail
	//		3: Skype
	//		4: Facebook
	//		5: Twitter
	//		6: Google+
	//		7: Instagram
	//		8: Linkedin
	//		9: Youtube
	//
	public function CheckDuplicate($account_id, $type = 0, $value)
	{
		$columns = array('name', 'nickname', 'email', 'skype', 'facebook', 'twitter', 'googleplus', 'instagram', 'linkedin', 'youtube');
		$sql = sprintf("SELECT `account_id` FROM `creativesd_profile` WHERE `%s`=? LIMIT 1", $columns[$type]);
		$sth = $this->dbh->prepare($sql);
		if( $sth->execute(array($value)) && $sth->rowCount() > 0 )
		{
			$request = $sth->fetch();
			if( $request[0] != $account_id )
				return true;
		}
		return false;
	}
	
	// Cria um Perfil.
	//
	public function Create($account_id, $nickname, $name, $sex, $birthdate, $country = null, $state = null, $socials = array(), $email, $avatar = null, $description = null)
	{
		$bindcolumns = array('account_id', 'nickname', 'name', 'sex', 'birthdate');
		$bind = array($account_id, $nickname, $name, $sex, $birthdate);
		
		
		if( $country !== null ) {
			$bindcolumns[] = 'country';
			$bind[] = $country;
		}
		
		if( $state !== null ) {
			$bindcolumns[] = '`state`';
			$bind[] = $state;
		}
		
		if( count($socials) )
		{
			foreach( $socials as $table => $value ) {
				if( $value === null )
					continue;
				
				$bindcolumns[] = $table;
				$bind[] = $value;
			}
		}
		
		if( $email !== null ) {
			$bindcolumns[] = 'email';
			$bind[] = $email;
		}
		
		if( $avatar !== null ) {
			$bindcolumns[] = 'avatar';
			$bind[] = $avatar;
		}
		
		if( $description !== null ) {
			$bindcolumns[] = 'description';
			$bind[] = $description;
		}
		
		$args = array();
		for( $i=0; $i < count($bindcolumns); $i++ )
			$args[] = "?";
		
		$bindcolumn = implode(", ", $bindcolumns);
		$bindarguments = implode(", ", $args);
		
		$sql = sprintf("REPLACE INTO `creativesd_profile` (%s) VALUES (%s)", $bindcolumn, $bindarguments); 
		$sth = $this->dbh->prepare($sql);
		return $sth->execute($bind) ? true : false;
	}
	
	// Pega informa��o de um determinado perfil.
	//
	public function getInfo($account_id, $info)
	{
		$sql = sprintf("SELECT `%s` FROM `creativesd_profile` WHERE `account_id`=? LIMIT 1", $info);
		$sth = $this->dbh->prepare($sql);
		if( $sth->execute(array($account_id)) && $sth->rowCount() > 0 )
		{
			$request = $sth->fetch();
			return $request[0];
		}
		return null;
	}
	
	// Destr�i a conex�o com o banco de dados.
	public function __destruct() {
		$this->dbh = null;
	}
}
?>