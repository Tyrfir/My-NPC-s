<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  *---------------------------------------------------------------*/
class Client extends Sql {
	// Vari�veis do Banco de Dados
	public $dbh = false;
	
	// Informa��es da Sess�o
	public $account_id = null;
	public $group_id = 0;
	
	public $AcessLevel = array();
	
	public function __construct() {
		$this->dbh = Sql::Connection();
		$this->AccessLevel = require(dirname(dirname(__FILE__))."\config\AccessLevel.php");
		return;
	}
	
	// Criar uma sess�o do Client.
	//
	public function RegisteSession($account_id)
	{
		$sql = sprintf("SELECT %s FROM login WHERE account_id=? LIMIT 1", Config::$groups['column']);
		$sth = $this->dbh->prepare($sql);
		$sth->execute(array($account_id));
		
		if( $sth->rowCount() <= 0 )
			return false;
		
		$login = $sth->fetch();
		$_SESSION['client_account_id'] = $this->account_id = $account_id;
		$_SESSION['client_group_id'] = $this->group_id = $login[0];
		return true;
	}
	
	// Checa se o usu�rio est� conectado.
	//
	public function CheckSession()
	{
		return isset($_SESSION['client_account_id']) ? true : false;
	}
	
	// Checa se a sess�o est� autorizada a acessar uma determinada a��o.
	// @require AccessLevel Cfg.
	public function CheckAccess($type)
	{
		if( !isset($this->AccessLevel[$type]) )
			return true;

		if( !$this->CheckSession() )
			return false;
		
		if( $this->group_id < $this->AccessLevel[$type] )
			return false;
		
		return true;
	}
	
	// Checa se uma conta existe.
	//
	public function CheckExist($account_id)
	{
		$sth = $this->dbh->prepare("SELECT COUNT(*) FROM login WHERE account_id=?");
		if( !$sth->execute(array($account_id)) )
			return false;
		
		$check = $sth->fetchColumn();
		return $check ? true : false;
	}
	
	// Destr�i a conex�o com o banco de dados.
	public function __destruct() {
		$this->dbh = null;
	}
}
?>