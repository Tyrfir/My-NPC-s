<?php
	if( !defined("CLIENT_PAGE") )
		exit;
	
	// Paginator
	$paginator = !isset($_GET['page']) || $_GET['page'] == 0 ? 1 : $_GET['page'];
	
	// Search
	$key = (isset($_GET['key'])&&trim($_GET['key'])?$_GET['key']:null);
	$type = (isset($_GET['type'])&&is_numeric($_GET['type'])?$_GET['type']:null);
	$status = (isset($_GET['status'])&&is_numeric($_GET['status'])?$_GET['status']:1);
	
	// Binds Search
	$target_value = null;
	$target_opt = null;
	$target_type = (isset($_GET['target_type'])&&is_numeric($_GET['target_type'])?$_GET['target_type']:null);
	$target_ref = (isset($_GET['target'])&&!empty($_GET['target'])?$_GET['target']:null);
	
	if( !is_null($target_type) )
	{
		if( in_array("amount",$TargetOptions[$target_type])
			&& isset($_GET['amount']) && (int)$_GET['amount'] > 0 
		)
		{
			$target_value = $_GET['amount']>0?$_GET['amount']:null;
		}
		
		if(
			(in_array("target",$TargetOptions[$target_type])
				&& isset($_GET['target'])
				&& !empty($_GET['target']) )
			|| (in_array("timer",$TargetOptions[$target_type])
				&& isset($_GET['target']) && trim($target) )
			|| (in_array("hour",$TargetOptions[$target_type])
				&& isset($_GET['target']) && trim($target) )
		)
		{
			$target_ref = $_GET['target'];
		}
	}
	
	$ghost = $Client->CheckAccess('ACH_VIEW_GHOST')?2:0;
	$init = ($paginator-1)*Config::$max_rows;
	$vstatus = $Client->CheckAccess('ACH_VIEW_DISABLE')?2:1;
	$Ach->Load($account_id,$key,$vstatus,$status,$type,$target_type,$target_ref,$target_opt,$target_value,$ghost,$init);
?>
		<form class="search-bar" action="?p=list" method="get">
			<label>Busca:</label>
			<div class="clear"></div>
		    <input type="hidden" name="account_id" id="account_id" value="<?php echo $account_id; ?>">
			<input type="hidden" name="pass" id="pass" value="<?php echo $pass; ?>">
			<input type="text" name="key" id="key" value="<?php echo $key?>">
			<select name="type" id="type">
				<option value="">Qualquer</option>
		<?php
			foreach( $CategoryList as $value => $name) {
		?>
				<option value="<?php echo $value; ?>"<?php if( !is_null($type) && $type == $value ) { echo "selected"; } ?>><?php echo $name; ?></option>
		<?php
			}
		?>
			</select>
			<select name="status" id="status">
				<option value="2"<?php if( $status == 2 ) { echo "selected"; } ?>>Todas Conquistas</option>
				<option value="0"<?php if( $status == 1 ) { echo "selected"; } ?>>Em progresso</option>
				<option value="1">Conquistadas</option>
			</select>
			<button type="submit" class="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
			<div class="clear"></div>
			<a href="?account_id=<?php echo $account_id ?>&pass=<?php echo $_GET['pass']; ?>&p=advanced-search&key=<?php echo $key ?>&type=<?php echo $type ?>&target_type=<?php echo $target_type ?>&target=<?php echo $target_ref ?>&target_value<?php echo $target_value ?>&status=<?php echo $status ?>&backurl=<?php echo $back_url ?>" class="pull-right">Busca avan�ada</a>
		</form>
<?php
	if( $Ach->achievements_count )
	{
?>
		<div class="content">
<?php
		for( $i=0, $a = 0; $i < $Ach->achievements_count; $i++ )
		{
			// Preparando Exibi��o da Conquista no Painel.
			$achievement_id = $Ach->achievements['id'][$i];
			$achievement_type = $Ach->achievements['type'][$i];
			$data_status = $Ach->achievements['status'][$i];
			$date = $Ach->achievements['date'][$i];
							
			$icon = $Ach->achievements['icon'][$i];
				
			if( file_exists("../images/icons/{$icon}.png") )
				$img = "../images/icons/{$icon}.png";
			else if( file_exists("../images/icons/{$icon}.gif") )
				$img = "../images/icons/{$icon}.gif";
			else
				$img = "../images/null.png";
					
			$rewards = "";
			$targets = "";
?>
			<div class="row">
				<div class="col-xs-12">
					<div class="table-conquest">
						<div class="base-top"><?php echo $Ach->achievements['name'][$i]; ?></div>
						<div class="base-image"><img src="<?php echo $img; ?>" /></div>
						<div class="base-desc"><?php echo $Ach->achievements['desc'][$i]; ?></div>
						<div class="base-bottom">
						<?php if( Config::$show_rewards || $data_status > -1 ) { ?>
							<a href="?account_id=<?php echo $account_id ?>&pass=<?php echo $_GET['pass']; ?>&p=view-reward&achievement_id=<?php echo $achievement_id; ?>&backurl=<?php echo $back_url ?>" >Recompensas</a>
						<?php } ?>
						<?php if( Config::$show_objetive || $data_status > -1 ) { ?>
							<a href="?account_id=<?php echo $account_id ?>&pass=<?php echo $_GET['pass']; ?>&p=view-progress&achievement_id=<?php echo $achievement_id; ?>&backurl=<?php echo $back_url ?>" class="pull-right"><?php echo $data_status>=0?"Completada em: <span class=\"reset-color\">{$date}</span>":"Progresso"; ?></a>
						<?php } ?>
						</div>
					</div>
				</div>
			</div>
<?php
		}
?>
		</div>
<?php

		// CreateNavBar
		if( $Ach->achievements_total > Config::$max_rows ) {
?>
		<div class="navbar">
<?php
			$Tpl->createNavBar($paginator,$Ach->achievements_total,Config::$max_rows,$_GET);
			$Tpl->showNavigation();
?>
		</div>
<?php
		}
	}
	else {
		$help_rand = rand(1,6);
?>
	<div class="page-error-main">
		<strong>Ooops!</strong>
		<p>Nada encontrado, reformule sua busca...</p>
		<?php if( isset($_GET['backurl']) && trim($_GET['backurl']) ) { ?>
		<p class="back-url"><a href="<?php echo urldecode($_GET['backurl']) ?>" class="pull-left"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Voltar</p>
		<?php } ?>
		<div class="alert-icon-help-<?php echo $help_rand; ?>"></div>
	</div>
<?php
	}
?>