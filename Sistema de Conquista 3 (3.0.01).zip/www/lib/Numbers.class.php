<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  *---------------------------------------------------------------*/
class Numbers {
	// Converte tempos em dias, horas e minutos.
	public static function calc_timer($timer)
	{
		$days = intval($timer/1440);
		$timer -= $days * 1440;
		$hour = intval($timer/60);
		$timer -= $hour*60;
		$minute = $timer;
		
		// Formatando
		if( $days && $hour && $minute )
			return sprintf("%d dia(s), %02d hora(s) e %02d minuto(s)", $days, $hour, $minute);
		else if( $days && $minute )
			return sprintf("%d dia(s) e %02d minuto(s)", $days, $minute);
		else if( $days && $hour )
			return sprintf("%d dia(s) e %02d hora(s)", $days, $hour);
		else if( $days )
			return sprintf("%d dia(s)", $days, $hour, $minute);
		else if( $minute && $hour )
			return sprintf("%02d hora(s) e %02d minuto(s)", $hour, $minute);
		else if( $hour )
			return sprintf("%02d hora(s)", $hour);
		else
			return sprintf("%02d minuto(s)", $minute);
	}
	
	// Converte tempos em dias, horas e minutos, segundos.
	public static function calc_timer_sec($timer)
	{
		$days = intval($timer/86400);
		$timer -= $days * 86400;
		$hour = intval($timer/3600);
		$timer -= $hour*3600;
		$minute = intval($timer/60);
		$timer -= $minute*60;
		$second = $timer;
		
		// Formatando
		if( $days && $hour && $minute && $second )
			return sprintf("%d dia(s), %02d hora(s), %02d minuto(s) e %02d segundo(s)", $days, $hour, $minute, $second);
		
		else if( $days && $hour && $minute )
			return sprintf("%d dia(s), %02d hora(s) e %02d minuto(s)", $days, $hour, $minute);
		else if( $days && $hour && $second )
			return sprintf("%d dia(s), %02d hora(s) e %02d segundo(s)", $days, $hour, $second);
		else if( $days && $minute && $second )
			return sprintf("%d dia(s), %02d minuto(s) e %02d segundo(s)", $days, $minute, $second);
		else if( $days && $minute )
			return sprintf("%d dia(s) e %02d minuto(s)", $days, $minute);
		else if( $days && $hour )
			return sprintf("%d dia(s) e %02d hora(s)", $days, $hour);
		else if( $days && $second )
			return sprintf("%d dia(s) e %02d segundo(s)", $days, $second);
		else if( $days )
			return sprintf("%d dia(s)", $days, $hour, $minute);
		else if( $hour && $minute && $second )
			return sprintf("%02d hora(s), %02d minto(s) e %02d segundo(s)", $hour, $minute, $second);
		else if( $hour && $second )
			return sprintf("%02d hora(s) e %02d segundo(s)", $hour, $second);
		else if( $minute && $second )
			return sprintf("%02d minuto(s) e %02d segundo(s)", $minute, $second);
		else if( $minute && $hour )
			return sprintf("%02d hora(s) e %02d minuto(s)", $hour, $minute);
		else if( $hour )
			return sprintf("%02d hora(s)", $hour);
		else if( $minute )
			return sprintf("%02d minuto(s)", $minute);
		else
			return sprintf("%02d segundo(s)", $minute);
	}
	
	// Formata��o de Quantidade
	public static function format_amount($string)
	{
		$string = (string)$string;
		for( $i=(strlen($string)-1), $newstr = "", $count=0; $i >= 0; $i-- )
		{	
			if( $count == 3 )
			{
				$newstr = "." . $newstr;
				$count=0;
			}
			
			$newstr = $string{$i} . $newstr;
			$count++;
		}
		
		return $newstr;
	}
}
?>