<?php
namespace App\ROChargen\db;


return array(
	false,            // none
	array( "name" => "õ�糯��",       "size" => "big"   ), // robe wings
	array( "name" => "���谡�賶",     "size" => "small" ), // bag of adventurer
	array( "name" => "Ÿ��õ���ǳ���", "size" => "big"   )  // robe wings of fallen angel
);
