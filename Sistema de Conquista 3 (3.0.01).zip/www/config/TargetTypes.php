<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  *---------------------------------------------------------------*/
// As categorias s�o ordenada de acordo como a lista.
return array(
		 0 => 'Jogador',
		 1 => 'Jogador de outro Cl�',
		 2 => 'Jogador de outro Ex�rcito',
		 3 => 'Vencer Batalhas Campais',
		 4 => 'Destruir o Emperium',
		 5 => 'Ajuntar quantia de Zeny',
		 6 => 'Gastar uma quantia de Zeny',
		 7 => 'Gastar uma quantia de Zeny de uma �nica vez',
		18 => 'Ganhar uma quantia de Zeny de uma �nica vez',
		 8 => 'Construir Runas Guardi�s',
		 9 => 'Construir Barricadas',
		49 => 'Destruir uma Barricada',
		50 => 'Destruir uma Runa Guardi�',
		10 => 'Aguardar um determinado tempo',
		11 => 'Visitar um mapa',
		12 => 'Eliminar monstro',
		13 => 'Pegar um determinado item de um monstro',
		14 => 'Pegar um item de um determinado monstro',
		15 => 'Estar em um determinado mapa',
		16 => 'Eliminar qualquer MvP',
		17 => 'Estar presente em um determinado hor�rio',
		// 18 moved
		19 => 'N�vel de Base',
		20 => 'N�vel de Classe',
		21 => 'N�vel de Base ou Classe',
		22 => 'Estar em uma determinada Classe',
		23 => 'Torna-se um Classe',
		24 => 'O alvo deve estar em uma determinada Classe',
		25 => 'Utilizar um Item',
		26 => 'Comprar um determinado item em NPCs',
		27 => 'Comprar um determinado item em Vendas de Jogadores',
		28 => 'Comprar um determinado item em NPCs ou Vendas de Jogadores',
		29 => 'Comprar qualquer item no NPCs',
		30 => 'Comprar qualquer item em Vendas de Jogadores',
		31 => 'Comprar qualquer item em Vendas de Jogadores ou NPC',
		32 => 'Vender um determinado item em NPCs',
		33 => 'Vender um determinado item para Jogadores',
		34 => 'Vender um determinado item para Jogadores ou NPCs',
		35 => 'Vender qualquer item em NPCs',
		36 => 'Vender qualquer item em Vendas de Jogadores',
		37 => 'Vender qualquer item em Vendas de Jogadores ou NPCs',
		38 => 'Pegar um determinado item em Trocas',
		39 => 'Dar um determinado item em Trocas',
		40 => 'Pegar ou Dar um determinado item em Trocas',
		41 => 'Pegar qualquer item em Trocas',
		42 => 'Dar qualquer item em Trocas',
		43 => 'Pegar ou Dar qualquer item em Trocas',
		44 => 'Pegar uma determinada quantia de Zeny em Trocas',
		45 => 'Dar uma determinada quantia de Zeny em Trocas',
		46 => 'Pegar uma determinada quantia de Zeny em Trocas de uma �nica vez',
		47 => 'Dar uma determinada quantia de Zeny em Trocas de uma �nica vez',
		48 => 'Refinar um determinado item',
		// 48~50 moved
		51 => 'Terminar a conquista em um determinado tempo',
		52 => 'Completar uma determinada Conquista'
);