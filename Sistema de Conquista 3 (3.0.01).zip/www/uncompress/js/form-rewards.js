/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  .---------------------------------------------------------------.
  .          Formul�rios de Gerenciamento de Recompensas          .
  *---------------------------------------------------------------*/
$(document).ready(function(){
	$chk_submit_send = false;
	
	$("#add-rewards #reward_type").change(function() {
		$type = $(this).val();
		
		if( $("#add-rewards #add_bonus_type").is(":visible") == true )
			$("#add-rewards #add_bonus_type").slideToggle("fast");
			
		$("#reward_row_bonus").removeClass('margin-10x-top');
			
		if( $type.length <= 0 ) {
			$("#add-rewards #reward_object").prop('disabled', true);
			$("#add-rewards #reward_amount").prop('disabled', true);
			$("#add-rewards #reward_rate").prop('disabled', true);
			$("#add-rewards #reward_desc").prop('disabled', true);
			$("#add-rewards #reward_object").val('');
			$("#add-rewards #reward_rate").val('');
			$("#add-rewards #reward_desc").val('');
			$("#add-rewards #reward_amount").val('');
			$("#add-rewards button").prop('disabled', true);
		}
		else if( $type == 0 ) {
			$("#add-rewards #reward_object").prop('disabled', false);
			$("#add-rewards #reward_amount").prop('disabled', false);
			$("#add-rewards #reward_rate").prop('disabled', false);
			$("#add-rewards #reward_desc").prop('disabled', false);
			$("#add-rewards #reward_object").val('');
			$("#add-rewards #reward_rate").val('');
			$("#add-rewards #reward_desc").val('');
			$("#add-rewards #reward_amount").val('');
			$("#add-rewards button").prop('disabled', false);
		}
		else if( $type == 1 ) {
			$("#add-rewards #reward_object").prop('disabled', true);
			$("#add-rewards #reward_amount").prop('disabled', false);
			$("#add-rewards #reward_rate").prop('disabled', false);
			$("#add-rewards #reward_desc").prop('disabled', true);
			$("#add-rewards #reward_object").val('Zeny');
			$("#add-rewards #reward_rate").val('');
			$("#add-rewards #reward_desc").val('Zeny');
			$("#add-rewards #reward_amount").val('');
			$("#add-rewards button").prop('disabled', false);
		}
		else if( $type == 2 ) {
			$("#add-rewards #reward_object").prop('disabled', true);
			$("#add-rewards #reward_amount").prop('disabled', false);
			$("#add-rewards #reward_rate").prop('disabled', false);
			$("#add-rewards #reward_desc").prop('disabled', true);
			$("#add-rewards #reward_object").val('Pontos de Cash');
			$("#add-rewards #reward_rate").val('');
			$("#add-rewards #reward_desc").val('Pontos de Cash');
			$("#add-rewards #reward_amount").val('');
			$("#add-rewards button").prop('disabled', false);
		}
		else if( $type == 3 ) {
			$("#add-rewards #reward_object").prop('disabled', true);
			$("#add-rewards #reward_amount").prop('disabled', false);
			$("#add-rewards #reward_rate").prop('disabled', false);
			$("#add-rewards #reward_desc").prop('disabled', true);
			$("#add-rewards #reward_object").val('Pontos Kafra');
			$("#add-rewards #reward_rate").val('');
			$("#add-rewards #reward_desc").val('Pontos Kafra');
			$("#add-rewards #reward_amount").val('');
			$("#add-rewards button").prop('disabled', false);
		}
		else if( $type == 4 ) {
			$("#add-rewards #reward_object").prop('disabled', true);
			$("#add-rewards #reward_amount").prop('disabled', false);
			$("#add-rewards #reward_rate").prop('disabled', false);
			$("#add-rewards #reward_desc").prop('disabled', true);
			$("#add-rewards #reward_object").val('Experi�ncia de Base');
			$("#add-rewards #reward_rate").val('');
			$("#add-rewards #reward_desc").val('Experi�ncia de Base');
			$("#add-rewards #reward_amount").val('');
			$("#add-rewards button").prop('disabled', false);
		}
		else if( $type == 5 ) {
			$("#add-rewards #reward_object").prop('disabled', true);
			$("#add-rewards #reward_amount").prop('disabled', false);
			$("#add-rewards #reward_rate").prop('disabled', false);
			$("#add-rewards #reward_desc").prop('disabled', true);
			$("#add-rewards #reward_object").val('Experi�ncia de Classe');
			$("#add-rewards #reward_rate").val('');
			$("#add-rewards #reward_desc").val('Experi�ncia de Classe');
			$("#add-rewards #reward_amount").val('');
			$("#add-rewards button").prop('disabled', false);
		}
		else if( $type == 6 ) {
			$("#add-rewards #reward_object").prop('disabled', true);
			$("#add-rewards #reward_amount").prop('disabled', false);
			$("#add-rewards #reward_rate").prop('disabled', false);
			$("#add-rewards #reward_desc").prop('disabled', true);
			$("#add-rewards #reward_object").val('N�vel de Base');
			$("#add-rewards #reward_rate").val('');
			$("#add-rewards #reward_desc").val('N�vel de Base');
			$("#add-rewards #reward_amount").val('');
			$("#add-rewards button").prop('disabled', false);
		}
		else if( $type == 7 ) {
			$("#add-rewards #reward_object").prop('disabled', true);
			$("#add-rewards #reward_amount").prop('disabled', false);
			$("#add-rewards #reward_rate").prop('disabled', false);
			$("#add-rewards #reward_desc").prop('disabled', true);
			$("#add-rewards #reward_object").val('N�vel de Classe');
			$("#add-rewards #reward_rate").val('');
			$("#add-rewards #reward_desc").val('N�vel de Classe');
			$("#add-rewards #reward_amount").val('');
			$("#add-rewards button").prop('disabled', false);
		}
		else if( $type == 8 ) {
			
			if( $("#add-rewards #add_bonus_type").is(":visible") == false )
				$("#add-rewards #add_bonus_type").slideToggle("fast");
			
			$("#add-rewards #reward_object").prop('disabled', true);
			$("#add-rewards #reward_amount").prop('disabled', false);
			$("#add-rewards #reward_rate").prop('disabled', false);
			$("#add-rewards #reward_desc").prop('disabled', true);
			$("#add-rewards #reward_object").val('B�nus de Atributo');
			$("#add-rewards #reward_rate").val('');
			$("#add-rewards #reward_desc").val('B�nus de Atributo');
			$("#add-rewards #reward_amount").val('');
			$("#reward_row_bonus").addClass('margin-10x-top');
			$("#add-rewards button").prop('disabled', false);
		}
	});
	
	$("#add-rewards #reward_object").keydown(function(e) {
		if( $("#add-rewards #reward_type").val() == 0 ) {
			$targettype = $("#add-rewards #reward_object").val();
			$(this).AutoSuggest(e,'type=13');
		}
	});
	
	$("#add-rewards button[type='reset']").click(function(e) {
		e.preventDefault();
		$type = $("#add-rewards #reward_type").val();
		
		if( $type <= 0 )
			$("#add-rewards #reward_object").val('');
		
		$("#add-rewards #reward_amount").val('');
	});
	
	$("#add-rewards").submit(function(e) {
		e.preventDefault();
		
		if( $chk_submit_send )
			return;
		
		$send = $(this).serialize();
		$chk_submit_send = true;
		waitingDialog.show('Aguarde!', {dialogSize: 'sm'});
		$achievement_id = $("#add-rewards #achievement_id").val();
		
		if( $("#add-rewards .alert-danger").is(":visible") == true )
			$("#add-rewards .alert-danger").slideToggle("medium");
		if( $("#add-rewards .alert-success").is(":visible") == true )
			$("#add-rewards .alert-success").slideToggle("medium");
		
		$.ajax({
			url: 'actions/add-reward.php',
			type: 'POST',
			async: true,
			cache: false,
			data: $send,
			dataType: 'json',
			success: function(result) {
				waitingDialog.hide();
				$chk_submit_send = false;
				
				if( result[0] == "success" )
				{
					if( $count_rewards <= 0 )
						$("#reward-list .table tbody").find('.no-result').remove();
					
					$("#reward-list .table tbody").append("<tr data-target='" + result[1] + "'><td>" + result[2] + "</td><td>" + result[3] + "</td><td>" + result[4] + "</td><td>" + result[5] + "</td><td>Ativado</td><td><button class='btn btn-danger btn-xs' data-action='remove' data-target='" + result[1] + "' data-toggle='tooltip' data-placement='top' title='Remover'><span class='glyphicon glyphicon-remove' aria-hidden='true'></span></button> <button class='btn btn-primary btn-xs' data-action='disable' data-target='" + result[1] + "' data-toggle='tooltip' data-placement='top' title='Ativar ou Desativar'><span class='glyphicon glyphicon-refresh' aria-hidden='true'></span></button></td></tr>");
					$('[data-toggle="tooltip"]').tooltip({html:true});
					$("#add-rewards .alert-success div").html(result[6]);
					$("#add-rewards .alert-success").slideToggle("medium");
					$count_rewards++;
					
					$('.table-conquest .base-bottom').ReloadCutinReward($achievement_id);
					
					// Reload Binds
					$("#reward-list button[data-action='remove']").bind("click",function(e) {
						$(this).RemoveReward(e);
					});
					
					$("#reward-list button[data-action='disable']").bind("click",function(e) {
						$(this).ChangeRewardStatus(e);
					});
					
					$("#add-rewards #reward_type").change();
				}
				else {
					if( $("#add-rewards #"+result[0]).length )
						$("#add-rewards #"+result[0]).focus();
					
					$("#add-rewards .alert-danger div").html(result[1]);
					$("#add-rewards .alert-danger").slideToggle("medium");
					$('html, body').animate({scrollTop: $('#add-rewards .alert-danger').offset().top-80}, 'medium');
				}
				
				return false;
			},
			error: function(request, status, error) {
				waitingDialog.hide();
				$chk_submit_send = false;
				console.log(arguments);
				$("#add-rewards .alert-danger div").html("Houve um erro inesperado!");
				$("#add-rewards .alert-danger").slideToggle("medium");
				$('html, body').animate({scrollTop: $('#add-rewards .alert-danger').offset().top-80}, 'medium');
			}
		});
	});
	
	$("#reward-list button[data-action='remove']").bind("click", function(e) {
		$(this).RemoveReward(e);
	});
	
	$("#reward-list button[data-action='enable'], #reward-list button[data-action='disable']").bind("click", function(e) {
		$(this).ChangeRewardStatus(e);
	});

	jQuery.fn.RemoveReward = function(e) {
		e.preventDefault();
		
		if( $chk_submit_send )
			return;
		
		$chk_submit_send = true;
		waitingDialog.show('Aguarde!', {dialogSize: 'sm'});
		
		$target = $(this).attr("data-target");
		
		if( $("#add-rewards .alert-danger").is(":visible") == true )
			$("#add-rewards .alert-danger").slideToggle("medium");
		if( $("#add-rewards .alert-success").is(":visible") == true )
			$("#add-rewards .alert-success").slideToggle("medium");
		
		$.ajax({
			url: 'actions/remove-reward.php',
			type: 'POST',
			async: true,
			cache: false,
			data: 'id='+$target,
			dataType: "json",
			success: function(result) {
				waitingDialog.hide();
				$chk_submit_send = false;
				
				if( result[0] == "success" )
				{
					$("#reward-list .table tbody").find("tr[data-target='" + result[1] + "']").each(function() {
						$(this).remove();
						$count_rewards--;
						
						// Reset Panel Filter
						$('.filterable .btn-filter').ClearFilter();
						
						if( $count_rewards <= 0 )
							$("#reward-list .table tbody").append("<tr class='no-result text-center'><td colspan='5'>Nenhuma recompensa cadastrada!</div></tr>");
					});
				}
				else {
					$("#add-rewards .alert-danger div").html(result[1]);
					
					if( $("#add-rewards .alert-danger").is(":visible") == false )
						$("#add-rewards .alert-danger").slideToggle("medium");	

					$('html, body').animate({scrollTop: $('#add-targets .alert-danger').offset().top-80}, 'medium');
				}
				return false;
			},
			error: function(request, status, error) {
				waitingDialog.hide();
				$chk_submit_send = false;
				console.log(arguments);
				$("#add-rewards .alert-danger div").html("Houve um erro inesperado!");
				$("#add-rewards .alert-danger").slideToggle("medium");
				$('html, body').animate({scrollTop: $('#add-rewards .alert-danger').offset().top-80}, 'medium');
			}
		});
	}
	
	jQuery.fn.ChangeRewardStatus = function(e) {
		e.preventDefault();
		
		if( $chk_submit_send )
			return;
		
		$chk_submit_send = true;
		waitingDialog.show('Aguarde!', {dialogSize: 'sm'});
		
		$target = $(this).attr("data-target");
		$status = $(this).attr("data-action") == 'enable' ? 1 : 0;
		
		if( $("#add-targets .alert-danger").is(":visible") == true )
			$("#add-targets .alert-danger").slideToggle("medium");
		if( $("#add-targets .alert-success").is(":visible") == true )
			$("#add-targets .alert-success").slideToggle("medium");
		
		$.ajax({
			url: 'actions/change-reward-status.php',
			type: 'POST',
			async: true,
			cache: false,
			data: 'id='+$target+'&status='+$status,
			dataType: 'json',
			success: function(result) {
				waitingDialog.hide();
				$chk_submit_send = false;
				if( result[0] == "success" )
				{
					$("#reward-list .table tbody").find("tr[data-target='" + result[1] + "']").each(function() {
						$update = $(this).find("td:nth-child(5)");
						$update.html(result[2]==1?"Ativado":"Desativado");
						
						$update = $(this).find("td:nth-child(6) button[data-action='"+(result[2]==1?"enable":"disable")+"']");
						$update.attr("data-action", (result[2]==1?"disable":"enable"));
					});
					
					// Reload Binds
					$("#reward-list button[data-action='remove']").bind("click",function(e) {
						$(this).RemoveReward(e);
					});
					
					$("#reward-list button[data-action='enable'], #reward-list button[data-action='disable']").bind("click",function(e) {
						$(this).ChangeRewardStatus(e);
					});
				}
				else {
					$("#add-rewards .alert-danger div").html(result[1]);
					
					if( $("#add-rewards .alert-danger").is(":visible") == false )
						$("#add-rewards .alert-danger").slideToggle("medium");

					$('html, body').animate({scrollTop: $('#add-rewards .alert-danger').offset().top-80}, 'medium');
				}
				return false;
			},
			error: function(request, status, error) {
				waitingDialog.hide();
				$chk_submit_send = false;
				console.log(arguments);
				$("#add-rewards .alert-danger div").html("Houve um erro inesperado!");
				$("#add-rewards .alert-danger").slideToggle("medium");
				$('html, body').animate({scrollTop: $('#add-rewards .alert-danger').offset().top-80}, 'medium');
			}
		});
	}
});