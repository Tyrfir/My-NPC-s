<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  *---------------------------------------------------------------*/
// As categorias s�o ordenada de acordo como a lista.
return array(
		 0 => 'Eliminar um Jogador:',
		 1 => 'Eliminar um Jogador de outro Cl�:',
		 2 => 'Eliminar um Jogador de outro Ex�rcito:',
		 3 => 'Vencer Batalhas Campais:',
		 4 => 'Destruir o Emperium:',
		 5 => 'Ajuntar quantia de Zeny:',
		 6 => 'Gastar uma quantia de Zeny:',
		 7 => 'Gastar Zeny(s) de uma �nica vez:',
		 8 => 'Construir Runas Guardi�s:',
		 9 => 'Construir Barricadas:',
		10 => 'Aguardar o Tempo:',
		11 => 'Visitar %s (%s):',
		12 => 'Eliminar o Monstro <a href="%s" target="_blank">%s</a>:',
		13 => 'Coletar o Item <a href="%s" target="_blank">%s</a>:',
		// (Sub-objetivo): 14 Pegar um item de um determinado monstro.
		// (Sub-objetivo): 15 Estar em um determinado mapa.
		16 => 'Eliminar qualquer MvP:',
		17 => 'Estar presente �s %sh:',
		18 => 'Ganhar uma quantia de Zeny de uma �nica vez:',
		19 => 'N�vel de Base:',
		20 => 'N�vel de Classe:',
		21 => 'N�vel de Base ou Classe:',
		// (Sub-objetivo): 22 Estar em um determinada Classe.
		23 => 'Torna-se um %s:',
		// (Sub-objetivo): 22 O Alvo deve estar em um determinada Classe.
		25 => 'Utilizar o Item <a href="%s" target="_blank">%s</a>:',
		26 => 'Comprar o Item <a href="%s" target="_blank">%s</a> em Vendas de NPC\'s:',
		27 => 'Comprar o Item <a href="%s" target="_blank">%s</a> em Vendas de Jogadores:',
		28 => 'Comprar o Item <a href="%s" target="_blank">%s</a> em Vendas de Jogadores ou NPC\'s:',
		29 => 'Comprar qualquer item em Vendas de NPC\'s:',
		30 => 'Comprar qualquer item em Vendas de Jogadores:',
		31 => 'Comprar qualquer item em Vendas de Jogadores ou NPC\'s:',
		32 => 'Vender o Item <a href="%s" target="_blank">%s</a> em Vendas de NPC\'s:',
		33 => 'Vender o Item <a href="%s" target="_blank">%s</a> em Vendas de Jogadores:',
		34 => 'Vender o Item <a href="%s" target="_blank">%s</a> em Vendas de Jogadores ou NPC\'s:',
		35 => 'Vender qualquer item em Vendas de NPC\'s:',
		36 => 'Vender qualquer item em para Jogadores:',
		37 => 'Vender qualquer item em para Jogadores ou NPC\'s:',
		38 => 'Pegar o Item <a href="%s" target="_blank">%s</a> em Trocas:',
		39 => 'Dar o Item <a href="%s" target="_blank">%s</a> em Trocas:',
		40 => 'Pegar ou Dar o Item <a href="%s" target="_blank">%s</a> em Trocas:',
		41 => 'Pegar qualquer item em Trocas:',
		42 => 'Dar qualquer item em Trocas:',
		43 => 'Pegar ou Dar qualquer item em Trocas:',
		44 => 'Pegar uma quantia de Zeny em Trocas:',
		45 => 'Dar uma quantia de Zeny em Trocas:',
		46 => 'Pegar Zeny(s) em Trocas de uma �nica vez:',
		47 => 'Dar Zeny(s) em Trocas de uma �nivez vez:',
		//48 ~ 50 livre
		// (Countdown): 51 Tempo restante para terminar a conquista
		52 => 'Completar a Conquista %s:'
);