PT-BR:
Caso você já possua o items.conf neste diretório, por favor, apenas migrar as configurações dentro no existente!

ENG:
If you already have items.conf in this directory, please just migrate the settings inside the existing one!