<?php
	if( !defined("CLIENT_PAGE") )
		exit;
	
	// Paginator
	$paginator = !isset($_GET['page']) || $_GET['page'] == 0 ? 1 : $_GET['page'];
	$init = ($paginator-1)*Config::$rank_max_rows;

	// Get Ranking
	$Ranking->Load($init);
?>
	<div class="content">
		<div class="header">
			<h4><i class="fa fa-trophy" aria-hidden="true"></i>&nbsp;&nbsp;Top Conquistadores</h4>
			<hr>
		</div>
		<table class="ranking-list">
		  <thead>
			<tr>
				<th>#</th>
				<th>Jogador</th>
				<th>Pontua��o</th>
				<th>Sexo</th>
				<th>Atualiza��o</th>
				<th>Player On-line</th>
			</tr>
		  </thead>
		  <tbody>
		<?php
			for( $i=0; $i < $Ranking->count; $i++ )
			{
				$account_id = $Ranking->players['account_id'][$i];
				$nickname = $Ranking->players['nickname'][$i];
				$sex = $Ranking->players['sex'][$i];
				$tmp_online = $Ranking->players['online'][$i];
				
				if( count($tmp_online) )
					$online = '<span data-toggle="tooltip" title="<label>Personagem encontra-se em:</label>' . $tmp_online[1] . ' ' . $tmp_online[2] . ', ' . $tmp_online[3] .'">' . $tmp_online[0] . '</span>';
				else
					$online = '<span class="off-line">OFF</span>';
		?>
				<tr>
					<td><?php echo $Ranking->players['position'][$i] ?></td>
					<td><a href="?p=profile&profile_id=<?php echo $account_id ?>&account_id=<?php echo $_GET['account_id']?>&pass=<?php echo $_GET['pass']; if( $back_url ) { echo "&backurl=".$back_url; }?>"><?php echo $nickname ? $nickname : "N�o definido" ?></a></td>
					<td><?php echo $Ranking->players['score'][$i] ?></td>
					<td><?php echo $sex !== null ? ($sex?"Feminino":"Masculino") : "N�o definido" ?></td>
					<td><?php echo $Ranking->players['lastupdate'][$i] ?></td>
					<td><?php echo $online ?></td>
				</tr>
		<?php
			}
		?>
		  </tbody>
		  
		 <?php if( isset($_GET['backurl']) && trim($_GET['backurl']) ) { ?>
		   <tfoot>
				<tr>
					<td colspan="6" class="back-url">
						<a href="<?php echo urldecode($_GET['backurl']) ?>"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Voltar</a>
					</td>
				</tr>
			</tfoot>
		<?php } ?>
		</table>
	</div>
	
	<div class="navbar">
		<?php
			// CreateNavBar
			if( $Ranking->total > Config::$rank_max_rows ) {
				$Tpl->createNavBar($paginator,$Ranking->total,Config::$rank_max_rows,$_GET);
				$Tpl->showNavigation();
			}
		?>
	</div>