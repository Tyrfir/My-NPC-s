<?php
	if( !defined("MAIN_PAGE") )
		exit;
?>

	<a href="#" class="go-top"></a>
	
	<div class="autosuggest">
		<div class="arrow"></div>
		<div class="boxcontent"></div>
	</div>
	

<?php
	if( $Auth->CheckSession() ) {
		$account_id = isset($account_id)?$account_id:$Auth->account_id;
		$share_url = Config::$WebSite."/?p=perfil/visualizar&account_id=".$account_id;
		$share_url = urlencode($share_url);
?>
	<div class="modal fade" id="share-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	  <div class="modal-dialog">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">�</span><span class="sr-only">Fechar</span></button>
			<h4 class="modal-title" id="myModalLabel"><i class="fa fa-share-alt"></i> Compartilhe</h4>
		  </div>
		  <div class="modal-body">
			<a title="Facebook" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $share_url; ?>&t=Conquistas" target="_blank"><span class="fa-stack fa-lg"><i class="fa fa-square-o fa-stack-2x"></i><i class="fa fa-facebook fa-stack-1x"></i></span></a>
			<a title="Twitter" href="https://twitter.com/intent/tweet?source=<?php echo $share_url; ?>&text=Conquistas:<?php echo $share_url; ?>" target="_blank"><span class="fa-stack fa-lg"><i class="fa fa-square-o fa-stack-2x"></i><i class="fa fa-twitter fa-stack-1x"></i></span></a>
			<a title="Google+" href="https://plus.google.com/share?url=<?php echo $share_url ?>" target="_blank"><span class="fa-stack fa-lg"><i class="fa fa-square-o fa-stack-2x"></i><i class="fa fa-google-plus fa-stack-1x"></i></span></a>
			<a title="Linkedin" href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo $share_url ?>" target="_blank"><span class="fa-stack fa-lg"><i class="fa fa-square-o fa-stack-2x"></i><i class="fa fa-linkedin fa-stack-1x"></i></span></a>
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
		  </div>
		</div>
	  </div>
	</div>
<?php
	}
?>
	
	<footer class="footer">
		<p>Sistema de Conquistas 3.0.1</p>
		<p>2014 - <?=date("Y")?> &copy; <a href="http://www.creativesd.com.br" target="_blank">Creative Services and Development</a></p>
		<p>Desenvolvido por <a href="mailto:sbk@creativesd.com.br">Romulo de Sousa Mangueira</a></p>
		<p>Todos os Direitos Reservado</p>
		<div class="skins form-group form-group-sm text-left pull-right">
			<form id="change-theme">
				<?php echo $Tpl->getUrlInput(array('theme')); ?>
				<strong>Alterar Tema:</strong>
				<select id="theme" name="theme" class="form-control input-sm">
				<?php
					foreach( $Templates as $key => $value )
						echo "<option value=\"{$key}\"" . ($Tpl->theme==$key?' selected':'').">{$key}</option>";
				?>
				</select>
			</form>
		</div>
	</footer>
  </body>
</html>