<template>
    <img src="/img/logo.gif" alt="" srcset="" />
</template>
