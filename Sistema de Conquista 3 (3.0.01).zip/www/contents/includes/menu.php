<?php
	if( !defined("MAIN_PAGE") )
		exit;
	
	$key = (isset($_GET['key'])&&trim($_GET['key'])?$_GET['key']:null);
	$type = (isset($_GET['type'])&&is_numeric($_GET['type'])?$_GET['type']:null);
	$status = (isset($_GET['status'])&&is_numeric($_GET['status'])?$_GET['status']:1);
	
	// Binds Search
	$target_value = null;
	$target_opt = null;
	$target_type = (isset($_GET['target_type'])&&is_numeric($_GET['target_type'])?$_GET['target_type']:null);
	$target_ref = (isset($_GET['target'])&&!empty($_GET['target'])?$_GET['target']:null);
	
	if( !is_null($target_type) )
	{
		if( in_array("amount",$TargetOptions[$target_type])
			&& isset($_GET['amount']) && (int)$_GET['amount'] > 0 
			&& isset($_GET['amount_opt'])
		)
		{
			$target_value = $_GET['amount']>0?$_GET['amount']:null;
			if( isset($Operators[$_GET['amount_opt']]) )
				$target_opt = $Operators[$_GET['amount_opt']];
		}
		
		if( in_array("target",$TargetOptions[$target_type])
			&& isset($_GET['target'])
			&& !empty($_GET['target'])
		)
		{
			$target_ref = $_GET['target'];
		}
		
		if( in_array("timer",$TargetOptions[$target_type])
			&& isset($_GET['timer']) && (int)$_GET['timer'] > 0
			&& isset($_GET['timer_opt'])
		)
		{
			$target_value = $_GET['timer']>0?$_GET['timer']:null;
			if( isset($Operators[$_GET['timer_opt']]) )
				$target_opt = $Operators[$_GET['timer_opt']];
		}
		
		// Search by Hour formatted
		if( in_array("hour",$TargetOptions[$target_type])
			&& (isset($_GET['hour']) && is_numeric($_GET['hour']) || isset($_GET['minute']) && is_numeric($_GET['minute']))
		)
		{
			if( isset($_GET['minute']) && is_numeric($_GET['minute']) )
			{
				if( $_GET['minute'] > 60 )
					$_GET['minute'] = 60;
				if( $_GET['minute'] < 0 )
					$_GET['minute'] = 0;
				
				$target_ref = sprintf(":%02d",$_GET['minute']);
			}
			
			if( isset($_GET['hour']) && is_numeric($_GET['hour']) )
			{
				if( $_GET['hour'] > 24 )
					$_GET['hour'] = 24;
				if( $_GET['hour'] < 0 )
					$_GET['hour'] = 0;
				
				if( is_null($target_ref) )
					$target_ref = sprintf("%02d:", $_GET['hour']);
				else
					$target_ref = sprintf("%02d%s", $_GET['hour'], $target_value);
			}
			
			if( strlen($target_ref) < 5 )
				$target_opt = 5;
			else
				$target_opt = 0;
		}
	}
?>
	<div class="main-menu">
		<div class="input-group" id="search">
			<input id="primary-key" type="text" class="form-control" placeholder="Nome ou descri��o..." value="<?php echo $key; ?>" />
			<div class="input-group-btn">
				<div class="btn-group" role="group">
					<div class="dropdown dropdown-lg">
						<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><span class="caret"></span></button>
						<div class="dropdown-menu dropdown-menu-right" role="menu">
							<form id="form-search" class="form-horizontal" role="form">
							<input type="hidden" id="p" name="p" value="lista">
							<input type="hidden" id="key" name="key" value="<?php echo $key; ?>">
							  <div class="form-group">
								<label for="type">Tipo:</label>
								<select name="type" class="form-control">
									<option value="">Qualquer tipo</option>
									<?php
										foreach( $CategoryList as $value => $name ) {
									?>
									<option value="<?php echo $value;?>"<?php if( !is_null($type) && $type == $value ) echo " selected"; ?>><?php echo $name; ?>
									<?php
										}
									?>
								</select>
							  </div>
							  <div class="form-group">
								<label for="target_type">Tipo do Alvo:</label>
								<select id="target_type" name="target_type" class="form-control">
									<option value="">Qualquer Alvo</option>
									<?php
										foreach( $TargetTypes as $value => $name ) {
											$enabledopts = "";
											if( isset($TargetOptions[$value]) )
											{
												for( $i = 0; $i < count($TargetOptions[$value]); $i++ )
													$enabledopts .= $TargetOptions[$value][$i].($i+1<count($TargetOptions[$value])?",":"");
											}
									?>
									<option value="<?php echo $value;?>"<?php if(!empty($enabledopts)) { echo ' enabledOpts="'.$enabledopts.'"'; } if( !is_null($target_type) && $target_type == $value ) { echo " selected"; } ?>><?php echo $name; ?></option>
									<?php
										}
									?>
								</select>
							  </div>
							  <div class="form-group" id="search_target">
								<label for="target">Alvo:</label>
								<input id="target" name="target" class="form-control" type="text" value="<?php echo $target_ref?>" autocomplete="off" disabled>
							  </div>
							  <div class="form-group" id="search_hour">
								<label for="hour">Hor�rio:</label>
								
								<select id="hour_opt" name="hour_opt" class="form-control" disabled>
									<option value="0">Exatamente</option>
									<option value="1">Menor</option>
									<option value="2">Maior</option>
									<option value="3">Menor ou Igual</option>
									<option value="4">Maior ou Igual</option>
								</select>
								
								<input id="hour" name="hour" class="form-control" type="number" min="00" max="24" placeholder="hh" disabled>
								<div id="hour_separate">:</div>
								<input id="minute" name="minute" class="form-control" type="number" min="00" max="60" placeholder="mm" disabled>
							  </div>
							  <div class="form-group" id="search_amount">
								<label>Quantidade:</label>
								<select id="amount_opt" name="amount_opt" class="form-control" disabled>
									<option value="0">Exatamente</option>
									<option value="1">Menor</option>
									<option value="2">Maior</option>
									<option value="3">Menor ou Igual</option>
									<option value="4">Maior ou Igual</option>
								</select>
								<input id="amount" name="amount" class="form-control" type="number" disabled>
							  </div>
							  <div class="form-group" id="search_timer">
								<label for="timer">Tempo:</label>
								<select id="timer_opt" name="timer_opt" class="form-control" disabled>
									<option value="0">Exatamente</option>
									<option value="1">Menor</option>
									<option value="2">Maior</option>
									<option value="3">Menor ou Igual</option>
									<option value="4">Maior ou Igual</option>
								</select>
								<input id="timer" name="timer" class="form-control" type="number" disabled>
								<p class="sub-desc">O tempo deve ser informado em minutos.</p>
							  </div>
							  <div class="form-group">
								<label for="status">Situa��o:</label>
								<select id="status" name="status" class="form-control">
									<option value="2"<?php if( $status == 2 ) echo " selected" ?>>Todas Conquistas</option>
									<option value="0"<?php if( $status == 0 ) echo " selected" ?>>Em progresso</option>
									<option value="1"<?php if( $status == 1 ) echo " selected" ?>>Conquistadas</option>
								</select>
							  </div>
							  <div class="form-group text-right">
								<button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-search" aria-hidden="true"></span> Buscar</button>
							  </div>
							</form>
						</div>
					</div>
					<button type="button" id="primary-search" class="btn btn-primary btn-search"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
				</div>
			</div>
		</div>
		
		<?php
			$Profile->RequestData($Auth->account_id);
		?>
		
		<div class="profile">
			<div class="image-profile"><img id="profile_avatar" src="<?php echo $Profile->avatar_url ? $Profile->avatar_url : $ProfileCfg['DEFAULT_AVATAR'] ?>" /></div>
			<div class="info">
				<ul>
					<li><i class="fa fa-star" aria-hidden="true"></i>&nbsp;&nbsp;<strong>Nick:</strong> <span id="profile_nickname"><?php echo $Profile->nickname ? $Profile->nickname : "N�o definido" ?></span></li>
					<li><i class="fa fa-address-card" aria-hidden="true"></i>&nbsp;&nbsp;<strong>Nome:</strong> <span id="profile_name"><?php echo $Profile->firstname ? $Profile->firstname : "N�o definido" ?></span></li>
					<li><i class="fa fa-venus-mars" aria-hidden="true"></i>&nbsp;&nbsp;<strong>Sexo:</strong> <span id="profile_gender"><?php echo $Profile->sex !== null ? ($Profile->sex?"Feminino":"Masculino") : "N�o definido" ?></span></li>
					<li><i class="fa fa-calendar" aria-hidden="true"></i>&nbsp;&nbsp;<strong>Idade:</strong> <span id="profile_age"><?php echo $Profile->age ? $Profile->age : "N�o definido" ?></span></li>
					<li><i class="fa fa-globe" aria-hidden="true"></i>&nbsp;&nbsp;<strong>Local:</strong> <span id="profile_birthdate"><?php echo $Profile->state ? $Profile->state : "N�o definido" ?></span></li>
					<li><i class="fa fa-trophy" aria-hidden="true"></i>&nbsp;&nbsp;<strong>Rank:</strong> <?php echo $Profile->rank ? "#".$Profile->rank : "N�o qualificado" ?></li>
					<li><i class="fa fa-spinner" aria-hidden="true"></i>&nbsp;&nbsp;<strong>Progresso:</strong> <?php echo $Profile->progress ."%" ?></li>
				</ul>
			</div>
			<div class="tools"><a href="?p=perfil/editar" class="pull-right"><span class="glyphicon glyphicon-cog"></a> <a href="#share" class="pull-right" data-toggle="modal" data-target="#share-modal"><i class="fa fa-share-alt"></i></a></div>
		</div>
		
		<div class="icon-menu"></div>
		<div class="side-bar">
			<ul>
				<li class="menu-head">
					<a href="#">Painel de Conquistas <span class="glyphicon glyphicon-align-justify pull-right"></span></a>
				</li>
				<div class="menu">
					<li>
						<a href="?p=perfil/visualizar"<?php if( $p == 'perfil/visualizar' ) echo 'class="active"'?>>Meu Perfil <span class="glyphicon glyphicon-user pull-right"></span></a>
					</li>
					<li>
						<a href="?p=lista"<?php if( $p == 'lista' ) echo 'class="active"'?>>Lista de Conquistas <span class="glyphicon glyphicon-star pull-right"></span></a>
					</li>
					<li>
						<a href="?p=ranking" <?php if( $p == 'ranking' ) echo 'class="active"'?>>Ranking  <i class="fa fa-trophy pull-right" aria-hidden="true"></i></a>
					</li>
					<?php if( $Auth->CheckAccess('ACH_NEW') ) { ?>
					<li>
						<a href="?p=admin/nova-conquista"<?php if( $p == 'admin/nova-conquista' ) echo 'class="active"'?>>Nova Conquista <span class="glyphicon glyphicon-plus pull-right"></span></a>
					</li>
					<?php } if( $Auth->CheckAccess('GEN_CUTIN') ) { ?>
					<li>
						<a href="?p=admin/gerador-de-cutin"<?php if( $p == 'admin/gerador-de-cutin' ) echo 'class="active"'?>>Gerar Cutin <span class="glyphicon glyphicon-picture pull-right"></span></a>
					</li>
					<?php } ?>
					<li>
						<a href="#share" data-toggle="modal" data-target="#share-modal">Compartilhe <i class="fa fa-share-alt pull-right"></i></a>
					</li>
					<li>
						<a href="?p=login&code=logout">Logout <span class="glyphicon glyphicon-log-out pull-right"></span></a>
					</li>
				</div>	
			</ul>
		</div>
	</div>