<?php
	if( !defined("CLIENT_PAGE") )
		exit;
	
	// Requer esta conectado...
	if( !isset($_GET['profile_id']) || empty($_GET['profile_id']) || !is_numeric($_GET['profile_id']) )
		$account_id = $Client->account_id;
	else {
		// Account_id from other player
		$account_id = $_GET['profile_id'];
	}
	
	if( !$Client->CheckExist($account_id) )
	{
		$help_rand = rand(1,6);
?>
	<div class="page-error-main">
		<strong>Ooops!</strong>
		<p>Perfil n�o encontrado...</p>
		<?php if( isset($_GET['backurl']) && trim($_GET['backurl']) ) { ?>
		<p class="back-url"><a href="<?php echo urldecode($_GET['backurl']) ?>" class="pull-left"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Voltar</p>
		<?php } ?>
		<div class="alert-icon-help-<?php echo $help_rand; ?>"></div>
	</div>
<?php
	}
	else {
		$Profile->RequestData($account_id);
?>
	<div class="content page-profile">
		<div class="header">
			<h4><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Perfil de <?php echo $Profile->nickname ?></h4>
			<hr>
		</div>
		<div class="avatar-box pull-left"><img class="avatar" src="<?php echo $Profile->avatar_url ? $Profile->avatar_url : "../".$ProfileCfg['DEFAULT_AVATAR'] ?>"></div>
		<div class="info-box pull-right">
			<div class="box"><i class="fa fa-address-card" aria-hidden="true"></i> <span>Nome Completo:</span> <?php echo $Profile->name ? $Profile->name : "N�o informado" ?></div>
			<div class="box"><i class="fa fa-star-o" aria-hidden="true"></i> <span>Nick:</span> <?php echo $Profile->nickname ?></div>
			<div class="box"><i class="fa fa-venus-mars" aria-hidden="true"></i> <span>Sexo:</span> <?php echo $Profile->sex?"Feminino":"Masculino" ?></div>
			<div class="box"><i class="fa fa-calendar" aria-hidden="true"></i> <span>Nascimento:</span> <?php echo $Profile->birthdate ? $Profile->birthdate : "N�o informado" ?></div>
			<div class="box"><i class="fa fa-asterisk" aria-hidden="true"></i> <span>Idade:</span> <?php echo $Profile->age ? $Profile->age : "N�o informado" ?></div>
		<?php
			$tmp_local = array();
			if( $Profile->country )
				$tmp_local[] = $Profile->country;
			if( $Profile->state && count($tmp_local) )
				$tmp_local[] = "(" . $Profile->state . ")";
			else if( $Profile->state )
				$tmp_local[] = $Profile->state;
						
			$local = implode(" ", $tmp_local);
		?>
			<div class="box"><i class="fa fa-globe" aria-hidden="true"></i> <span>Local:</span> <?php echo $local ? $local : "N�o informado" ?></div>
			<div class="box"><i class="fa fa-trophy" aria-hidden="true"></i> <span>Rank:</span> <?php echo $Profile->rank?$Profile->rank."� colocado":"N�o qualificado" ?></div>
			<div class="box"><i class="fa fa-spinner" aria-hidden="true"></i> <span>Progresso:</span> <?php echo $Profile->progress ."%" ?> (<strong><?php echo $Profile->total ?></strong> de <strong><?php echo $Profile->total_db ?></strong> conquistas)</div>
		</div>
	</div>
<?php
		if( $Profile->description ) {
?>
	<div class="content page-profile">
		<div class="header">
			<h4><i class="fa fa-info-circle" aria-hidden="true"></i>&nbsp;&nbsp;Sobre mim</h4>
			<hr>
		</div>
		<div class="about-me"><?php echo $Profile->description; ?></div>
	</div>
<?php
		}
		
		if( count($Profile->last_achievements) ) {
			
		}
?>
	<div class="content page-profile">
		<div class="header">
			<h4><i class="fa fa-trophy" aria-hidden="true"></i>&nbsp;&nbsp;Conquistas recentes</h4>
			<hr>
		</div>
		<table class="last-achievements">
			<thead>
				<tr>
					<th></th>
					<th>Nome</th>
					<th>Data</th>
				</tr>
			</thead>
			<tbody>
		<?php
			// Paginator
			$paginator = !isset($_GET['page']) || $_GET['page'] == 0 ? 1 : $_GET['page'];
			$init = ($paginator-1)*$ProfileCfg['MAX_LAST'];
			$end = $init+$ProfileCfg['MAX_LAST'];
			
			for( $i=$init; $i < $end && $i < count($Profile->last_achievements); $i++ ) {
				
				$name = $Profile->last_achievements[$i]['name'];
				$icon = $Profile->last_achievements[$i]['icon'];
				$date = date_create($Profile->last_achievements[$i]['date_time']);
				$date = date_format($date, "d.m.Y");
				
				if( file_exists("../images/icons/{$icon}.png") )
					$img = "../images/icons/{$icon}.png";
				else if( file_exists("../images/icons/{$icon}.gif") )
					$img = "../images/icons/{$icon}.gif";
				else
					$img = "../images/null.png";
		?>
				<tr>
					<td><img src="<?php echo $img; ?>" class="icon"></td>
					<td><?php echo $name ?></td>
					<td><?php echo $date ?></td>
				</tr>
		<?php
			}
		?>
			</tbody>
		</table>
		
		<?php
			if( count($Profile->last_achievements) > $ProfileCfg['MAX_LAST'] ) {
		?>
				<div class="navbar">
					<?php
						// CreateNavBar
						$Tpl->createNavBar($paginator,count($Profile->last_achievements),$ProfileCfg['MAX_LAST'],$_GET);
						$Tpl->showNavigation();
					?>
				</div>
		<?php
			}
		?>
	</div>
<?php
		if( isset($_GET['backurl']) && trim($_GET['backurl']) ) {
?>
	   <div class="back-url-profile">
			<a href="<?php echo urldecode($_GET['backurl']) ?>"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Voltar</a>&nbsp;
	   </div>
<?php
		}
	}
?>