<?php if (!defined('FLUX_ROOT')) exit; ?>
      <div id="leftbar">
        <div class="boarder">
          <img src="<?php echo $this->themePath('img/emblem.png'); ?>" alt="" title="" class="emblem">
          <div class="guild">
            <b>Guild of BonifacioRO</b><br>
            <span class="gm">Leader: <b>GM Parpar</b></span>
          </div>
          <div class="clear"></div>
          <div class="char">
			<div class="sex">
            <img src="<?php echo $this->themePath('img/potm/M/4016.gif'); ?>" alt="" title=""></div><br>
            Ice Cream<br>
            Job: <span class="job">Champion</span>
          </div>
          <div class="char">
			<div class="sex">
            <img src="<?php echo $this->themePath('img/potm/M/4013.gif'); ?>" alt="" title=""></div><br>
            Parparazzi™<br>
            Job: <span class="job">Assassin Cross</span>
          </div>
        </div>
		</div>