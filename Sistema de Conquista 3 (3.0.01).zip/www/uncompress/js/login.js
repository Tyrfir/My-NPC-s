/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  .---------------------------------------------------------------.
  .                        Login & Logout                         .
  *---------------------------------------------------------------*/
$(document).ready(function() {
	$chk_submit_send = false;
	$("#form-login").submit(function(e) {
		e.preventDefault();
		
		if( $chk_submit_send )
			return;
		
		$send = $(this).serialize();
		$chk_submit_send = true;
		
		waitingDialog.show('Aguarde!', {dialogSize: 'sm'});
		
		if( $("#form-login .alert-danger").is(":visible") == true )
			$("#form-login .alert-danger").slideToggle("medium");
		if( $("#form-login .alert-success").is(":visible") == true )
			$("#form-login .alert-success").slideToggle("medium");
		
		$.ajax({
			url: 'actions/login.php',
			type: 'POST',
			async: true,
			cache: false,
			data: $send,
			dataType: 'json',
			success: function(result) {
				waitingDialog.hide();
				if( result[0] != "success" )
				{
					$chk_submit_send = false;
					$("#"+result[0]).focus();
					$("#form-login .alert-danger div").html(result[1]);
					$("#form-login .alert-danger").slideToggle("medium");
					
					$('html, body').animate({scrollTop: $('#form-login .alert-danger').offset().top-80}, 'medium');
				}
				else {
					$("#form-login .alert-success div").html(result[1]);
					$("#form-login .alert-success").slideToggle("medium");
					window.location = result[2];
				}
				return false;
			},
			error: function(request, status, error) {
				waitingDialog.hide();
				$chk_submit_send = false;
				console.log(arguments);
				$("#form-login .alert-danger div").html("Houve um erro inesperado!");
				$("#form-login .alert-danger").slideToggle("medium");
				$("html, body").animate({scrollTop: $("#form-login .alert-danger").offset().top-80}, "medium");
			}
		});
	});
});