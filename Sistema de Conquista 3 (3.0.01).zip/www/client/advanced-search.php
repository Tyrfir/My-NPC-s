<?php
	if( !defined("CLIENT_PAGE") )
		exit;
	
	// Search
	$key = (isset($_GET['key'])&&trim($_GET['key'])?$_GET['key']:null);
	$type = (isset($_GET['type'])&&is_numeric($_GET['type'])?$_GET['type']:null);
	$status = (isset($_GET['status'])&&is_numeric($_GET['status'])?$_GET['status']:1);
	
	// Binds Search
	$target_value = null;
	$target_opt = null;
	$target_type = (isset($_GET['target_type'])&&is_numeric($_GET['target_type'])?$_GET['target_type']:null);
	$target_ref = (isset($_GET['target'])&&!empty($_GET['target'])?$_GET['target']:null);
	
	if( !is_null($target_type) )
	{
		if( in_array("amount",$TargetOptions[$target_type])
			&& isset($_GET['amount']) && (int)$_GET['amount'] > 0 
		)
		{
			$target_value = $_GET['amount']>0?$_GET['amount']:null;
		}
		
		if(
			(in_array("target",$TargetOptions[$target_type])
				&& isset($_GET['target'])
				&& !empty($_GET['target']) )
			|| (in_array("timer",$TargetOptions[$target_type])
				&& isset($_GET['target']) && trim($target) )
			|| (in_array("hour",$TargetOptions[$target_type])
				&& isset($_GET['target']) && trim($target) )
		)
		{
			$target_ref = $_GET['target'];
		}
	}
?>

	<div class="content">
		<div class="header">
			<h4><i class="fa fa-search" aria-hidden="true"></i> Busca Avan�ada</h4>
			<hr>
		</div>
		
		<form action="?p=list" method="get">
			<input type="hidden" name="account_id" id="account_id" value="<?php echo $account_id; ?>">
			<input type="hidden" name="pass" id="pass" value="<?php echo $pass; ?>">
			<input type="hidden" name="p" id="p" value="list">
			<table class="advanced-search">
				<tr>
					<td>
						<label for="key">Nome ou descri��o:</label>
						<input type="text" name="key" id="key" placeholder="Nome ou descri��o..." value="<?php echo $key ?>">
					</td>
					<td>
						<label for="type">Tipo da Conquista:</label>
						<select name="type" id="type">
							<option value="">Qualquer</option>
					<?php
						foreach( $CategoryList as $value => $name) {
					?>
							<option value="<?php echo $value; ?>"<?php if( !is_null($type) && $type == $value ) { echo " selected"; } ?>><?php echo $name; ?></option>
					<?php
						}
					?>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<label for="target_type">Tipo do Alvo:</label>
						<select id="target_type" name="target_type" class="form-control">
							<option value="">Qualquer Alvo</option>
							<?php
								foreach( $TargetTypes as $value => $name ) {
							?>
							<option value="<?php echo $value;?>"<?php if( !is_null($target_type) && $target_type == $value ) { echo " selected"; } ?>><?php echo $name; ?></option>
							<?php
								}
							?>
						</select>
					</td>
					<td>
						<label for="target">Alvo:</label>
						<input id="target" name="target" type="text" value="<?php echo $target_ref ?>">
					</td>
				</tr>
				<tr>
					<td>
						<label for="amount">Quantidade:</label>
						<input id="amount" name="amount" type="number" value="<?php echo $target_value ?>">
					</td>
					<td>
						<label for="status">Situa��o:</label>
						<select id="status" name="status" class="form-control">
							<option value="2"<?php if( !is_null($status) && $status == 2 ) { echo " selected"; } ?>>Todas Conquistas</option>
							<option value="0"<?php if( !is_null($status) && $status == 0 ) { echo " selected"; } ?>>Em progresso</option>
							<option value="1"<?php if( !is_null($status) && $status == 1 ) { echo " selected"; } ?>>Conquistadas</option>
						</select>
					</td>
				</tr>
				<tr>
					<td colspan="2" align="center">
						<button type="submit" class="submit"><i class="fa fa-search" aria-hidden="true"></i> Consultar</button>
					</td>
				</tr>
				<?php if( isset($_GET['backurl']) && trim($_GET['backurl']) ) { ?>
				<tr>
					<td colspan="2" class="back-url">
						<a href="<?php echo urldecode($_GET['backurl']) ?>"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Voltar</a>
					</td>
				</tr>
				<?php } ?>
			</table>
		</form>
	</div>