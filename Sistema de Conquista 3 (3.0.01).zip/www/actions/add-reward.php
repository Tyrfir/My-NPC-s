<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  .---------------------------------------------------------------.
  .                    A��o de Adi��o de Alvos                    .
  *---------------------------------------------------------------*/
// Required Files
require_once('../config/Config.php');
require_once('../lib/Sql.class.php');
require_once('../lib/Achievement.class.php');
require_once('../lib/Numbers.class.php');
require_once('../lib/Account.class.php');

$RewardsType = require_once('../config/RewardsType.php');
$BonusStatus = require_once('../config/BonusStatus.php');
$CharRules = require_once('../config/CharRules.php');

	$Ach = new Achievements();
	$Auth = new Account();
	
	$result = array();
	
	if( !$Auth->CheckAccess('ADD_REWARD') )
		$result = array("error", utf8_encode("Voc� n�o tem autoriza��o para adicionar recompensas."));
	else if( !isset($_POST['achievement_id']) || !is_numeric($_POST['achievement_id']) )
		$result = array("submit", utf8_encode("Identifica��o n�o sinalizada."));
	else if( !isset($_POST['reward_type']) || !is_numeric($_POST['reward_type']) )
		$result = array("reward_type", utf8_encode("Voc� deve selecionar o tipo da recompensa."));
	else if( !isset($RewardsType[$_POST['reward_type']]) )
		$result = array("reward_type", utf8_encode("O tipo da recompensa deve ser v�lido!"));
	else if( !isset($_POST['reward_amount']) || !is_numeric($_POST['reward_amount']) )
		$result = array("reward_amount", utf8_encode("Voc� deve entrar com o valor da recompensa!"));
	else if( !isset($_POST['reward_rate']) || !is_numeric($_POST['reward_rate']) )
		$result = array("reward_rate", utf8_encode("Voc� deve entrar com a chance da recompensa!"));
	else {
		$achievement_id = $_POST['achievement_id'];
		$type = $_POST['reward_type'];
		$object = null;
		$desc = null;
		$amount = $_POST['reward_amount'];
		$rate = $_POST['reward_rate'];
		
		switch($type)
		{
			case 0:
				if( !isset($_POST['reward_object']) || !trim($_POST['reward_object']) )
				{
					$result = array("reward_object", utf8_encode("Voc� deve entrar com o o Item no campo de recompensa."));
					echo json_encode($result);
					exit;
				}
				
				if( !isset($_POST['reward_desc']) || !trim($_POST['reward_desc']) )
				{
					$object = $Ach->getitemid($_POST['reward_object']);
					if( !$object )
					{
						$result = array("reward_desc", utf8_encode("O item n�o contem no Banco de Dados, voc� deve inserir manualmente a descri��o do item!"));
						echo json_encode($result);
						exit;
					}
				
					$desc = $Ach->getitemname($object);
					$desc_name = $desc . " # " . $object;
				}
				else {
					$object = $Ach->getitemid($_POST['reward_object']);
					if( !$object ) {
						if( !is_numeric($_POST['reward_object']) )
						{
							$result = array("reward_object", utf8_encode("O item n�o foi encontrado no Banco de Dados, voc� deve inserir somente ID de itens personalizados."));
							echo json_encode($result);
							exit;
						}
						
						$object = $_POST['reward_object'];
					}
					
					$desc = $_POST['reward_desc'];
					$desc_name = $desc . " # " . $object;
				}
				break;
			case 1:
				$object = "Zeny";
				$desc = $desc_name = $RewardsType[$type];
				break;
			case 2:
				$object = "CashPoint";
				$desc = $desc_name = $RewardsType[$type];
				break;
			case 3:
				$object = "KafraPoint";
				$desc = $desc_name = $RewardsType[$type];
				break;
			case 4:
				$object = "BaseExp";
				$desc = $desc_name = $RewardsType[$type];
				break;
			case 5:
				$object = "JobExp";
				$desc = $desc_name = $RewardsType[$type];
				break;
			case 6:
				$object = "BaseLevel";
				$desc = $desc_name = $RewardsType[$type];
				break;
			case 7:
				$object = "JobLevel";
				$desc = $desc_name = $RewardsType[$type];
				break;
			case 8:
				if( !isset($_POST['reward_btype']) || !isset($BonusStatus[$_POST['reward_btype']]) )
				{
					$result = array("reward_btype", utf8_encode("Voc� deve selecionar um b�nus v�lido!"));
					echo json_encode($result);
					exit;
				}
				$object = $_POST['reward_btype'];
				$desc = $desc_name = $BonusStatus[$_POST['reward_btype']];
				break;
		}
		
		if( strlen($object) < $CharRules['MIN_OBJECT'] || strlen($object) > $CharRules['MAX_OBJECT'] )
			$result = array("reward_object", utf8_encode(sprintf("A recompensa deve ter <strong>entre %d a %d caracteres</strong>.", $CharRules['MIN_OBJECT'], $CharRules['MAX_OBJECT'])));
		else if( $amount < $CharRules['MIN_OBJECT_VALUE'] || $amount > $CharRules['MAX_OBJECT_VALUE'] )
			$result = array("reward_amount", utf8_encode(sprintf("O valor da recompensa deve ter <strong>entre %d a %d</strong>.", $CharRules['MIN_OBJECT_VALUE'], $CharRules['MAX_OBJECT_VALUE'])));
		else if( strlen($desc) < $CharRules['MIN_OBJECT_DESC'] || strlen($desc) > $CharRules['MAX_OBJECT_DESC'] )
			$result = array("reward_desc", utf8_encode(sprintf("A descri��o da recompensa deve ter <strong>entre %d a %d caracteres</strong>.", $CharRules['MIN_OBJECT_DESC'], $CharRules['MAX_OBJECT_DESC'])));
		else if( $rate <= 0 || $rate > 10000 )
			$result = array("reward_rate", utf8_encode("As chances da recompensa deve ter o valor <strong>entre 1 a 10000</strong>."));
		else {
			$new_id = $Ach->AddReward($_POST['achievement_id'], $object, $amount, $type, $rate, $desc);
			if( $new_id > 0 )
				$result = array("success", $new_id, $desc_name, utf8_encode($RewardsType[$type]), utf8_encode($amount), utf8_encode($rate), sprintf("Recompensa <strong>%s</strong> adicionada com sucesso!", $desc_name));
			else
				$result = array("none", "Houve um erro ao inserir a nova recompensa.");
		}
	}
	
	// Return Results
	echo json_encode($result);
	exit;
?>