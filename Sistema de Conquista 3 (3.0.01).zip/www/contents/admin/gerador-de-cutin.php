<?php
	if( !defined("MAIN_PAGE") )
		exit;
	
	// Requer esta conectado...
	$Auth->RequireLogin();
	
	// N�o est� autorizado a visualizar a p�gina.
	if( !$Auth->CheckAccess('GEN_CUTIN') ) {
		include_once('contents/errors/not-authorized.php');
		exit;
	}
	
	// Get HTML Header
	require_once('contents/includes/header.php');
	require_once('contents/includes/menu.php');

	$filesIcon = scandir('images/icons',0);
	
	$count_list = $Ach->CreateList();
	
	if( $count_list ) {
		$defaultId = $Ach->achievement_list[0]['id'];
?>
	
	<div class="content page margin-xs-top-10x" id="cutin-generator">
		<div class="container-fluid">
			<div class="row">
				<div class="col-xs-12">
					<h3><span class="glyphicon glyphicon-picture" aria-hidden="true"></span> Gerar de Cutin</h3>
				</div>
			</div>
			<hr>
			<div class="row margin-10x-bottom">
				<div class="col-xs-12">
					<div class="alert alert-warning" role="alert">
						<div class="alert-content">
							  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
							  <strong>Aten��o, para salvar seu Cutin � necess�rio que</strong>
							  <ul>
								<li>Ajuste a largura entre <strong>390 � 700 pixels</strong>, a altura � gerada automaticamente.</li>
								<li>Tire uma <strong>PrintScreen</strong> da <strong>caixa rosa</strong> abaixo.</li>
								<li>Utilize um <strong>Editor de Imagens</strong> selecionando apenas a imagem de acordo com a <strong>largura e altura</strong> informada pelo sistema.</li>
								<li>Salve o Cutin no <strong>Formato BMP</strong> e adicione na pasta <strong>Data/GRF</strong>, caso haja d�vidas acesse <a href="https://rathena.org/wiki/cutin" target="_blank">Wikip�dia do rAthena</a> que serve para qualquer emulador e patch.</li>
							  </ul>
						</div>
						<div class="alert-icon-help-2"></div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12">
					<label>Selecione o Cutin:</label>
					<select name="achievement_id" id="achievement_id" class="form-control">
					<?php
						for( $i=0; $i < $count_list; $i++ )
						{
					?>
						<option value="<?php echo $Ach->achievement_list[$i]['id'];?>"><?php echo $Ach->achievement_list[$i]['name']; ?></option>
						<?php
						}
					?>
					</select>
				</div>
			</div>
			<div class="row margin-20x-top">
				<div class="col-xs-12">
					<label>Cutin:</label>
					<div class="cutin" id="reload-cutin">
						
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 margin-20x-top">
					<label>Op��es de Visualiza��o:</label>
					<div class="checkbox">
					  <label><input id="showreward" type="checkbox" checked>Mostrar recompensas</label>
					</div>
					<div class="checkbox">
					  <label><input id="showrate" type="checkbox">Mostrar chances de recompensa</label>
					</div>
					<div class="checkbox">
						 <label><input id="defaultcutin" type="checkbox">Utilizar janela padr�o do jogo</label>
					</div>
					<div class="form-inline">
					  <label for="wdt">Largura:</label>
					  <input id="wdt" name="wdt" type="number" class="form-control" value="390">
					  <label for="hgt">Altura:</label>
					  <input id="hgt" name="hgt" type="number" class="form-control" value="137" disabled>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<script type="text/javascript" src="js/cutin-generator.js"></script>
	<script type="text/javascript">
		$('#reload-cutin').ReloadCutin(<?php echo $defaultId; ?>);
	</script>
<?php
	}
	// Get HTML Bottom Header
	require_once('contents/includes/bottom.php');
?>