/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                       Sistema de Perfil                       .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 1.0  .
  .---------------------------------------------------------------.
  .              Formul�rios de Edi��o de Perfil                  .
  *---------------------------------------------------------------*/
$(document).ready(function() {
	$('.profile-help').click(function(e) {
		e.preventDefault();
		$("#profile-help").toggle("fast");
	});
	
	$("#edit-profile #country").change(function(e) {
		$country_val = $(this).val();
		
		$check_process = false;
		$("#edit-profile #state").find("option").each(function() {
			$state_parent = $(this).attr("parent");
			if( $state_parent == $country_val )
			{
				if( $check_process == false ) {
					$(this).prop('selected', true);
					$check_process = true;
				}
				$(this).removeClass("no-display");
			}
			else {
				$(this).addClass("no-display");
			}
		});
	});
	
	$("#edit-profile button[type='reset']").click(function() {
		setTimeout(function() {
			default_desc = $("#edit-profile #desc").prop("defaultValue");
			$("#edit-profile #country").change();
			$("#edit-profile .nicEdit-main").html(default_desc);
			$("#edit-profile .nicEdit-main").keydown();
		},100);
	});
	
	bkLib.onDomLoaded(function() {
		var $description = new nicEditor({iconsPath : 'js/nicEdit/nicEditorIcons.gif', buttonList : ['bold','italic','underline','left','center','right','justify','ol','ul','fontFamily','fontSize','indent','outdent','link','unlink','forecolor','bgcolor','subscript','superscript','strikethrough','hr','removeformat']}).panelInstance('desc');
	
		$("#edit-profile .nicEdit-main").keydown(function(e) {
			setTimeout(function() { $(this).DescriptionCount(); },100);
		});
		
		$(this).DescriptionCount();
	});
	
	jQuery.fn.DescriptionCount = function() {
		setTimeout(function() {
			$size = $("#edit-profile .nicEdit-main").text().length;
			$element = $("#edit-profile #desc_char");
			$element.find("span").html($size);
			$element.css("color", ($size > $description_max_char?"#FF0000":"#000"));
		},100);
	}
	
	$("#edit-profile input[name='avatar_upload_type'").change(function() {
		$type = $(this).val();
		status_1 = $type==0?false:true;
		status_2 = $type==1?false:true;
		status_3 = $type==2?false:true;
		
		if( $("#edit-profile #current_avatar").is(":visible") == status_1 )
				$("#edit-profile #current_avatar").slideToggle("fast");
				
		$("#edit-profile #url_avatar").prop('disabled', status_2);
		if( $("#edit-profile #avatar_from_url").is(":visible") == status_2 )
			$("#edit-profile #avatar_from_url").slideToggle("fast");
			
		$("#edit-profile #upload_avatar").prop('disabled', status_3);
		if( $("#edit-profile #avatar_upload").is(":visible") == status_3 )
			$("#edit-profile #avatar_upload").slideToggle("fast");
	});
	
	$chk_submit_send = false;
	$("#edit-profile").submit(function(e) {
		e.preventDefault();
		
		if( $chk_submit_send )
			return;
		
		$description = escape($("#edit-profile .nicEdit-main").html());
		$("#edit-profile #desc").val($description);
		$chk_submit_send = true;
		var $modal = $('.upload-loading-bar'),
		$bar = $modal.find('.progress-bar');
		
		if( $("#edit-profile .alert-success").is(":visible") == true )
			$("#edit-profile .alert-success").slideToggle("medium");
					
		if( $("#edit-profile .alert-danger").is(":visible") == true )
			$("#edit-profile .alert-danger").slideToggle("medium");
		
		waitingDialog.show('Aguarde!', {dialogSize: 'sm'});
		var options = {
			type: 'POST',
		    url: 'actions/edit-profile.php',
			async: true,
			cache: false,
			dataType: 'json',
			uploadProgress: function(event, position, total, percentComplete) {
				$modal.modal('show');
				$bar.css("width",percentComplete+"%");
				$bar.addClass('animate');
				waitingDialog.hide();
			},
            success: function(result) {
				$bar.removeClass('animate');
				$modal.modal('hide');
				waitingDialog.hide();
				$chk_submit_send = false;
				
				if( result[0] != 'success' )
				{
					if( $("#edit-profile #"+result[0]).length )
						$("#edit-profile #"+result[0]).focus();
					
					$("#edit-profile .alert-danger div").html(result[1]);
					$("#edit-profile .alert-danger").slideToggle("medium");
					$("html, body").animate({scrollTop: $("#edit-profile .alert-danger").offset().top-80}, "medium");
				}
				else {
					$("html, body").animate({scrollTop: $(".profile").offset().top-80}, "medium");
					$("#edit-profile .alert-success div").html(result[1]);
					$("#edit-profile .alert-success").slideToggle("medium");
					$("#profile_name").html(result[2]);
					$("#profile_nickname").html(result[3]);
					$("#profile_age").html(result[4]);
					$("#profile_birthdate").html(result[5]);
					$("#profile_gender").html(result[6]);
					$("#profile_avatar").attr("src", result[7]);
					$("#edit-profile #current_avatar").html(result[7]);
					$("#edit-profile").find("#avatar_by_url[value='0']").click();
				}
				return false;
            },  
            error: function(request, status, error) { 
				$bar.removeClass('animate');
				$modal.modal('hide');
				waitingDialog.hide();
				$chk_submit_send = false;
				console.log(arguments);
				$("#edit-profile .alert-danger div").html("Houve um erro inesperado!");
				$("#edit-profile .alert-danger").slideToggle("medium");
				return false;
			}
        };
			
		$(this).ajaxSubmit(options);
		return false;
	});
	
	$("#submenus a").click(function(e) {
		e.preventDefault();
		target = $(this).attr("href");
		$("html, body").animate({scrollTop: $("#edit-profile "+target).offset().top-80}, "medium");
	});
});