<?php
// Requirindo Bibliotecas
require_once('config/Config.php');
require_once('lib/Sql.class.php');
require_once('lib/Achievement.class.php');
require_once('lib/Numbers.class.php');
require_once('lib/Template.class.php');
require_once('lib/Account.class.php');
require_once('lib/Profile.class.php');
require_once('lib/Ranking.class.php');

// Carregando Arrays com Listas
$BonusStatusList = require_once('config/BonusStatus.php');
$CategoryList = require_once('config/Category.php');
$JobNames = require_once('config/JobName.php');
$TargetDesc = require_once('config/TargetDesc.php');
$TargetInfo = require_once('config/TargetInfo.php');
$TargetTypes = require_once('config/TargetTypes.php');
$Templates = require_once('config/Templates.php');
$Operators = require_once('config/Operators.php');
$TargetOptions = require_once('config/TargetOptions.php');
$RewardsType = require_once('config/RewardsType.php');
$CharRules = require_once('config/CharRules.php');
$Country = require_once('config/Country.php');
$ProfileCfg = require_once('config/Profile.php');

// Set Index Page
define("MAIN_PAGE",true);

	$Ach = new Achievements;
	$Auth = new Account;
	$Tpl = new Template;
	$Profile = new Profile;
	$Ranking = new Ranking;
	
	// Inicializando Templates
	$Tpl->init();
	
	// Configure Selector Page
	$p = !isset($_GET['p']) || empty($_GET['p']) ? 'lista' : $_GET['p'];
	
	// P�gina n�o encontrada.
	if( !file_exists('contents/'.$p.'.php') )
	{
		$ErrorMessage = '<p>P�gina n�o encontrada.<br/> Aguarde, voc� est� sendo redirecionado...</p>';
		require_once('contents/errors/not-found.php');
		exit;
	}
	
	define("CURRENT_PAGE", $p);
	
	// Reset Vars
	$key = (isset($_GET['key'])&&trim($_GET['key'])?$_GET['key']:null);
	$type = (isset($_GET['type'])&&is_numeric($_GET['type'])?$_GET['type']:null);
	$status = (isset($_GET['status'])&&is_numeric($_GET['status'])?$_GET['status']:1);
	
	// Binds Search
	$target_value = null;
	$target_opt = null;
	$target_type = null;
	$target_ref = null;
	

	/* Include Page for URL */
	require_once('contents/'.CURRENT_PAGE.'.php');
?>