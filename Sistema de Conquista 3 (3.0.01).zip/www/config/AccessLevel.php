<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  *---------------------------------------------------------------*/
// Lista de Privil�gio de A��es
return array(
	// Acesso a P�ginas
	'ACH_NEW'			=> 99,		// N�vel para adicionar uma nova conquista.
	'ACH_EDIT'			=> 99,		// N�vel para acessar a edi��o de uma conquista.
	'ACH_REMOVE'		=> 99,		// N�vel para excluir uma Conquista.

	'GEN_CUTIN'			=> 99,		// N�vel para Gerar um Cutin.
	'ADD_TARGET'		=> 99,		// N�vel para Adicionar/Atualizar um Alvo.
	'REM_TARGET'		=> 99,		// N�vel para Remover uma recompensa.
	'CHG_TARGET'		=> 99,		// N�vel para Alterar a situa��o de um alvo.
	'ADD_REWARD'		=> 99,		// N�vel para Adicionar uma nova recompensa.
	'REM_REWARD'	 	=> 99,		// N�vel para Remover uma recompensa.
	'CHG_REWARD'		=> 99,		// N�vel para Alterar uma situa��o de uma recompensa.

	// Outras Fun��es
	'ACH_SUGGEST'		=> 99,		// N�vel para exibir Conquistas Fantasmas em Sugest�es de Formul�rio.
	'ACH_VIEW_GHOST'	=> 99,		// N�vel para exibir na lista Conquistas Fantasmas sem necess�rio ter completado.
	'ACH_VIEW_DISABLE'	=> 99,		// N�vel para exibir conquistas desativadas.
);