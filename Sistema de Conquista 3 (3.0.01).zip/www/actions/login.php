<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  .---------------------------------------------------------------.
  .                             Login                             .
  *---------------------------------------------------------------*/
// Required Files
require_once('../config/Config.php');
require_once('../lib/Sql.class.php');
require_once('../lib/Account.class.php');

	$Auth = new Account();
	
	$result = array();
	if( !isset($_POST['username']) || !trim($_POST['username']) )
		$result = array("username", utf8_encode("Voc� deve entrar com seu usu�rio."));
	else if( !isset($_POST['password']) || !trim($_POST['password']) )
		$result = array("password", utf8_encode("Voc� deve entrar com sua senha."));
	else if( substr_count($_POST['password'], ' ') )
		$result = array("password", utf8_encode("Voc� n�o pode digitar espa�o em sua senha."));
	else if( !$Auth->Login($_POST['username'], $_POST['password']) )
		$result = array("username", utf8_encode("Usu�rio ou Senha inv�lido."));
	else {
		if( isset($_POST['continue']) && trim($_POST['continue']) )
			$url = $_POST['continue'];
		else
			$url = '?p=perfil/visualizar';
		
		$result = array("success", utf8_encode("Voc� est� conectado, aguarde voc� est� sendo redirecionado!"), utf8_encode($url));
	}
	
	// Return Results
	echo json_encode($result);
	exit;
?>