<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  .---------------------------------------------------------------.
  .                    Sugest�o de Formul�rios                    .
  *---------------------------------------------------------------*/
// Required Files
require_once('../config/Config.php');
require_once('../lib/Sql.class.php');
require_once('../lib/Achievement.class.php');
require_once('../lib/Account.class.php');

	$Ach = new Achievements;
	$Auth = new Account;

	$result = "";
	if( !isset($_POST['search']) || (!is_numeric($_POST['search']) && !trim($_POST['search'])) )
		;
	else {
		$likesearch = "%".utf8_decode($_POST['search'])."%";
		switch( (int)$_POST['type'] )
		{
			case 11:
			case 15:
				$count = 0;
				$query = "SELECT map, name FROM %s WHERE name LIKE ? OR map LIKE ? ORDER BY map LIMIT %d";
				$sql = sprintf($query, "achievement_mapname", Config::$MaxSuggest);
				$sth = $Ach->dbh->prepare($sql);
				$sth->execute(array($likesearch,$likesearch));
				
				while( $r = $sth->fetch() ) {
					if( $count > Config::$MaxSuggest )
						break;
					
					$result .= "<a value=\"{$r[0]}\">{$r[1]} # {$r[0]}</a>";
					$count++;
				}
				break;
			case 12:
			case 14:
				$count = 0;
				$query = "SELECT ID, iName FROM %s WHERE ID=? OR iName LIKE ? ORDER BY ID LIMIT %d";
				$sql = sprintf($query, "mob_db", Config::$MaxSuggest);
				$sth = $Ach->dbh->prepare($sql);
				$sth->execute(array($_POST['search'],$likesearch));
				
				while( $r = $sth->fetch() ) {
					if( $count > Config::$MaxSuggest )
						break;
					
					$result .= "<a value=\"{$r[0]}\">{$r[1]} # {$r[0]}</a>";
					$count++;
				}
				
				$sql = sprintf($query, "mob_db2", Config::$MaxSuggest);
				$sth = $Ach->dbh->prepare($sql);
				$sth->execute(array($_POST['search'],$likesearch));
				
				while( $r = $sth->fetch() ) {
					if( $count > Config::$MaxSuggest )
						break;
					
					$result .= "<a value=\"{$r[0]}\">{$r[1]} # {$r[0]}</a>";
					$count++;
				}
				break;
			case 13:
			case 25:
			case 26:
			case 27:
			case 28:
			case 32:
			case 33:
			case 34:
			case 38:
			case 39:
			case 40:
			case 48:
				$count = 0;
				$query = "SELECT id, name_japanese FROM %s WHERE id=? OR name_japanese LIKE ? ORDER BY id LIMIT %d";
				$sql = sprintf($query, "item_db", Config::$MaxSuggest);
				$sth = $Ach->dbh->prepare($sql);
				$sth->execute(array($_POST['search'],$likesearch));
				
				while( $r = $sth->fetch() ) {
					if( $count > Config::$MaxSuggest )
						break;
					
					$result .= "<a value=\"{$r[0]}\">{$r[1]} # {$r[0]}</a>";
					$count++;
				}
				
				$sql = sprintf($query, "item_db2", Config::$MaxSuggest);
				$sth = $Ach->dbh->prepare($sql);
				$sth->execute(array($_POST['search'],$likesearch));
				
				while( $r = $sth->fetch() ) {
					if( $count > Config::$MaxSuggest )
						break;
					
					$result .= "<a value=\"{$r[0]}\">{$r[1]} # {$r[0]}</a>";
					$count++;
				}
				break;
			case 22:
			case 23:
			case 24:
				$JobList = require_once('../config/JobName.php');
				$count = 0;
				foreach( $JobList as $id => $name )
				{
					if( $count > Config::$MaxSuggest )
						break;
					
					if( stristr($id,$_POST['search']) || stristr($name,$_POST['search']) || $id == $_POST['search'] || $name == $_POST['search'] )
					{
						$result .= "<a value=\"{$id}\">{$name} # {$id}</a>";
						$count++;
					}
				}
				break;
			case 52:
				$count = 0;
				$sql = "SELECT id, name FROM achievement_db WHERE (id=? OR name LIKE ?)";
				if( !$Auth->CheckAccess('ADD_SUGGEST') )
					$sql .= " AND ghost=0";
				
				$sql .= sprintf(" ORDER BY id LIMIT %d", Config::$MaxSuggest);
				
				$sth = $Ach->dbh->prepare($sql);
				$sth->execute(array($_POST['search'],$likesearch));
				
				while( $r = $sth->fetch() ) {
					if( $count > Config::$MaxSuggest )
						break;
					
					$result .= "<a value=\"{$r[0]}\">{$r[1]} # {$r[0]}</a>";
					$count++;
				}
				break;
			default:
				break;
		}
	}
	
	echo empty($result)?"none":$result;
?>