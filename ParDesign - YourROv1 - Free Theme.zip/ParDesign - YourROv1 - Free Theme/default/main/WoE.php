<?php if (!defined('FLUX_ROOT')) exit; ?>

      <div id="rightbar" style="width:219px;height: 239px;">
        <div class="woesched">
          <div class="stime">
            <div class="sday">
              Everyday
            </div>
			12:00 - 10:00 PM
          </div>
		  <div class="stime">
            <div class="sday">
              Saturday
            </div>
			12:00 - 10:00 PM
          </div>
		  <div class="stime">
            <div class="sday">
              Sunday
            </div>
			12:00 - 10:00 PM
          </div>
		  
        </div>
	</div>