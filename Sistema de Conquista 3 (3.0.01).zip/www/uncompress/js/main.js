$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip({html:true});
	
	$(".go-top").click(function(e){
		e.preventDefault();
		$('html, body').animate({scrollTop: $('body').offset().top}, 'medium');
	});
			
	$(window).scroll(function(){
		if( $(this).scrollTop() > 10 && $(".go-top").is(":visible") == false )
			$(".go-top").fadeIn("slow");
		else if( $(this).scrollTop() <= 10 && $(".go-top").is(":visible") == true )
			$(".go-top").fadeOut("slow");
	});
	
	$('#change-theme').change(function() {
		$(this).submit();
	});
	
	/* Menu */
	$(".side-bar .menu-head").click(function(e) {
		e.preventDefault();
		if( $(window).width() <= 800 )
			$(".side-bar .menu").slideToggle("slow");
	});
	
	$(".alert-danger .close").bind("click", function(e) {
		$(this).parent().slideToggle("medium");
	});
	
	$(".alert-success .close").bind("click", function(e) {
		$(this).parent().slideToggle("medium");
	});
	
	$profile_sm = false;
	$(".page-profile .show-more").bind("click", function(e) {
		e.preventDefault();
		$(".page-profile .last-achievements .hidden-icon").slideToggle("fast");
		$profile_sm = $profile_sm ? false : true;
		if( $profile_sm == true )
			$(this).html("<span class=\"glyphicon glyphicon-eye-close\"></span> Ocultar");
		else
			$(this).html("<span class=\"glyphicon glyphicon-plus\"></span> Mostrar todas");
	});
	
	var screenWidth = screen.width;
	var screenHeight = screen.height;
	
	if( screenWidth < 600 ) {
		$("body").html("Este site foi feito para operar em resoluções acim de 600px de largura!");
	}
	
	//(window).resize(function() {
	//	if( $(window).width() > 800 )
	//	{
	//		if( $(".side-bar .menu").css("display") == 'none' )
	//				$(".side-bar .menu").css("display", "initial");
	//	}
	//});
});