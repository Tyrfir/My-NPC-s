/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  .---------------------------------------------------------------.
  .                        Login & Logout                         .
  *---------------------------------------------------------------*/
$(document).ready(function(){$chk_submit_send=!1,$("#form-login").submit(function(e){e.preventDefault(),$chk_submit_send||($send=$(this).serialize(),$chk_submit_send=!0,waitingDialog.show("Aguarde!",{dialogSize:"sm"}),1==$("#form-login .alert-danger").is(":visible")&&$("#form-login .alert-danger").slideToggle("medium"),1==$("#form-login .alert-success").is(":visible")&&$("#form-login .alert-success").slideToggle("medium"),$.ajax({url:"actions/login.php",type:"POST",async:!0,cache:!1,data:$send,dataType:"json",success:function(e){return waitingDialog.hide(),"success"!=e[0]?($chk_submit_send=!1,$("#"+e[0]).focus(),$("#form-login .alert-danger div").html(e[1]),$("#form-login .alert-danger").slideToggle("medium"),$("html, body").animate({scrollTop:$("#form-login .alert-danger").offset().top-80},"medium")):($("#form-login .alert-success div").html(e[1]),$("#form-login .alert-success").slideToggle("medium"),window.location=e[2]),!1},error:function(e,i,o){waitingDialog.hide(),$chk_submit_send=!1,console.log(arguments),$("#form-login .alert-danger div").html("Houve um erro inesperado!"),$("#form-login .alert-danger").slideToggle("medium"),$("html, body").animate({scrollTop:$("#form-login .alert-danger").offset().top-80},"medium")}}))})});