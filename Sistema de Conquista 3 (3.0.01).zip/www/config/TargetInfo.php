<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  *---------------------------------------------------------------*/
// Descri��es Principal de Objetivos da Conquista de acordo com seu tipo.
return array(
		0 => 'Esta � uma conquista do tipo <strong>VS Jogadores</strong>, seu principal objetivo � derrotar diversos advers�rios.<br/>Abaixo segue a lista de requisitos e seu progresso:',
		1 => 'Esta � uma conquista do tipo <strong>VS Monstros</strong>, seu principal objetivo � derrotar diversos monstros.<br/>Abaixo segue a lista de requisitos e seu progresso:',
		2 => 'Esta � uma conquista do tipo <strong>Cl�</strong>, seu principal objetivo � derrotar diversos cl�s advers�rio.<br/>Abaixo segue a lista de requisitos e seu progresso:',
		3 => 'Esta � uma conquista do tipo <strong>Batalhas Campais</strong>, seu principal objetivo � dentro das Batalhas com seu Ex�rcito.<br/>Abaixo segue a lista de requisitos e seu progresso:',
		4 => 'Esta � uma conquista do tipo <strong>Guerra do Emperium</strong>, seu principal objetivo � a mec�nica deste evento.<br/>Abaixo segue a lista de requisitos e seu progresso:',
		5 => 'Esta � uma conquista do tipo <strong>Zeny</strong>, seu principal objetivo � o seu monop�lio.<br/>Abaixo segue a lista de requisitos e seu progresso:',
		6 => 'Esta � uma conquista do tipo <strong>Tempo</strong>, seu principal objetivo � o tempo.<br/>Abaixo segue a lista de requisitos e seu progresso:',
		7 => 'Esta � uma conquista do tipo <strong>Visita de Mapas</strong>, seu principal objetivo � vagar pelos Reinos e Rep�blicas.<br/>Abaixo segue a lista de requisitos e seu progresso:',
		8 => 'Esta � uma conquista do tipo <strong>Personagens</strong>, seu principal objetivo � evoluir periodicamente seus personagens.<br/>Abaixo segue a lista de requisitos e seu progresso:',
		9 => 'Esta � uma conquista do tipo <strong>Itens</strong>, seus objetivos � negociar ou coletar itens.<br/>Abaixo segue a lista de requisitos e seu progresso:',
		'default' => 'Esta conquista � <strong>desconhecida</strong>.<br/>Abaixo segue a lista de requisitos e seu progresso:'
);