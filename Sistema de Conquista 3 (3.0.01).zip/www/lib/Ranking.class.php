<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  *---------------------------------------------------------------*/
class Ranking extends Sql {
	// Vari�veis do Banco de Dados
	public $dbh = false;
	
	// Vari�veis de Jogadores
	public $players = array();
	public $count = 0;
	public $total = 0;
	
	public function __construct() {
		$this->dbh = Sql::Connection();
		return;
	}
	
	public function Load($init = 0, $end = null, $by = "lastupdate", $order = "ASC")
	{
		if( $end === null )
			$end = Config::$rank_max_rows;
		
		// Obt�m as informa��es necess�ria.
		$sql = sprintf("SELECT `account_id`, `score`, `lastupdate` FROM `achievement_ranking` ORDER BY `score` DESC, `lastupdate` ASC LIMIT %d, %d", $init, $end);
		$sth = $this->dbh->prepare($sql);
		if( !$sth->execute() || $sth->rowCount() <= 0 )
			return 0;
		
		$count = 0;
		while( $r = $sth->fetch() )
		{
			$this->players['account_id'][] = $account_id = $r[0];
			$this->players['score'][] = $myscore = $r[1];
			$lastupdate = $r[2];
			$date = date_create($lastupdate);
			$this->players['lastupdate'][] = date_format($date, "d-m-Y");
			
			$nickname = null;
			$sex = null;
			$avatar = null;
			$local = null;
			
			$profile = $this->dbh->prepare("SELECT `nickname`, `sex`, `avatar` FROM `creativesd_profile` WHERE `account_id`=? LIMIT 1");
			if( $profile->execute(array($account_id)) && $profile->rowCount() > 0 )
			{
				$request = $profile->fetch();
				$nickname = $request[0];
				$sex = $request[1];
				$avatar = $request[2];
			}
			else {
				$this->players['avatar_url'][] = null;
				$profile = $this->dbh->prepare("SELECT `name` FROM `char` WHERE `account_id`=? ORDER BY `char_id` LIMIT 1");
				if( $profile->execute(array($account_id)) && $profile->rowCount() > 0 )
				{
					$request = $profile->fetch();
					$nickname = $request[0];
				}
				
				$profile = $this->dbh->prepare("SELECT `sex` FROM `login` WHERE `account_id`=? LIMIT 1");
				if( $profile->execute(array($account_id)) && $profile->rowCount() > 0 )
				{
					$request = $profile->fetch();
					$sex = ($request[0]=="M"?0:1);
				}
			}
			
			$this->players['nickname'][] = $nickname;
			$this->players['sex'][] = $sex;
			$this->players['avatar_url'][] = $avatar;
			
			$pos = 0;
			$position = $this->dbh->prepare("SELECT COUNT(*) FROM `achievement_ranking` WHERE `account_id`!=? AND ((`score`>=? AND `lastupdate`<?) OR (`score`>?))");
			if( $position->execute(array($account_id,$myscore,$lastupdate,$myscore)) && $sth->rowCount() > 0 )
			{
				$request = $position->fetch();
				$pos = $request[0]+1;
			}
			
			$this->players['position'][] = $pos;
			
			// Checa se o jogador esta on-line.
			$online = $this->dbh->prepare("SELECT `name`, `last_map`, `last_x`, `last_y` FROM `char` WHERE `account_id`=? AND `online`='1' LIMIT 1");
			if( $online->execute(array($account_id)) && $online->rowCount() > 0 )
			{
				$request = $online->fetch();
				$this->players['online'][] = $request;
			}
			else {
				$this->players['online'][] = array();
			}
		
			$count++;
		}
		
		// Obt�m o resultado total.
		$sth = $this->dbh->prepare("SELECT COUNT(*) FROM `achievement_ranking`");
		if( $sth->execute() && $sth->rowCount() > 0 )
		{
			$request = $sth->fetch();
			$this->total = $request[0];
		}
		
		$this->count = $count;
		return $this->total;
	}
	
	// Destr�i a conex�o com o banco de dados.
	public function __destruct() {
		$this->dbh = null;
	}
}
?>