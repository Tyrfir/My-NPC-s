CREATE TABLE IF NOT EXISTS `achievement_db` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL DEFAULT '',
  `cutin` VARCHAR(50) NOT NULL DEFAULT '',
  `icon` VARCHAR(50) NOT NULL DEFAULT 'c00',
  `desc` VARCHAR(200) NOT NULL DEFAULT 'Sem Descri��o',
  `type` SMALLINT(6) NOT NULL DEFAULT '0',
  `ghost` SMALLINT(6) NOT NULL DEFAULT '0',
  `status` SMALLINT(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=300;

-- Type:
--	0 -> Vs Jogadores
--	1 -> Vs Monstros
--	2 -> Cl�s
--	3 -> Batalhas Campais
--	4 -> Guerra do Emperium
--	5 -> Zeny
--	6 -> Tempo
--	7 -> Visita de Mapas
--	8 -> Evolu��o do Personagem (Classe, BaseLevel, JobLevel)
--	9 -> Itens
--
-- Reward:
--	0 -> Aleat�rio
--	1 -> Todos Itens configurados.

INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(1, 'O Primeiro de Muitos', 'conquista_01', 'c01', 'Mate um Poring sem d� e sem piedade.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(2, 'Todos v�o para o c�u', 'conquista_02', 'c02', 'Mate 1.000 Porings.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(3, 'O Primeiro jam�is ser� esquecido', 'conquista_03', 'c03', 'Derrote um MvP qualquer.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(4, 'Mem�ria de um Grande Her�i', 'conquista_04', 'c04', 'Derrote o MvP Thanatos na Torre de Thanatos.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(5, 'Bode morto n�o fala', 'conquista_05', 'c05', 'Derrote o MvP Bafom� no Labirinto da Floresta.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(6, 'Imp�rio a 7 palmos abaixo da terra', 'conquista_06', 'c06', 'Derrote o MvP Imperador Morroc na Ruptura Dimensional.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(7, 'Iniciante no PvP', 'conquista_07', 'c07', 'Derrote 250 inimigos no PvP.', 0, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(8, 'Amador no PvP', 'conquista_08', 'c08', 'Derrote 500 inimigos no PvP.', 0, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(9, 'Mestre no PvP', 'conquista_09', 'c09', 'Derrote 1.000 inimigos no PvP.', 0, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(10, 'Iniciante de Guerra', 'conquista_10', 'c07', 'Derrote 250 inimigos de outro Cl�.', 2, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(11, 'Amador de Guerra', 'conquista_11', 'c08', 'Derrote 500 inimigos de outro Cl�.', 2, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(12, 'Veterano de Guerra', 'conquista_12', 'c09', 'Derrote 1.000 inimigos de outro Cl�.', 2, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(13, 'Iniciante de Batalhas', 'conquista_13', 'c07', 'Derrote 250 inimigos do Ex�rcito Advers�rio nas Batalhas Campais.', 3, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(14, 'Amador de Batalhas', 'conquista_14', 'c08', 'Derrote 500 inimigos do Ex�rcito Advers�rio nas Batalhas Campais.', 3, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(15, 'Veterano de Batalhas', 'conquista_15', 'c09', 'Derrote 1.000 inimigos do Ex�rcito Advers�rio nas Batalhas Campais.', 3, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(16, 'Legion�rio Intermedi�rio', 'conquista_16', 'c13', 'Ven�a 100 Batalhas Campais.', 3, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(17, 'Legion�rio Avan�ado', 'conquista_17', 'c13', 'Ven�a 200 Batalhas Campais.', 3, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(18, 'Legion�rio Veterano', 'conquista_18', 'c13', 'Ven�a 500 Batalhas Campais.', 3, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(19, 'Lembro como fosse ontem', 'conquista_19', 'c10', 'Destrua um Emperium durante a Guerra.', 4, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(20, 'Um verdadeiro quebrador de Emperium', 'conquista_20', 'c10', 'Destrua 100 vezes o Emperium durante a Guerra.', 4, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(21, 'Meu primeiro milh�o', 'conquista_21', 'c15', 'Ajunte 1.000.000 de Zenys.', 5, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(22, 'Consumidor de Primeira Classe', 'conquista_22', 'c15', 'Gaste 250.000 Zenys em negocia��es.', 5, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(23, 'Consumidor Avan�ado', 'conquista_23', 'c15', 'Gaste 500.000 zenys em negocia��es.', 5, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(24, 'Consumidor Abusivo', 'conquista_24', 'c15', 'Gaste 1.000.000 de Zenys em negocia��es.', 5, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(25, 'Numa tacada s�!', 'conquista_25', 'c15', 'Gaste 700.000 zenys de uma s� vez em negocia��es.', 5, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(26, 'Iniciante em Runas Guardi�s', 'conquista_26', 'c11', 'Construa 5 Runas Guardi�s durante a Guerra do Emperium Segunda Edi��o.', 4, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(27, 'Intermedi�rio em Runas Guardi�s', 'conquista_27', 'c11', 'Construa 25 Runas Guardi�s durante a Guerra do Emperium Segunda Edi��o.', 4, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(28, 'Avan�ado em Runas Guardi�s', 'conquista_28', 'c11', 'Construa 50 Runas Guardi�s durante a Guerra do Emperium Segunda Edi��o.', 4, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(29, 'Construtor de Barreiras', 'conquista_29', 'c12', 'Construa 5 Barricadas durante a Guerra do Emperium Segunda Edi��o.', 4, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(30, 'Construtor de Fortes', 'conquista_30', 'c12', 'Construa 25 Barricadas durante a Guerra do Emperium Segunda Edi��o.', 4, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(31, 'Construtor de Fortalezas', 'conquista_31', 'c12', 'Construa 50 Barricadas durante a Guerra do Emperium Segunda Edi��o.', 4, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(32, 'Acordado sim, dormindo nunca!', 'conquista_32', 'c14', 'Esteja conectado no servidor exatamente as 04:00hrs madrugada.', 6, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(33, 'Jogador Iniciante', 'conquista_33', 'c14', 'Tenha 42horas completas de jogo.', 6, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(34, 'Jogador Intermedi�rio', 'conquista_34', 'c14', 'Tenha 84horas completas de jogo.', 6, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(35, 'Jogador Avan�ado', 'conquista_35', 'c14', 'Tenha 168horas completas de jogo.', 6, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(36, 'Um feio a menos na terra', 'conquista_36', 'c16', 'Derrote o MvP Orc Her�i nos Arredores de Geffen (03).', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(37, 'Barata boa � barata morta', 'conquista_37', 'c17', 'Derrote o MvP Besouro Ladr�o Dourado nos Esgoto de Prontera (04).', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(38, 'Mais ele estava engolindo uma garotinha', 'conquista_38', 'c18', 'Derrote o MvP Maya no Formigueiro Infernal (02).', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(39, 'O mais feio que eu j� vi', 'conquista_39', 'c19', 'Derrote o MvP Senhor dos Orcs nos Arredores de Geffen (10).', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(40, 'Caximbo faz mal a sa�de', 'conquista_40', 'c20', 'Derrote o MvP Eddga na Floresta de Payon (10).', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(41, 'Ou sua coroa ou a vida!', 'conquista_41', 'c21', 'Derrote o MvP Os�ris Dentro da Pir�mide (04).', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(42, 'De p� ou sentado tanto faz...', 'conquista_42', 'c22', 'Derrote o MvP Amon Ra Dentro da Pir�mide (06).', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(43, 'Ta rindo do que?', 'conquista_43', 'c23', 'Derrote o MvP Freeoni no Deserto Sograt (17).', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(44, 'O Ca�a Vampiro', 'conquista_44', 'c24', 'Derrote o MvP Dracula no Calabou�o de Geffen (02).', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(45, 'Uma c�pia mal feita', 'conquista_45', 'c25', 'Derrote o MvP Doppelganger em Geffenia (01).', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(46, 'Por um pote de mel!', 'conquista_46', 'c26', 'Derrote o MvP Abelha Rainha no Monte Mjolnir (04).', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(47, 'Lugar de m�mia � no museu!', 'conquista_47', 'c27', 'Derrote o MvP Fara� na Esfinge (05).', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(48, 'Pirataria � Crime!', 'conquista_48', 'c28', 'Derrote o MvP Drake no Navio Fantasma (02).', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(49, 'Cade o Papai Noel', 'conquista_49', 'c29', 'Derrote o MvP Cavaleiro da Tempestade na Sala de Constru��o de Brinquedos.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(50, 'Brasileiro Nato!', 'conquista_50', 'c30', 'Derrote o MvP Boitat� nas Profundezas das Cataratas.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(51, 'Conduzido ao Sal�o dos Mortos', 'conquista_51', 'c31', 'Derrote o MvP Valqu�ria Randgris no Santu�rio de Odin.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(52, 'Nada de senhor e tudo de morto!', 'conquista_52', 'c32', 'Derrote o MvP Senhor dos Mortos em Niflheim.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(53, 'Iluminando o mundo', 'conquista_53', 'c33', 'Derrote o MvP Senhor das Trevas no Cemit�rio de Glast Heim.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(54, 'Viajante de Rune-Midgard', 'conquista_54', 'c34', 'Visite todas as cidades de Rune-Midgard.', 7, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(55, 'Viajante de Rep�blica', 'conquista_55', 'c34', 'Visite todas as cidades da Rep�blica de Schwarzwald.', 7, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(56, 'Viajante de Na��o', 'conquista_56', 'c34', 'Visite todas as cidades da Na��o de Arunafeltz.', 7, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(57, 'Viajante de Regi�es', 'conquista_57', 'c34', 'Visite todas as Regi�es desassociadas.', 7, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(58, 'Cora��o de Gelo', 'conquista_58', 'c35', 'Derrote o MvP Hatii nos Arredores de Lutie.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(59, 'Espada Mole Casca dura tanto bate at� que fura', 'conquista_59', 'c36', 'Derrote o MvP General Tartaruga no Pal�cio da Ilha da Tartaruga.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(60, 'At� o Sol nascer...', 'conquista_60', 'c37', 'Derrote o MvP Flor do Luar no Calabou�o de Payon.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(61, 'Limpeza em Prontera', 'conquista_61', 'c38', 'Derrote os MvPs Bafom� e Besouro Ladr�o em seu habitar.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(62, 'Limpeza em Morroc', 'conquista_62', 'c39', 'Derrote os MvPs Amon Ra, Far�o, Freeoni, Maya e Os�ris em seus habitar.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(63, 'Limpeza em Geffen', 'conquista_63', 'c40', 'Derrote os MvPs Doppelganger, Dr�cula, Orc Her�i e Senhor dos Orcs em seus habitar.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(64, 'Limpeza em Payon', 'conquista_64', 'c41', 'Derrote os MvPs Eddga e Flor do Luar em seus habitar.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(65, 'Limpeza em Lutie', 'conquista_65', 'c42', 'Derrote os MvPs Cavaleiro da Tempestade e Hatii em seus habitar.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(66, 'Limpeza em Alberta', 'conquista_66', 'c43', 'Derrote os MvPs Drake e General Tartagura em seus habitar.', 1, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(67, 'De passo em passo', 'conquista_67', 'c44', 'Ganhe um N�vel de Base ou de Classe no Jogo.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(68, 'Estou pronto!', 'conquista_68', 'c45', 'Alcance o N�vel 9 de Classe como Aprendiz.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(69, 'Ao infinito e Al�m!', 'conquista_69', 'c44', 'Alcance o N�vel 99 de Base com qualquer Classe.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(70, 'Mestre em Habilidades', 'conquista_70', 'c44', 'Alcance o N�vel 50 de Classe com qualquer Classe.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(71, 'No Caminho das Espadas', 'conquista_71', 'c46', 'Torne-se um Espadachim.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(72, 'No Caminho da M�gia', 'conquista_72', 'c47', 'Torne-se um Mago.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(73, 'No Caminho das Flechas', 'conquista_73', 'c48', 'Torne-se um Arqueiro.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(74, 'No Caminho do Com�rcio', 'conquista_74', 'c49', 'Torne-se um Mercador.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(75, 'No Caminho das Ruas', 'conquista_75', 'c50', 'Torne-se um Gatuno.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(76, 'No Caminho da Santidade', 'conquista_76', 'c51', 'Torne-se um Novi�o.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(77, 'Um verdadeiro Cavaleiro', 'conquista_77', 'c52', 'Torne-se um Cavaleiro.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(78, 'Expresso M�gico', 'conquista_78', 'c53', 'Torne-se um Bruxo.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(79, 'Entre a Ca�a e o Ca�ador', 'conquista_79', 'c54', 'Torne-se um Ca�ador.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(80, 'Engenheiro de Armas', 'conquista_80', 'c55', 'Torne-se um Ferreiro.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(81, 'Guerreiro das Sombras', 'conquista_81', 'c56', 'Torne-se um Mercen�rio.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(82, 'Santo Graal', 'conquista_82', 'c57', 'Torne-se um Sacerdote.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(83, 'Escudo Absoluto', 'conquista_83', 'c58', 'Torne-se um Templ�rio.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(84, 'Aprendizagem', 'conquista_84', 'c59', 'Torne-se um S�bio.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(85, 'Ritimo da M�sica', 'conquista_85', 'c60', 'Torne-se um Bardo ou Odalisca.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(86, 'Troca Equivalente', 'conquista_86', 'c61', 'Torne-se um Alquimista.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(87, 'Miliante', 'conquista_87', 'c62', 'Torne-se um Arruaceiro.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(88, 'Dominio da For�a', 'conquista_88', 'c63', 'Torne-se um Monge.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(89, 'Anjo da Guarda!', 'conquista_89', 'c45', 'Torne-se um Super Aprendiz.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(90, 'Mestre em Ninjutsu', 'conquista_90', 'c64', 'Torne-se um Ninja.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(91, 'Pistoleiro', 'conquista_91', 'c65', 'Torne-se um Justiceiro.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(92, 'Grande Guerreiro', 'conquista_92', 'c66', 'Torne-se um Lorde.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(93, 'Mestre Arcano', 'conquista_93', 'c67', 'Torne-se um Arquimago.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(94, 'Atirador de Elite', 'conquista_94', 'c68', 'Torne-se um Atirador de Elite.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(95, 'Senhor das Armas', 'conquista_95', 'c69', 'Torne-se um Mestre Ferreiro.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(96, 'Executor', 'conquista_96', 'c70', 'Torne-se um Algoz.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(97, 'Porto Seguro', 'conquista_97', 'c71', 'Torne-se um Sumo-Sacerdote.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(98, 'Juramento da Devo��o', 'conquista_98', 'c72', 'Torne-se um Paladino.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(99, 'Profundo Conhecimento', 'conquista_99', 'c73', 'Torne-se um Professor.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(100, 'Nota Certa', 'conquista_100', 'c74', 'Torne-se um Menestrel ou uma Cigana.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(101, 'For�a Vital', 'conquista_101', 'c75', 'Torne-se um Criador.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(102, 'Causa da Desordem', 'conquista_102', 'c76', 'Torne-se um Desordeiro.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(103, 'Esp�rito Ardente', 'conquista_103', 'c77', 'Torne-se um Mestre.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(104, 'Taekwondo', 'conquista_104', 'c78', 'Torne-se um Taekwon.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(105, 'Compreens�o da Alma', 'conquista_105', 'c79', 'Torne-se um Espiritualista.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(106, 'Mestre das Artes Marciais', 'conquista_106', 'c80', 'Torne-se um Mestre Taekwon.', 8, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(107, 'Dando o troco', 'conquista_107', 'c01', 'Colete 500 Jellopy de um Poring.', 9, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(108, 'Estamos quites', 'conquista_108', 'c01', 'Colete 1.000 Jellopy de um Poring.', 9, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(109, 'Consumidor de Po��es', 'conquista_109', 'c81', 'Mostre que voc� � um verdadeiro Consumidor de Po��es.', 9, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(110, 'Negociador de Utilidades', 'conquista_110', 'c82', 'Compre alguns itens em Lojas de Utilidades.', 9, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(111, 'Iniciante no Com�rcio da Comunidade', 'conquista_111', 'c82', 'Compre 10 itens em Lojas de Jogadores.', 9, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(112, 'Intermedi�rio no Com�rcio da Comunidade', 'conquista_112', 'c82', 'Compre 50 itens em Lojas de Jogadores.', 9, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(113, 'Avan�ado no Com�rcio da Comunidade', 'conquista_113', 'c82', 'Compre 100 itens em Lojas de Jogadores.', 9, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(114, 'Entrando no Com�rcio da Comunidade', 'conquista_114', 'c82', 'Venda 100 itens para Jogadores.', 9, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(115, 'Contribuidor no Com�rcio da Comunidade', 'conquista_115', 'c82', 'Venda 500 itens para Jogadores.', 9, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(116, 'Perito no Com�rcio da Comunidade', 'conquista_116', 'c82', 'Venda 1.000 itens para Jogadores.', 9, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(117, 'Iniciante em Negocia��o', 'conquista_117', 'c82', 'Troque 5 itens com outros jogadores.', 9, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(118, 'Intermedi�rio em Negocia��o', 'conquista_118', 'c82', 'Troque 15 itens com outros jogadores.', 9, 0, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `ghost`, `status`) VALUES(119, 'Avan�ado em Negocia��o', 'conquista_119', 'c82', 'Troque 45 itens com outros jogadores.', 9, 0, 1);

ALTER TABLE `achievement_db` AUTO_INCREMENT=300;

--
-- type:
--	 0 -> O Alvo � um Jogador qualquer.
--	 1 -> O Alvo � um Jogador de outro Cl�.
--	 2 -> O Alvo � um Jogador de outro Ex�rcito (BG).
--	 3 -> O Alvo � vencer as Batalhas Campais (BG).
--	 4 -> O Alvo � destru�r o Emperium.
--	 5 -> O Alvo � ajuntar uma quantidade de Zeny.
--	 6 -> O Alvo � gastar uma quantidade de Zeny em progresso.
--	 7 -> O Alvo � gastar uma quantidade de Zeny em uma unica vez.
--	 8 -> O Alvo � constru��o de Runas Guardi�.
--	 9 -> O Alvo � constru��o de Barricadas.
--	10 -> O Alvo � um Tempo.
--	11 -> O Alvo � visitar o mapa.
--	12 -> O Alvo � um monstro.
--	13 -> O Alvo � pegar um item de um monstro.
--	14 -> O Alvo item tem que estar neste determinado monstro.
--	15 -> O Alvo � estar neste determinado mapa.
--	16 -> O Alvo � qualquer MvP.
--	17 -> O Alvo � um hor�rio determinado. (hh:mm)
--	18 -> O Alvo � ganhar uma quantidade de Zeny de uma unica vez.
--	19 -> O Alvo � um N�vel de Base.
--	20 -> O Alvo � um N�vel de Classe.
--	21 -> O Alvo � um N�vel de Base ou Classe.
--	22 -> O Alvo � estar em uma Classe.
--	23 -> O Alvo � alcan�ar uma determinada Classe.
--	24 -> O Alvo jogador deve estar em uma determinada Classe.
--	25 -> O Alvo � utilizar um determinado item.
--
--	26 -> O Alvo � comprar um determinado item no npc.
--	27 -> O Alvo � comprar um determinado item em vendas de jogadores.
--	28 -> O Alvo � comprar um determinado item em vendas de jogadores ou npc.
--	29 -> O Alvo � comprar qualquer item no npc.
--	30 -> O Alvo � comprar qualquer item em vendas de jogadores.
--	31 -> O Alvo � comprar qualquer item em vendas de jogadores ou npc.
--
--	32 -> O Alvo � vender um determinado item em npcs.
--	33 -> O Alvo � vender um determinado item para jogadores.
--	34 -> O Alvo � vender um determinado item para jogadores ou npc.
--	35 -> O Alvo � vender qualquer item no npc.
--	36 -> O Alvo � vender qualquer item em vendas de jogadores.
--	37 -> O Alvo � vender qualquer item em vendas de jogadores ou npc.
--
--	38 -> O Alvo � pegar um determinado item em uma troca.
--	39 -> O Alvo � dar um determinado item em uma troca.
--	40 -> O Alvo � pegar ou dar um determinado item em uma troca.
--	41 -> O Alvo � pegar qualquer item em uma troca.
--	42 -> O Alvo � dar qualquer item em uma troca.
--	43 -> O Alvo � pegar ou dar qualquer item em uma troca.
--	44 -> O Alvo � pegar uma determinada quantidade de zeny em trocas.
--	45 -> O Alvo � dar uma determina quantidade de zeny em trocas.
--	46 -> O Alvo � pegar uma determinada quantidade de zeny em trocas em uma �nica vez.
--	47 -> O Alvo � dar uma determinada quantidade de zeny em trocas em uma �nica vez.
--
--	51 -> Conquista deve ser terminada em x segundos.
--	52 -> O Alvo � completar uma determinada conquista.
--

CREATE TABLE IF NOT EXISTS `achievement_req` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `achievement_id` INT(11) UNSIGNED NOT NULL DEFAULT '0',
  `type` SMALLINT(6) NOT NULL DEFAULT '0',
  `target` VARCHAR(50) NOT NULL DEFAULT 'no',
  `value` INT(11) NOT NULL DEFAULT '0',
  `status` SMALLINT(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`achievement_id`, `type`, `target`),
  KEY `achievement_id` (`achievement_id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM;

INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (1, 12, '1002', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (2, 12, '1002', 1000, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (3, 16, 'mvp', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (4, 12, '1708', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (4, 15, 'thana_boss', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (5, 12, '1039', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (5, 15, 'prt_maze03', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (6, 12, '1916', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (6, 15, 'moc_fild21', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (7, 0, 'player', 250, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (8, 0, 'player', 500, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (9, 0, 'player', 1000, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (10, 1, 'player', 250, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (11, 1, 'player', 500, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (12, 1, 'player', 1000, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (13, 2, 'player', 250, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (14, 2, 'player', 500, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (15, 2, 'player', 1000, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (16, 3, 'battleground', 100, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (17, 3, 'battleground', 200, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (18, 3, 'battleground', 500, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (19, 4, 'emperium', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (20, 4, 'emperium', 100, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (21, 5, 'zeny', 1000000, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (22, 6, 'zeny', 250000, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (23, 6, 'zeny', 500000, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (24, 6, 'zeny', 1000000, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (25, 7, 'zeny', 700000, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (26, 8, 'runestone', 5, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (27, 8, 'runestone', 25, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (28, 8, 'runestone', 50, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (29, 9, 'barricade', 5, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (30, 9, 'barricade', 25, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (31, 9, 'barricade', 50, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (32, 17, '04:00', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (33, 10, 'timer', 2520, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (34, 10, 'timer', 5040, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (35, 10, 'timer', 10080, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (36, 12, '1087', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (36, 15, 'gef_fild03', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (37, 12, '1086', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (37, 15, 'prt_sewb4', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (38, 15, 'anthell02', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (38, 12, '1147', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (39, 15, 'gef_fild10', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (39, 12, '1190', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (40, 15, 'gef_fild10', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (40, 12, '1115', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (41, 15, 'moc_pryd04', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (41, 12, '1038', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (42, 15, 'moc_pryd06', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (42, 12, '1151', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (43, 15, 'moc_fild17', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (43, 12, '1159', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (44, 15, 'gef_dun01', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (44, 12, '1389', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (45, 15, 'gef_dun02', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (45, 12, '1046', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (46, 15, 'mjolnir_04', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (46, 12, '1059', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (47, 15, 'in_sphinx5', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (47, 12, '1157', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (48, 15, 'treasure02', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (48, 12, '1112', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (49, 15, 'xmas_dun02', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (49, 12, '1251', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (50, 15, 'bra_dun02', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (50, 12, '2068', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (51, 12, '1751', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (51, 15, 'odin_tem03', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (52, 15, 'niflheim', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (52, 12, '1373', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (53, 15, 'gl_chyard', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (53, 12, '1272', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (54, 11, 'prontera', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (54, 11, 'izlude', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (54, 11, 'geffen', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (54, 11, 'payon', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (54, 11, 'alberta', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (54, 11, 'morocc', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (54, 11, 'xmas', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (54, 11, 'comodo', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (54, 11, 'glast_01', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (54, 11, 'prt_monk', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (54, 11, 'umbala', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (54, 11, 'niflheim', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (54, 11, 'jawaii', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (55, 11, 'yuno', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (55, 11, 'einbroch', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (55, 11, 'lighthalzen', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (55, 11, 'hugel', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (56, 11, 'rachel', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (56, 11, 'veins', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (56, 11, 'nameless_i', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (57, 11, 'amatsu', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (57, 11, 'gonryun', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (57, 11, 'ayothaya', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (57, 11, 'louyang', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (57, 11, 'moscovia', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (57, 11, 'brasilis', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (57, 11, 'dewata', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (58, 15, 'xmas_fild01', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (58, 12, '1252', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (59, 15, 'tur_dun04', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (59, 12, '1312', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (60, 15, 'pay_dun04', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (60, 12, '1150', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (61, 15, 'prt_maze03', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (61, 15, 'prt_sewb4', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (61, 12, '1039', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (61, 12, '1086', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (62, 15, 'moc_pryd04', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (62, 12, '1038', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (62, 12, '1511', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (62, 15, 'moc_pryd06', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (62, 12, '1157', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (62, 15, 'in_sphinx5', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (62, 12, '1147', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (62, 15, 'anthell02', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (62, 12, '1159', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (62, 15, 'moc_fild17', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (63, 12, '1046', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (63, 15, 'gef_dun02', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (63, 12, '1389', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (63, 15, 'gef_dun01', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (63, 12, '1087', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (63, 15, 'gef_fild03', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (63, 12, '1190', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (63, 15, 'gef_fild10', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (64, 12, '1115', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (64, 15, 'pay_fild10', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (64, 12, '1150', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (64, 15, 'pay_dun04', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (65, 12, '1251', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (65, 15, 'xmas_dun02', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (65, 12, '1252', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (65, 15, 'xmas_fild01', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (66, 12, '1112', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (66, 15, 'treasure02', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (66, 12, '1312', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (66, 15, 'tur_dun04', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (67, 21, 'AnyLevel', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (68, 20, 'JobLevel', 9, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (68, 22, '0', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (69, 19, 'BaseLevel', 99, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (70, 20, 'JobLevel', 50, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (71, 22, '1', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (71, 22, '4002', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (71, 22, '4024', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (72, 22, '2', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (72, 22, '4003', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (72, 22, '4025', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (73, 22, '3', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (73, 22, '4004', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (73, 22, '4026', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (74, 22, '5', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (74, 22, '4006', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (74, 22, '4028', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (75, 22, '6', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (75, 22, '4007', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (75, 22, '4029', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (76, 22, '4', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (76, 22, '4005', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (76, 22, '4027', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (77, 22, '7', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (77, 22, '13', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (77, 22, '4030', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (77, 22, '4036', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (78, 22, '9', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (78, 22, '4032', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (79, 22, '11', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (79, 22, '4034', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (80, 22, '10', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (80, 22, '4033', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (81, 22, '12', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (81, 22, '4035', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (82, 22, '8', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (82, 22, '4031', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (83, 22, '15', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (83, 22, '21', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (83, 22, '4037', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (83, 22, '4044', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (84, 22, '16', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (84, 22, '4039', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (85, 22, '19', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (85, 22, '4042', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (85, 22, '20', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (85, 22, '4043', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (86, 22, '18', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (86, 22, '4041', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (87, 22, '17', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (87, 22, '4040', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (88, 22, '15', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (88, 22, '4038', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (89, 22, '23', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (89, 22, '4045', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (90, 22, '25', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (91, 22, '24', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (92, 22, '4008', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (92, 22, '4014', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (93, 22, '4010', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (94, 22, '4012', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (95, 22, '4011', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (96, 22, '4013', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (97, 22, '4009', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (98, 22, '4015', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (98, 22, '4022', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (99, 22, '4017', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (100, 22, '4020', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (100, 22, '4021', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (101, 22, '4019', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (102, 22, '4018', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (103, 22, '4016', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (104, 22, '4046', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (105, 22, '4049', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (106, 22, '4047', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (106, 22, '4048', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (107, 13, '909', 500, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (107, 14, '1002', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (108, 13, '909', 1000, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (108, 14, '1002', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (109, 25, '501', 10, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (109, 25, '502', 10, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (109, 25, '504', 10, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (109, 25, '505', 10, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (109, 25, '503', 3, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (109, 25, '506', 3, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (109, 25, '545', 3, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (109, 25, '546', 3, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (109, 25, '547', 3, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (110, 26, '611', 30, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (110, 26, '601', 20, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (110, 26, '602', 20, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (111, 30, 'anyitem', 10, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (112, 30, 'anyitem', 50, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (113, 30, 'anyitem', 100, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (114, 36, 'anyitem', 100, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (115, 36, 'anyitem', 500, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (116, 36, 'anyitem', 1000, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (117, 42, 'anyitem', 5, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (118, 42, 'anyitem', 15, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (119, 42, 'anyitem', 45, 1);

--
-- type:
--	0: Item
--	1: Zeny
--	2: Cash Point
--	3: Kafra Point
--	4: BaseExp
--	5: JobExp
--	6: Level
--	7: JobLevel
--	8: StatusUP2
--	{
--		target:
--			0 -> bStr
--			1 -> bVit
--			2 -> bInt
--			3 -> bAgi
--			4 -> bDex
--			5 -> bLuk
--	}
CREATE TABLE IF NOT EXISTS `achievement_rewards` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `achievement_id` INT(11) unsigned NOT NULL DEFAULT '0',
  `object` VARCHAR(32) NOT NULL DEFAULT '',
  `value` INT(11) NOT NULL DEFAULT '0',
  `type` INT(1) unsigned NOT NULL DEFAULT '0',
  `rate` SMALLINT(9) UNSIGNED NOT NULL DEFAULT '0',
  `desc` VARCHAR(32) NOT NULL DEFAULT '',
  `status` SMALLINT(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `achievement_id` (`achievement_id`)
) ENGINE=MyISAM;

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (1, '501', 150, 0, 'Po��o Vermelha', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (1, 'BaseExp', 10000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (1, 'JobExp', 10000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (2, '14232', 1, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (2, 'BaseExp', 15000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (2, 'JobExp', 10000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (3, '14232', 1, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (3, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (3, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (4, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (4, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (4, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (5, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (5, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (5, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (6, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (6, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (6, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (7, '610', 15, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (7, 'BaseExp', 35000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (7, 'JobExp', 25000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (8, '610', 20, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (8, 'BaseExp', 40000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (8, 'JobExp', 30000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (9, '610', 25, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (9, 'BaseExp', 45000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (9, 'JobExp', 35000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (10, '610', 15, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (10, 'BaseExp', 35000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (10, 'JobExp', 25000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (11, '610', 20, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (11, 'BaseExp', 40000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (11, 'JobExp', 30000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (12, '610', 25, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (12, 'BaseExp', 45000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (12, 'JobExp', 35000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (13, '610', 15, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (13, 'BaseExp', 35000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (13, 'JobExp', 25000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (14, '610', 20, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (14, 'BaseExp', 40000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (14, 'JobExp', 30000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (15, '610', 25, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (15, 'BaseExp', 45000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (15, 'JobExp', 35000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (16, 'BaseExp', 80000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (16, 'JobExp', 75000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (17, 'BaseExp', 90000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (17, 'JobExp', 85000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (18, 'BaseExp', 100000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (18, 'JobExp', 95000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (19, 'BaseExp', 100000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (19, 'JobExp', 95000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (19, '#CASHPOINTS', 10000, 1, 'Cash', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (20, 'BaseExp', 100000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (20, 'JobExp', 95000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (20, '#CASHPOINTS', 25000, 1, 'Cash', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (21, 'BaseExp', 100000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (21, 'JobExp', 95000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (21, '#CASHPOINTS', 10000, 1, 'Cash', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (22, 'BaseExp', 40000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (22, 'JobExp', 35000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (22, 'Zeny', 125000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (23, 'BaseExp', 45000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (23, 'JobExp', 40000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (23, 'Zeny', 250000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (24, 'BaseExp', 50000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (24, 'JobExp', 45000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (24, 'Zeny', 500000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (25, 'BaseExp', 45000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (25, 'JobExp', 40000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (25, 'Zeny', 375000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (26, 'BaseExp', 80000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (26, 'JobExp', 75000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (27, 'BaseExp', 90000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (27, 'JobExp', 85000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (28, 'BaseExp', 80000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (28, 'JobExp', 75000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (28, '#CASHPOINTS', 25000, 1, 'Cash', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (29, 'BaseExp', 80000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (29, 'JobExp', 75000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (30, 'BaseExp', 90000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (30, 'JobExp', 85000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (31, 'BaseExp', 80000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (31, 'JobExp', 75000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (31, '#CASHPOINTS', 25000, 1, 'Cash', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (32, 'BaseExp', 80000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (32, 'JobExp', 75000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (18, '610', 25, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (33, 'BaseExp', 80000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (33, 'JobExp', 75000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (17, '610', 25, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (34, 'BaseExp', 80000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (34, 'JobExp', 75000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (16, '610', 25, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (35, 'BaseExp', 80000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (35, 'JobExp', 75000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (35, '#CASHPOINTS', 25000, 1, 'Cash', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (35, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (36, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (36, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (36, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (37, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (37, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (37, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (38, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (38, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (38, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (39, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (39, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (39, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (40, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (40, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (40, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (41, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (41, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (41, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (42, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (42, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (42, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (43, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (43, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (43, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (44, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (44, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (44, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (45, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (45, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (45, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (46, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (46, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (46, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (47, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (47, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (47, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (48, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (48, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (48, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (49, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (49, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (49, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (50, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (50, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (50, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (51, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (51, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (51, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (52, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (52, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (52, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (53, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (53, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (53, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (54, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (54, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (54, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (55, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (55, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (55, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (56, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (56, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (56, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (57, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (57, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (57, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (58, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (58, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (58, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (59, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (59, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (59, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (60, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (60, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (60, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (61, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (61, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (61, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (62, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (62, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (62, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (63, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (63, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (63, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (64, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (64, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (64, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (65, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (65, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (65, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (66, '610', 10, 0, 'Folha de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (66, 'BaseExp', 25000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (66, 'JobExp', 15000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (67, 'BaseExp', 10000, 1, 'Experi�ncia de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (67, 'JobExp', 10000, 1, 'Experi�ncia de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (68, '14232', 2, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (69, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (70, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (71, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (71, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (71, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (71, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (71, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (72, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (72, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (72, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (72, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (72, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (73, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (73, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (73, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (73, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (73, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (74, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (74, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (74, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (74, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (74, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (75, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (75, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (75, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (75, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (75, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (76, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (76, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (76, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (76, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (76, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (77, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (77, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (77, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (77, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (77, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (78, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (78, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (78, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (78, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (78, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (79, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (79, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (79, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (79, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (79, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (80, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (80, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (80, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (80, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (80, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (81, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (81, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (81, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (81, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (81, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (82, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (82, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (82, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (82, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (82, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (83, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (83, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (83, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (83, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (83, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (84, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (84, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (84, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (84, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (84, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (85, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (85, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (85, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (85, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (85, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (86, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (86, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (86, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (86, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (86, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (87, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (87, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (87, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (87, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (87, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (88, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (88, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (88, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (88, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (88, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (89, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (89, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (89, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (89, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (89, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (90, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (90, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (90, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (90, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (90, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (91, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (91, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (91, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (91, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (91, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (92, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (92, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (92, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (92, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (92, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (93, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (93, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (93, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (93, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (93, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (94, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (94, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (94, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (94, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (94, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (95, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (95, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (95, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (95, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (95, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (96, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (96, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (96, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (96, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (96, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (97, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (97, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (97, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (97, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (97, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (98, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (98, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (98, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (98, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (98, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (99, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (99, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (99, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (99, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (99, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (100, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (100, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (100, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (100, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (100, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (101, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (101, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (101, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (101, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (101, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (102, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (102, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (102, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (102, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (102, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (103, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (103, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (103, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (103, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (103, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (104, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (104, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (104, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (104, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (104, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (105, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (105, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (105, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (105, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (105, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (106, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (106, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (106, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (106, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (106, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (107, 'Zeny', 100000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (108, 'Zeny', 100000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (109, '503', 20, 0, 'Po��o Amarela', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (109, '502', 20, 0, 'Po��o Laranja', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (109, '501', 20, 0, 'Po��o Vermelha', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (109, '504', 20, 0, 'Po��o Branca', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (109, '505', 20, 0, 'Po��o Azul', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (109, '506', 20, 0, 'Po��o Verde', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (109, '545', 20, 0, 'Po��o Vermelha Compacta', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (109, '546', 20, 0, 'Po��o Amarela Compacta', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (109, '547', 20, 0, 'Po��o Branca Compacta', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (110, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (110, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (110, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (110, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (111, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (111, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (111, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (111, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (112, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (112, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (112, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (112, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (113, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (113, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (113, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (113, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (114, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (114, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (114, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (114, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (115, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (115, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (115, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (115, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (116, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (116, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (116, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (116, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (117, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (117, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (117, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (117, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (118, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (118, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (118, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (118, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (119, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (119, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (119, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (119, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );


CREATE TABLE IF NOT EXISTS `achievement_data` (
  `account_id` INT(11) UNSIGNED NOT NULL DEFAULT '0',
  `achievement_id` INT(11) UNSIGNED NOT NULL DEFAULT '0',
  `date_time` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` SMALLINT(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`account_id`, `achievement_id`),
  KEY `account_id` (`account_id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `achievement_progress` (
  `account_id` INT(11) UNSIGNED NOT NULL DEFAULT '0',
  `achievement_id` INT(11) UNSIGNED NOT NULL DEFAULT '0',
  `type` SMALLINT(6) NOT NULL DEFAULT '0',
  `target` VARCHAR(50) NOT NULL DEFAULT '',
  `value` INT(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`account_id`, `achievement_id`, `type`, `target`),
  KEY `achievement_id` (`achievement_id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `achievement_mapname` (
  `map` VARCHAR(16) NOT NULL DEFAULT '',
  `name` VARCHAR(80) NOT NULL DEFAULT '',
  PRIMARY KEY (`map`)
) ENGINE=MyISAM;

INSERT INTO `achievement_mapname` VALUES ('moc_prydn1', 'Base da Pir�mide (01)');
INSERT INTO `achievement_mapname` VALUES ('moc_prydn2', 'Base da Pir�mide (02)');
INSERT INTO `achievement_mapname` VALUES ('gld_dun04', 'Calabou�o do Feudo de Britoniah');
INSERT INTO `achievement_mapname` VALUES ('gld_dun03', 'Calabou�o do Feudo das Valqu�rias');
INSERT INTO `achievement_mapname` VALUES ('gld_dun02', 'Calabou�o do Feudo de Luina');
INSERT INTO `achievement_mapname` VALUES ('gld_dun01', 'Calabou�o do Feudo do Bosque Celestial');
INSERT INTO `achievement_mapname` VALUES ('payg_cas05', 'Pal�cio da Colina');
INSERT INTO `achievement_mapname` VALUES ('payg_cas04', 'Pal�cio Escarlate');
INSERT INTO `achievement_mapname` VALUES ('payg_cas03', 'Pal�cio da Sombra');
INSERT INTO `achievement_mapname` VALUES ('payg_cas02', 'Pal�cio do Lago Sagrado');
INSERT INTO `achievement_mapname` VALUES ('payg_cas01', 'Pal�cio do Sol');
INSERT INTO `achievement_mapname` VALUES ('pay_gld', 'Feudo do Bosque Celestial');
INSERT INTO `achievement_mapname` VALUES ('aldeg_cas05', 'Acrux');
INSERT INTO `achievement_mapname` VALUES ('aldeg_cas04', 'Rigel');
INSERT INTO `achievement_mapname` VALUES ('aldeg_cas03', 'Canopus');
INSERT INTO `achievement_mapname` VALUES ('aldeg_cas02', 'Astrum');
INSERT INTO `achievement_mapname` VALUES ('aldeg_cas01', 'Sirius');
INSERT INTO `achievement_mapname` VALUES ('alde_gld', 'Feudo de Luina');
INSERT INTO `achievement_mapname` VALUES ('gefg_cas05', 'Arima');
INSERT INTO `achievement_mapname` VALUES ('gefg_cas04', 'Saffran');
INSERT INTO `achievement_mapname` VALUES ('gefg_cas03', 'Ruaden');
INSERT INTO `achievement_mapname` VALUES ('gefg_cas02', 'Trapesac');
INSERT INTO `achievement_mapname` VALUES ('gefg_cas01', 'Arsulf');
INSERT INTO `achievement_mapname` VALUES ('prtg_cas05', 'Gondul');
INSERT INTO `achievement_mapname` VALUES ('prtg_cas04', 'Skoegul');
INSERT INTO `achievement_mapname` VALUES ('prtg_cas03', 'Brynhildr');
INSERT INTO `achievement_mapname` VALUES ('prtg_cas02', 'Hrist');
INSERT INTO `achievement_mapname` VALUES ('prtg_cas01', 'Kriemhild');
INSERT INTO `achievement_mapname` VALUES ('prt_gld', 'Feudo das Valqu�rias');
INSERT INTO `achievement_mapname` VALUES ('tur_dun01', 'Ilha da Tartaruga');
INSERT INTO `achievement_mapname` VALUES ('tur_dun02', 'Calabou�o da Ilha da Tartaruga');
INSERT INTO `achievement_mapname` VALUES ('tur_dun03', 'Vila das Boas Tartarugas');
INSERT INTO `achievement_mapname` VALUES ('tur_dun04', 'Pal�cio da Ilha da Tartaruga');
INSERT INTO `achievement_mapname` VALUES ('tur_dun05', 'P�ntano Subterr�neo (1)');
INSERT INTO `achievement_mapname` VALUES ('tur_dun06', 'P�ntano Subterr�neo (2)');
INSERT INTO `achievement_mapname` VALUES ('guild_vs3', 'Arena do Forte');
INSERT INTO `achievement_mapname` VALUES ('guild_vs2', 'Arena do Forte');
INSERT INTO `achievement_mapname` VALUES ('guild_vs1', 'Arena do Forte');
INSERT INTO `achievement_mapname` VALUES ('guild_room', '�rea de Espera, Arena da Guilda');
INSERT INTO `achievement_mapname` VALUES ('quiz_00', 'Desafio das Perguntas');
INSERT INTO `achievement_mapname` VALUES ('quiz_01', 'Desafio das Perguntas');
INSERT INTO `achievement_mapname` VALUES ('gef_fild12', 'Floresta Kordt');
INSERT INTO `achievement_mapname` VALUES ('gef_fild13', 'Feudo de Britoniah');
INSERT INTO `achievement_mapname` VALUES ('gef_fild14', 'Vila dos Orcs do Oeste');
INSERT INTO `achievement_mapname` VALUES ('cmd_in02', 'Casa em Comodo (2)');
INSERT INTO `achievement_mapname` VALUES ('cmd_in01', 'Casa em Comodo (1)');
INSERT INTO `achievement_mapname` VALUES ('comodo', 'Cidade Litor�nea de Comodo');
INSERT INTO `achievement_mapname` VALUES ('beach_dun', 'Karu, a Caverna do Oeste');
INSERT INTO `achievement_mapname` VALUES ('beach_dun2', 'Ruande, a Caverna do Norte');
INSERT INTO `achievement_mapname` VALUES ('beach_dun3', 'Mao, a Caverna do Leste');
INSERT INTO `achievement_mapname` VALUES ('cmd_fild01', 'Floresta Papuchica');
INSERT INTO `achievement_mapname` VALUES ('cmd_fild02', 'Praia Kokomo');
INSERT INTO `achievement_mapname` VALUES ('cmd_fild03', 'Mangue Zenhai');
INSERT INTO `achievement_mapname` VALUES ('cmd_fild04', 'Praia Kokomo');
INSERT INTO `achievement_mapname` VALUES ('cmd_fild05', 'Limite da Floresta Papuchica');
INSERT INTO `achievement_mapname` VALUES ('cmd_fild06', 'Fortaleza de Saint Darmain(Oeste)');
INSERT INTO `achievement_mapname` VALUES ('cmd_fild07', 'Ilha do Farol, Pharos');
INSERT INTO `achievement_mapname` VALUES ('cmd_fild08', 'Fortaleza de Saint Darmain(Leste)');
INSERT INTO `achievement_mapname` VALUES ('cmd_fild09', 'Fortaleza de Saint Darmain(Sul)');
INSERT INTO `achievement_mapname` VALUES ('xmas_in', 'Casa em Lutie');
INSERT INTO `achievement_mapname` VALUES ('xmas_dun02', 'Sala de Constru��o de Brinquedos');
INSERT INTO `achievement_mapname` VALUES ('xmas_dun01', 'Dep�sito da F�brica de Brinquedos');
INSERT INTO `achievement_mapname` VALUES ('xmas_fild01', 'Arredores de Lutie');
INSERT INTO `achievement_mapname` VALUES ('xmas', 'Lutie, A Cidade do Natal');
INSERT INTO `achievement_mapname` VALUES ('mjolnir_01', 'Monte Mjolnir (01)');
INSERT INTO `achievement_mapname` VALUES ('mjolnir_02', 'Monte Mjolnir (02)');
INSERT INTO `achievement_mapname` VALUES ('mjolnir_03', 'Monte Mjolnir (03)');
INSERT INTO `achievement_mapname` VALUES ('mjolnir_04', 'Monte Mjolnir (04)');
INSERT INTO `achievement_mapname` VALUES ('mjolnir_05', 'Monte Mjolnir (05)');
INSERT INTO `achievement_mapname` VALUES ('mjolnir_06', 'Monte Mjolnir (06)');
INSERT INTO `achievement_mapname` VALUES ('mjolnir_07', 'Monte Mjolnir (07)');
INSERT INTO `achievement_mapname` VALUES ('mjolnir_08', 'Monte Mjolnir (08)');
INSERT INTO `achievement_mapname` VALUES ('mjolnir_09', 'Monte Mjolnir (09)');
INSERT INTO `achievement_mapname` VALUES ('mjolnir_10', 'Monte Mjolnir (10)');
INSERT INTO `achievement_mapname` VALUES ('mjolnir_11', 'Monte Mjolnir (11)');
INSERT INTO `achievement_mapname` VALUES ('mjolnir_12', 'Monte Mjolnir (12)');
INSERT INTO `achievement_mapname` VALUES ('prt_fild00', 'Arredores de Prontera (00)');
INSERT INTO `achievement_mapname` VALUES ('prt_fild01', 'Arredores de Prontera (01)');
INSERT INTO `achievement_mapname` VALUES ('prt_fild02', 'Arredores de Prontera (02)');
INSERT INTO `achievement_mapname` VALUES ('prt_fild03', 'Arredores de Prontera (03)');
INSERT INTO `achievement_mapname` VALUES ('prt_fild04', 'Arredores de Prontera (04)');
INSERT INTO `achievement_mapname` VALUES ('prt_fild05', 'Arredores de Prontera (05)');
INSERT INTO `achievement_mapname` VALUES ('prt_fild06', 'Arredores de Prontera (06)');
INSERT INTO `achievement_mapname` VALUES ('prt_fild07', 'Arredores de Prontera (07)');
INSERT INTO `achievement_mapname` VALUES ('prt_fild08', 'Arredores de Prontera (08)');
INSERT INTO `achievement_mapname` VALUES ('prt_fild09', 'Arredores de Prontera (09)');
INSERT INTO `achievement_mapname` VALUES ('prt_fild10', 'Arredores de Prontera (10)');
INSERT INTO `achievement_mapname` VALUES ('prt_fild11', 'Arredores de Prontera (11)');
INSERT INTO `achievement_mapname` VALUES ('prt_monk', 'Abadia de Santa Capitolina');
INSERT INTO `achievement_mapname` VALUES ('gef_fild00', 'Arredores de Geffen (00)');
INSERT INTO `achievement_mapname` VALUES ('gef_fild01', 'Arredores de Geffen (01)');
INSERT INTO `achievement_mapname` VALUES ('gef_fild02', 'Arredores de Geffen (02)');
INSERT INTO `achievement_mapname` VALUES ('gef_fild03', 'Arredores de Geffen (03)');
INSERT INTO `achievement_mapname` VALUES ('gef_fild04', 'Arredores de Geffen (04)');
INSERT INTO `achievement_mapname` VALUES ('gef_fild05', 'Arredores de Geffen (05)');
INSERT INTO `achievement_mapname` VALUES ('gef_fild06', 'Arredores de Geffen (06)');
INSERT INTO `achievement_mapname` VALUES ('gef_fild07', 'Arredores de Geffen (07)');
INSERT INTO `achievement_mapname` VALUES ('gef_fild08', 'Arredores de Geffen (08)');
INSERT INTO `achievement_mapname` VALUES ('gef_fild09', 'Arredores de Geffen (09)');
INSERT INTO `achievement_mapname` VALUES ('gef_fild10', 'Arredores de Geffen (10)');
INSERT INTO `achievement_mapname` VALUES ('in_orcs01', 'Vila dos Orcs');
INSERT INTO `achievement_mapname` VALUES ('gef_fild11', 'Arredores de Geffen (11)');
INSERT INTO `achievement_mapname` VALUES ('moc_fild01', 'Deserto Sograt (01)');
INSERT INTO `achievement_mapname` VALUES ('moc_fild02', 'Deserto Sograt (02)');
INSERT INTO `achievement_mapname` VALUES ('moc_fild03', 'Deserto Sograt (03)');
INSERT INTO `achievement_mapname` VALUES ('moc_fild04', 'Deserto Sograt (04)');
INSERT INTO `achievement_mapname` VALUES ('moc_fild05', 'Deserto Sograt (05)');
INSERT INTO `achievement_mapname` VALUES ('moc_fild06', 'Deserto Sograt (06)');
INSERT INTO `achievement_mapname` VALUES ('moc_fild07', 'Deserto Sograt (07)');
INSERT INTO `achievement_mapname` VALUES ('moc_fild08', 'Deserto Sograt (08)');
INSERT INTO `achievement_mapname` VALUES ('moc_fild09', 'Deserto Sograt (09)');
INSERT INTO `achievement_mapname` VALUES ('moc_fild10', 'Deserto Sograt (10)');
INSERT INTO `achievement_mapname` VALUES ('moc_fild11', 'Deserto Sograt (11)');
INSERT INTO `achievement_mapname` VALUES ('moc_fild12', 'Deserto Sograt (12)');
INSERT INTO `achievement_mapname` VALUES ('moc_fild13', 'Deserto Sograt (13)');
INSERT INTO `achievement_mapname` VALUES ('moc_fild14', 'Deserto Sograt (14)');
INSERT INTO `achievement_mapname` VALUES ('moc_fild15', 'Deserto Sograt (15)');
INSERT INTO `achievement_mapname` VALUES ('moc_fild16', 'Deserto Sograt (16)');
INSERT INTO `achievement_mapname` VALUES ('in_moc_16', 'Guilda dos Mercen�rios');
INSERT INTO `achievement_mapname` VALUES ('moc_fild17', 'Deserto Sograt (17)');
INSERT INTO `achievement_mapname` VALUES ('moc_fild18', 'Deserto Sograt (18)');
INSERT INTO `achievement_mapname` VALUES ('moc_fild19', 'Deserto Sograt (19)');
INSERT INTO `achievement_mapname` VALUES ('pay_fild01', 'Floresta de Payon (01)');
INSERT INTO `achievement_mapname` VALUES ('pay_fild02', 'Floresta de Payon (02)');
INSERT INTO `achievement_mapname` VALUES ('pay_fild03', 'Floresta de Payon (03)');
INSERT INTO `achievement_mapname` VALUES ('pay_fild04', 'Floresta de Payon (04)');
INSERT INTO `achievement_mapname` VALUES ('pay_fild05', 'Floresta de Payon (05)');
INSERT INTO `achievement_mapname` VALUES ('pay_fild06', 'Floresta de Payon (06)');
INSERT INTO `achievement_mapname` VALUES ('pay_fild07', 'Floresta de Payon (07)');
INSERT INTO `achievement_mapname` VALUES ('pay_fild08', 'Floresta de Payon (08)');
INSERT INTO `achievement_mapname` VALUES ('pay_fild09', 'Floresta de Payon (09)');
INSERT INTO `achievement_mapname` VALUES ('pay_fild10', 'Floresta de Payon (10)');
INSERT INTO `achievement_mapname` VALUES ('pay_fild11', 'Floresta de Payon (11)');
INSERT INTO `achievement_mapname` VALUES ('new_1-1', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('new_2-1', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('new_3-1', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('new_4-1', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('new_5-1', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('new_1-2', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('new_2-2', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('new_3-2', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('new_4-2', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('new_5-2', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('new_1-3', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('new_2-3', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('new_3-3', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('new_4-3', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('new_5-3', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('new_1-4', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('new_2-4', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('new_3-4', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('new_4-4', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('new_5-4', 'Campo de Treinamento');
INSERT INTO `achievement_mapname` VALUES ('anthell01', 'Formigueiro Infernal (1)');
INSERT INTO `achievement_mapname` VALUES ('anthell02', 'Formigueiro Infernal (2)');
INSERT INTO `achievement_mapname` VALUES ('gef_dun00', 'Calabou�o de Geffen (1)');
INSERT INTO `achievement_mapname` VALUES ('gef_dun01', 'Calabou�o de Geffen (2)');
INSERT INTO `achievement_mapname` VALUES ('gef_dun02', 'Geffenia (1)');
INSERT INTO `achievement_mapname` VALUES ('gef_dun03', 'Geffenia (2)');
INSERT INTO `achievement_mapname` VALUES ('iz_dun00', 'T�nel Submarino (0)');
INSERT INTO `achievement_mapname` VALUES ('iz_dun01', 'T�nel Submarino (1)');
INSERT INTO `achievement_mapname` VALUES ('iz_dun02', 'T�nel Submarino (3)');
INSERT INTO `achievement_mapname` VALUES ('iz_dun03', 'T�nel Submarino (4)');
INSERT INTO `achievement_mapname` VALUES ('iz_dun04', 'T�nel Submarino (5)');
INSERT INTO `achievement_mapname` VALUES ('iz_dun05', 'T�nel Submarino (6)');
INSERT INTO `achievement_mapname` VALUES ('in_sphinx1', 'Esfinge (1)');
INSERT INTO `achievement_mapname` VALUES ('in_sphinx2', 'Esfinge (2)');
INSERT INTO `achievement_mapname` VALUES ('in_sphinx3', 'Esfinge (3)');
INSERT INTO `achievement_mapname` VALUES ('in_sphinx4', 'Esfinge (4)');
INSERT INTO `achievement_mapname` VALUES ('in_sphinx5', 'Esfinge (5)');
INSERT INTO `achievement_mapname` VALUES ('moc_pryd01', 'Dentro da Pir�mide (1)');
INSERT INTO `achievement_mapname` VALUES ('moc_pryd02', 'Dentro da Pir�mide (2)');
INSERT INTO `achievement_mapname` VALUES ('moc_pryd03', 'Dentro da Pir�mide (3)');
INSERT INTO `achievement_mapname` VALUES ('moc_pryd04', 'Dentro da Pir�mide (4)');
INSERT INTO `achievement_mapname` VALUES ('moc_pryd05', 'Dentro da Pir�mide (5)');
INSERT INTO `achievement_mapname` VALUES ('moc_pryd06', 'Dentro da Pir�mide (6)');
INSERT INTO `achievement_mapname` VALUES ('moc_prydb1', 'Guilda dos Gatunos');
INSERT INTO `achievement_mapname` VALUES ('mjo_dun01', 'Mina Abandonada de Mjolnir (1)');
INSERT INTO `achievement_mapname` VALUES ('mjo_dun02', 'Mina Abandonada de Mjolnir (2)');
INSERT INTO `achievement_mapname` VALUES ('mjo_dun03', 'Mina Abandonada de Mjolnir (3)');
INSERT INTO `achievement_mapname` VALUES ('orcsdun01', 'Calabou�o dos Orcs (1)');
INSERT INTO `achievement_mapname` VALUES ('orcsdun02', 'Calabou�o dos Orcs (2)');
INSERT INTO `achievement_mapname` VALUES ('pay_dun00', 'Caverna de Payon (0)');
INSERT INTO `achievement_mapname` VALUES ('pay_dun01', 'Caverna de Payon (1)');
INSERT INTO `achievement_mapname` VALUES ('pay_dun02', 'Caverna de Payon (2)');
INSERT INTO `achievement_mapname` VALUES ('pay_dun03', 'Caverna de Payon (3)');
INSERT INTO `achievement_mapname` VALUES ('pay_dun04', 'Caverna de Payon (4)');
INSERT INTO `achievement_mapname` VALUES ('prt_maze01', 'Labirinto da Floresta (1)');
INSERT INTO `achievement_mapname` VALUES ('prt_maze02', 'Labirinto da Floresta (2)');
INSERT INTO `achievement_mapname` VALUES ('prt_maze03', 'Labirinto da Floresta (3)');
INSERT INTO `achievement_mapname` VALUES ('prt_sewb1', 'Esgoto de Prontera (1)');
INSERT INTO `achievement_mapname` VALUES ('prt_sewb2', 'Esgoto de Prontera (2)');
INSERT INTO `achievement_mapname` VALUES ('prt_sewb3', 'Esgoto de Prontera (3)');
INSERT INTO `achievement_mapname` VALUES ('prt_sewb4', 'Esgoto de Prontera (4)');
INSERT INTO `achievement_mapname` VALUES ('treasure01', 'Navio Fantasma (1)');
INSERT INTO `achievement_mapname` VALUES ('treasure02', 'Navio Fantasma (2)');
INSERT INTO `achievement_mapname` VALUES ('hunter_1-1', 'Guilda dos Ca�adores');
INSERT INTO `achievement_mapname` VALUES ('hunter_2-1', 'Guilda dos Ca�adores');
INSERT INTO `achievement_mapname` VALUES ('hunter_3-1', 'Guilda dos Ca�adores');
INSERT INTO `achievement_mapname` VALUES ('in_hunter', 'Guilda dos Ca�adores');
INSERT INTO `achievement_mapname` VALUES ('knight_1-1', 'Cavalaria');
INSERT INTO `achievement_mapname` VALUES ('knight_2-1', 'Cavalaria');
INSERT INTO `achievement_mapname` VALUES ('knight_3-1', 'Cavalaria');
INSERT INTO `achievement_mapname` VALUES ('priest_1-1', 'Sanctum');
INSERT INTO `achievement_mapname` VALUES ('priest_2-1', 'Sanctum');
INSERT INTO `achievement_mapname` VALUES ('priest_3-1', 'Sanctum');
INSERT INTO `achievement_mapname` VALUES ('sword_1-1', 'Hall da Prova dos Espadachins');
INSERT INTO `achievement_mapname` VALUES ('sword_2-1', 'Hall da Prova dos Espadachins');
INSERT INTO `achievement_mapname` VALUES ('sword_3-1', 'Hall da Prova dos Espadachins');
INSERT INTO `achievement_mapname` VALUES ('job_thief1', 'Fazenda dos Cogumelos');
INSERT INTO `achievement_mapname` VALUES ('wizard_1-1', 'Escola dos Bruxos');
INSERT INTO `achievement_mapname` VALUES ('wizard_2-1', 'Escola dos Bruxos');
INSERT INTO `achievement_mapname` VALUES ('wizard_3-1', 'Escola dos Bruxos');
INSERT INTO `achievement_mapname` VALUES ('force_1-1', 'Luta Contra o Tempo');
INSERT INTO `achievement_mapname` VALUES ('force_2-1', 'Luta Contra o Tempo');
INSERT INTO `achievement_mapname` VALUES ('force_3-1', 'Luta Contra o Tempo');
INSERT INTO `achievement_mapname` VALUES ('force_1-2', 'Luta Contra o Tempo');
INSERT INTO `achievement_mapname` VALUES ('force_2-2', 'Luta Contra o Tempo');
INSERT INTO `achievement_mapname` VALUES ('force_3-2', 'Luta Contra o Tempo');
INSERT INTO `achievement_mapname` VALUES ('force_1-3', 'Luta Contra o Tempo');
INSERT INTO `achievement_mapname` VALUES ('force_2-3', 'Luta Contra o Tempo');
INSERT INTO `achievement_mapname` VALUES ('force_3-3', 'Luta Contra o Tempo');
INSERT INTO `achievement_mapname` VALUES ('ordeal_1-1', 'Batalha de Prova��o');
INSERT INTO `achievement_mapname` VALUES ('ordeal_2-1', 'Batalha de Prova��o');
INSERT INTO `achievement_mapname` VALUES ('ordeal_3-1', 'Batalha de Prova��o');
INSERT INTO `achievement_mapname` VALUES ('ordeal_1-2', 'Batalha de Prova��o');
INSERT INTO `achievement_mapname` VALUES ('ordeal_2-2', 'Batalha de Prova��o');
INSERT INTO `achievement_mapname` VALUES ('ordeal_3-2', 'Batalha de Prova��o');
INSERT INTO `achievement_mapname` VALUES ('ordeal_1-3', 'Batalha de Prova��o');
INSERT INTO `achievement_mapname` VALUES ('ordeal_2-3', 'Batalha de Prova��o');
INSERT INTO `achievement_mapname` VALUES ('ordeal_3-3', 'Batalha de Prova��o');
INSERT INTO `achievement_mapname` VALUES ('ordeal_1-4', 'Batalha de Prova��o');
INSERT INTO `achievement_mapname` VALUES ('ordeal_2-4', 'Batalha de Prova��o');
INSERT INTO `achievement_mapname` VALUES ('ordeal_3-4', 'Batalha de Prova��o');
INSERT INTO `achievement_mapname` VALUES ('alb_ship', 'Navio de Alberta');
INSERT INTO `achievement_mapname` VALUES ('alberta', 'Alberta');
INSERT INTO `achievement_mapname` VALUES ('alberta_in', 'Casa em Alberta');
INSERT INTO `achievement_mapname` VALUES ('alb2trea', 'Ilha de Alberta');
INSERT INTO `achievement_mapname` VALUES ('aldebaran', 'Al De Baran');
INSERT INTO `achievement_mapname` VALUES ('aldeba_in', 'Dentro de Al De Baran');
INSERT INTO `achievement_mapname` VALUES ('gef_tower', 'Torre de Geffen');
INSERT INTO `achievement_mapname` VALUES ('geffen', 'Geffen');
INSERT INTO `achievement_mapname` VALUES ('geffen_in', 'Casa em Geffen');
INSERT INTO `achievement_mapname` VALUES ('moc_castle', 'Castelo de Morroc');
INSERT INTO `achievement_mapname` VALUES ('moc_ruins', 'Ru�nas de Morroc');
INSERT INTO `achievement_mapname` VALUES ('morocc', 'Morroc');
INSERT INTO `achievement_mapname` VALUES ('morocc_in', 'Casa em Morroc');
INSERT INTO `achievement_mapname` VALUES ('pay_arche', 'Vila dos Arqueiros');
INSERT INTO `achievement_mapname` VALUES ('payon', 'Payon');
INSERT INTO `achievement_mapname` VALUES ('payon_in01', 'Casa em Payon (1)');
INSERT INTO `achievement_mapname` VALUES ('payon_in02', 'Casa em Payon (2)');
INSERT INTO `achievement_mapname` VALUES ('prontera', 'Prontera');
INSERT INTO `achievement_mapname` VALUES ('prt_in', 'Casa em Prontera');
INSERT INTO `achievement_mapname` VALUES ('prt_castle', 'Castelo de Prontera');
INSERT INTO `achievement_mapname` VALUES ('prt_church', 'Catedral');
INSERT INTO `achievement_mapname` VALUES ('izlude', 'Izlude');
INSERT INTO `achievement_mapname` VALUES ('izlude_in', 'Casa em Izlude');
INSERT INTO `achievement_mapname` VALUES ('izlu2dun', 'Ilha Byalan');
INSERT INTO `achievement_mapname` VALUES ('monk_in', 'Dentro de St. Abbey');
INSERT INTO `achievement_mapname` VALUES ('glast_01', 'Glast Heim');
INSERT INTO `achievement_mapname` VALUES ('alde_dun01', 'Torre do Rel�gio (s1)');
INSERT INTO `achievement_mapname` VALUES ('alde_dun02', 'Torre do Rel�gio (s2)');
INSERT INTO `achievement_mapname` VALUES ('alde_dun03', 'Torre do Rel�gio (s3)');
INSERT INTO `achievement_mapname` VALUES ('alde_dun04', 'Torre do Rel�gio (s4)');
INSERT INTO `achievement_mapname` VALUES ('c_tower1', 'Torre do Rel�gio (1)');
INSERT INTO `achievement_mapname` VALUES ('c_tower2', 'Torre do Rel�gio (2)');
INSERT INTO `achievement_mapname` VALUES ('c_tower3', 'Torre do Rel�gio (3)');
INSERT INTO `achievement_mapname` VALUES ('c_tower4', 'Torre do Rel�gio (4)');
INSERT INTO `achievement_mapname` VALUES ('gl_cas01', 'Glast Heim (1)');
INSERT INTO `achievement_mapname` VALUES ('gl_cas02', 'Glast Heim (2)');
INSERT INTO `achievement_mapname` VALUES ('gl_church', 'Abadia de Glast Heim');
INSERT INTO `achievement_mapname` VALUES ('gl_chyard', 'Cemit�rio de Glast Heim');
INSERT INTO `achievement_mapname` VALUES ('gl_dun01', 'A Mais Profunda Caverna de Glast Heim (1)');
INSERT INTO `achievement_mapname` VALUES ('gl_dun02', 'A Mais Profunda Caverna de Glast Heim (2)');
INSERT INTO `achievement_mapname` VALUES ('gl_in01', 'Casa em Glast Heim');
INSERT INTO `achievement_mapname` VALUES ('gl_knt01', 'Cavalaria de Glast Heim (1)');
INSERT INTO `achievement_mapname` VALUES ('gl_knt02', 'Cavalaria de Glast Heim (1)');
INSERT INTO `achievement_mapname` VALUES ('gl_prison', 'Pris�o Subterr�nea de Glast Heim (0)');
INSERT INTO `achievement_mapname` VALUES ('gl_prison1', 'Pris�o Subterr�nea de Glast Heim (1)');
INSERT INTO `achievement_mapname` VALUES ('gl_sew01', 'Esgoto de Glast Heim (1)');
INSERT INTO `achievement_mapname` VALUES ('gl_sew02', 'Esgoto de Glast Heim (2)');
INSERT INTO `achievement_mapname` VALUES ('gl_sew03', 'Esgoto de Glast Heim (3)');
INSERT INTO `achievement_mapname` VALUES ('gl_sew04', 'Esgoto de Glast Heim (4)');
INSERT INTO `achievement_mapname` VALUES ('gl_step', 'Escadarias de Glast Heim');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_room', 'PvP : Sala de Espera');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_room', 'PvP : Sala de Espera');
INSERT INTO `achievement_mapname` VALUES ('pvp_c_room', 'PvP : Sala de Espera');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_1-1', 'PvP : Sala Sandu�che');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_2-1', 'PvP : Sala Sandu�che');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_3-1', 'PvP : Sala Sandu�che');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_4-1', 'PvP : Sala Sandu�che');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_5-1', 'PvP : Sala Sandu�che');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_6-1', 'PvP : Sala Sandu�che');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_7-1', 'PvP : Sala Sandu�che');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_8-1', 'PvP : Sala Sandu�che');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_1-2', 'PvP : Sala Desafio Adiante');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_2-2', 'PvP : Sala Desafio Adiante');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_3-2', 'PvP : Sala Desafio Adiante');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_4-2', 'PvP : Sala Desafio Adiante');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_5-2', 'PvP : Sala Desafio Adiante');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_6-2', 'PvP : Sala Desafio Adiante');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_7-2', 'PvP : Sala Desafio Adiante');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_8-2', 'PvP : Sala Desafio Adiante');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_1-3', 'PvP : Sala Tetra');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_2-3', 'PvP : Sala Tetra');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_3-3', 'PvP : Sala Tetra');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_4-3', 'PvP : Sala Tetra');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_5-3', 'PvP : Sala Tetra');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_6-3', 'PvP : Sala Tetra');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_7-3', 'PvP : Sala Tetra');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_8-3', 'PvP : Sala Tetra');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_1-4', 'PvP : Sala Encruzilhada');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_2-4', 'PvP : Sala Encruzilhada');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_3-4', 'PvP : Sala Encruzilhada');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_4-4', 'PvP : Sala Encruzilhada');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_5-4', 'PvP : Sala Encruzilhada');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_6-4', 'PvP : Sala Encruzilhada');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_7-4', 'PvP : Sala Encruzilhada');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_8-4', 'PvP : Sala Encruzilhada');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_1-5', 'PvP : Sala B�ssola');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_2-5', 'PvP : Sala B�ssola');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_3-5', 'PvP : Sala B�ssola');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_4-5', 'PvP : Sala B�ssola');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_5-5', 'PvP : Sala B�ssola');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_6-5', 'PvP : Sala B�ssola');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_7-5', 'PvP : Sala B�ssola');
INSERT INTO `achievement_mapname` VALUES ('pvp_n_8-5', 'PvP : Sala B�ssola');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_1-1', 'PvP : Sala de Prontera');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_2-1', 'PvP : Sala de Prontera');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_3-1', 'PvP : Sala de Prontera');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_4-1', 'PvP : Sala de Prontera');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_5-1', 'PvP : Sala de Prontera');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_6-1', 'PvP : Sala de Prontera');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_7-1', 'PvP : Sala de Prontera');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_8-1', 'PvP : Sala de Prontera');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_1-2', 'PvP : Sala de Izlude');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_2-2', 'PvP : Sala de Izlude');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_3-2', 'PvP : Sala de Izlude');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_4-2', 'PvP : Sala de Izlude');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_5-2', 'PvP : Sala de Izlude');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_6-2', 'PvP : Sala de Izlude');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_7-2', 'PvP : Sala de Izlude');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_8-2', 'PvP : Sala de Izlude');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_1-3', 'PvP : Sala de Payon');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_2-3', 'PvP : Sala de Payon');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_3-3', 'PvP : Sala de Payon');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_4-3', 'PvP : Sala de Payon');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_5-3', 'PvP : Sala de Payon');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_6-3', 'PvP : Sala de Payon');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_7-3', 'PvP : Sala de Payon');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_8-3', 'PvP : Sala de Payon');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_1-4', 'PvP : Sala de Alberta');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_2-4', 'PvP : Sala de Alberta');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_3-4', 'PvP : Sala de Alberta');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_4-4', 'PvP : Sala de Alberta');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_5-4', 'PvP : Sala de Alberta');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_6-4', 'PvP : Sala de Alberta');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_7-4', 'PvP : Sala de Alberta');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_8-4', 'PvP : Sala de Alberta');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_1-5', 'PvP : Sala de Morroc');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_2-5', 'PvP : Sala de Morroc');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_3-5', 'PvP : Sala de Morroc');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_4-5', 'PvP : Sala de Morroc');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_5-5', 'PvP : Sala de Morroc');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_6-5', 'PvP : Sala de Morroc');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_7-5', 'PvP : Sala de Morroc');
INSERT INTO `achievement_mapname` VALUES ('pvp_y_8-5', 'PvP : Sala de Morroc');
INSERT INTO `achievement_mapname` VALUES ('pvp_2vs2', 'PvP : Colisseu');
INSERT INTO `achievement_mapname` VALUES ('alde_alche', 'Guilda dos Alquimistas');
INSERT INTO `achievement_mapname` VALUES ('yuno_in05', 'Cora��o de Imir');
INSERT INTO `achievement_mapname` VALUES ('yuno_in04', 'Biblioteca de Juno');
INSERT INTO `achievement_mapname` VALUES ('job_duncer', 'Teatro de Comodo');
INSERT INTO `achievement_mapname` VALUES ('job_sage', 'Campo de Testes (S�bios)');
INSERT INTO `achievement_mapname` VALUES ('job_cru', 'Campo de Testes (Templ�rios)');
INSERT INTO `achievement_mapname` VALUES ('job_monk', 'Abadia de Santa Capitolina');
INSERT INTO `achievement_mapname` VALUES ('monk_test', 'Abadia de Santa Capitolina');
INSERT INTO `achievement_mapname` VALUES ('in_rogue', 'Guila dos Arruaceiros');
INSERT INTO `achievement_mapname` VALUES ('mag_dun02', 'Calabou�o de Magma');
INSERT INTO `achievement_mapname` VALUES ('mag_dun01', 'Calabou�o de Magma');
INSERT INTO `achievement_mapname` VALUES ('yuno_fild04', 'Planalto de Juno');
INSERT INTO `achievement_mapname` VALUES ('yuno_fild03', 'Planalto de Juno');
INSERT INTO `achievement_mapname` VALUES ('yuno_fild02', 'Arredores de Juno');
INSERT INTO `achievement_mapname` VALUES ('yuno_fild01', 'Fronteira de Aldebaran');
INSERT INTO `achievement_mapname` VALUES ('yuno_in03', 'Casa em Juno');
INSERT INTO `achievement_mapname` VALUES ('yuno_in02', 'Castelo dos S�bios');
INSERT INTO `achievement_mapname` VALUES ('yuno_in01', 'Casa em Juno');
INSERT INTO `achievement_mapname` VALUES ('yuno', 'Juno');
INSERT INTO `achievement_mapname` VALUES ('job_wiz', 'Campo de Testes (Bruxos)');
INSERT INTO `achievement_mapname` VALUES ('job_prist', 'Campo de Testes (Sacerdotes)');
INSERT INTO `achievement_mapname` VALUES ('job_knt', 'Campo de Testes (Cavaleiros)');
INSERT INTO `achievement_mapname` VALUES ('job_hunte', 'Campo de Testes (Ca�adores)');
INSERT INTO `achievement_mapname` VALUES ('gon_test', 'Sal�o de Batalhas');
INSERT INTO `achievement_mapname` VALUES ('gon_dun01', 'Santu�rio de Xi Wang Mu');
INSERT INTO `achievement_mapname` VALUES ('gon_dun02', 'Tabuleiro de Go');
INSERT INTO `achievement_mapname` VALUES ('gon_dun03', 'Terra das Fadas');
INSERT INTO `achievement_mapname` VALUES ('gon_fild01', 'Campo de Kunlun');
INSERT INTO `achievement_mapname` VALUES ('gon_in', 'Interior de Kunlun');
INSERT INTO `achievement_mapname` VALUES ('gonryun', 'Kunlun, a Ilha dos Heremitas');
INSERT INTO `achievement_mapname` VALUES ('ama_test', 'Campo de Momotaro');
INSERT INTO `achievement_mapname` VALUES ('ama_dun03', 'Templo Subterr�neo de Amatsu');
INSERT INTO `achievement_mapname` VALUES ('ama_dun02', 'Campo de Batalha da Floresta Subterr�nea');
INSERT INTO `achievement_mapname` VALUES ('ama_dun01', 'Labirinto de Tatames');
INSERT INTO `achievement_mapname` VALUES ('ama_fild01', 'Campo de Amatsu');
INSERT INTO `achievement_mapname` VALUES ('ama_in02', 'Interior de TenguGak');
INSERT INTO `achievement_mapname` VALUES ('ama_in01', 'Interior de Amatsu');
INSERT INTO `achievement_mapname` VALUES ('amatsu', 'Amatsu, a terra dos Tengu');
INSERT INTO `achievement_mapname` VALUES ('um_dun01', 'Loja de Carpintaria');
INSERT INTO `achievement_mapname` VALUES ('um_dun02', 'Estrada para o Outro Mundo');
INSERT INTO `achievement_mapname` VALUES ('um_in', 'Interior de Umbala');
INSERT INTO `achievement_mapname` VALUES ('um_fild01', 'Floresta de Luluka');
INSERT INTO `achievement_mapname` VALUES ('um_fild02', 'Floresta de Hoomga');
INSERT INTO `achievement_mapname` VALUES ('um_fild03', 'P�ntano de Kalala');
INSERT INTO `achievement_mapname` VALUES ('um_fild04', 'Selva de Hoomga');
INSERT INTO `achievement_mapname` VALUES ('umbala', 'Aldeia da tribo Wootan, Umbala');
INSERT INTO `achievement_mapname` VALUES ('payon_in03', 'Casa em Payon');
INSERT INTO `achievement_mapname` VALUES ('nif_in', 'Interior de Nifflheim');
INSERT INTO `achievement_mapname` VALUES ('yggdrasil01', 'Fonte de Hvergelmir (Tronco de Yggdrasil)');
INSERT INTO `achievement_mapname` VALUES ('nif_fild02', 'Vale de Gyoll');
INSERT INTO `achievement_mapname` VALUES ('nif_fild01', 'Skellington, um vilarejo solit�rio em Nifflheim');
INSERT INTO `achievement_mapname` VALUES ('niflheim', 'Nifflheim, O reino dos mortos');
INSERT INTO `achievement_mapname` VALUES ('jawaii_in', 'Interior de Jawaii');
INSERT INTO `achievement_mapname` VALUES ('jawaii', 'Jawaii, a Ilha da Lua-de-Mel');
INSERT INTO `achievement_mapname` VALUES ('lou_in02', 'Interior de Louyang');
INSERT INTO `achievement_mapname` VALUES ('lou_in01', 'Interior de Louyang');
INSERT INTO `achievement_mapname` VALUES ('lou_dun03', 'Suei Long Gon');
INSERT INTO `achievement_mapname` VALUES ('lou_dun02', 'Interior da Tumba Real');
INSERT INTO `achievement_mapname` VALUES ('lou_dun01', 'A Tumba Real');
INSERT INTO `achievement_mapname` VALUES ('lou_fild01', 'Campos de Louyang');
INSERT INTO `achievement_mapname` VALUES ('louyang', 'Louyang, as terras altas');
INSERT INTO `achievement_mapname` VALUES ('ayo_in02', 'Interior de Ayotaya');
INSERT INTO `achievement_mapname` VALUES ('ayo_in01', 'Interior de Ayotaya');
INSERT INTO `achievement_mapname` VALUES ('ayo_dun02', 'Interior do Santu�rio Ancestral');
INSERT INTO `achievement_mapname` VALUES ('ayo_dun01', 'Labirinto do Santu�rio Ancestral');
INSERT INTO `achievement_mapname` VALUES ('ayo_fild02', 'Campos de Ayotaya');
INSERT INTO `achievement_mapname` VALUES ('ayo_fild01', 'Campos de Ayotaya');
INSERT INTO `achievement_mapname` VALUES ('ayothaya', 'Ayotaya');
INSERT INTO `achievement_mapname` VALUES ('prt_are_in', 'Sala de Espera');
INSERT INTO `achievement_mapname` VALUES ('arena_room', 'Sala de Espera');
INSERT INTO `achievement_mapname` VALUES ('prt_arena01', 'Arena');
INSERT INTO `achievement_mapname` VALUES ('prt_are01', 'Arena');
INSERT INTO `achievement_mapname` VALUES ('force_4-1', 'Luta Contra o Tempo');
INSERT INTO `achievement_mapname` VALUES ('himinn', 'Valkyrie Hall (Himinn)');
INSERT INTO `achievement_mapname` VALUES ('sec_in01', 'Interior do Valhalla');
INSERT INTO `achievement_mapname` VALUES ('sec_in02', 'Interior do Valhalla');
INSERT INTO `achievement_mapname` VALUES ('sec_pri', 'Sala da Medita��o (Pris�o do Valhalla)');
INSERT INTO `achievement_mapname` VALUES ('valkyrie', 'Hall das Valqu�rias');
INSERT INTO `achievement_mapname` VALUES ('gefenia01', 'Gefenia');
INSERT INTO `achievement_mapname` VALUES ('gefenia02', 'Gefenia');
INSERT INTO `achievement_mapname` VALUES ('gefenia03', 'Gefenia');
INSERT INTO `achievement_mapname` VALUES ('gefenia04', 'Gefenia');
INSERT INTO `achievement_mapname` VALUES ('ein_dun02', 'Calabou�o da Mina');
INSERT INTO `achievement_mapname` VALUES ('ein_dun01', 'Calabou�o da Mina');
INSERT INTO `achievement_mapname` VALUES ('ein_fild10', 'Campos de Einbroch');
INSERT INTO `achievement_mapname` VALUES ('ein_fild09', 'Campos de Einbroch');
INSERT INTO `achievement_mapname` VALUES ('ein_fild08', 'Campos de Einbroch');
INSERT INTO `achievement_mapname` VALUES ('ein_fild07', 'Campos de Einbroch');
INSERT INTO `achievement_mapname` VALUES ('ein_fild06', 'Campos de Einbroch');
INSERT INTO `achievement_mapname` VALUES ('airplane', 'Aeroplano');
INSERT INTO `achievement_mapname` VALUES ('airport', 'Aeroporto');
INSERT INTO `achievement_mapname` VALUES ('ein_in01', 'Interior de Einbroch');
INSERT INTO `achievement_mapname` VALUES ('einbech', 'Einbech, a vila mineradora');
INSERT INTO `achievement_mapname` VALUES ('einbroch', 'Einbroch, a cidade de a�o');
INSERT INTO `achievement_mapname` VALUES ('turbo_e_16', 'Est�dio Turbo Track');
INSERT INTO `achievement_mapname` VALUES ('turbo_e_8', 'Est�dio Turbo Track');
INSERT INTO `achievement_mapname` VALUES ('turbo_e_4', 'Est�dio Turbo Track');
INSERT INTO `achievement_mapname` VALUES ('turbo_n_16', 'Est�dio Turbo Track');
INSERT INTO `achievement_mapname` VALUES ('turbo_n_8', 'Est�dio Turbo Track');
INSERT INTO `achievement_mapname` VALUES ('turbo_n_4', 'Est�dio Turbo Track');
INSERT INTO `achievement_mapname` VALUES ('turbo_n_1', 'Est�dio Turbo Track');
INSERT INTO `achievement_mapname` VALUES ('turbo_room', 'Sala de Espera');
INSERT INTO `achievement_mapname` VALUES ('yuno_fild12', 'Controle da Fronteira');
INSERT INTO `achievement_mapname` VALUES ('yuno_fild11', 'Campos de Juno');
INSERT INTO `achievement_mapname` VALUES ('yuno_fild09', 'Acampamento dos Guardas de Schwaltzwald');
INSERT INTO `achievement_mapname` VALUES ('yuno_fild08', 'Academia de Kiel Khayr');
INSERT INTO `achievement_mapname` VALUES ('yuno_fild07', 'Desfiladeiro de El Mes (Vale do Abismo)');
INSERT INTO `achievement_mapname` VALUES ('yuno_fild05', 'Planalto de El Mes');
INSERT INTO `achievement_mapname` VALUES ('que_god02', 'Mapa da Miss�o');
INSERT INTO `achievement_mapname` VALUES ('que_god01', 'Mapa da Miss�o');
INSERT INTO `achievement_mapname` VALUES ('quiz_test', 'Sal�o do Desafio');
INSERT INTO `achievement_mapname` VALUES ('rwc01', 'championship4');
INSERT INTO `achievement_mapname` VALUES ('rwc03', 'championship5');
INSERT INTO `achievement_mapname` VALUES ('que_job01', 'Taverna Particular');
INSERT INTO `achievement_mapname` VALUES ('abyss_01', 'Caverna Subterr�nea do Lago do Abismo');
INSERT INTO `achievement_mapname` VALUES ('abyss_02', 'Caverna Subterr�nea do Lago do Abismo');
INSERT INTO `achievement_mapname` VALUES ('abyss_03', 'Caverna Subterr�nea do Lago do Abismo');
INSERT INTO `achievement_mapname` VALUES ('tha_t01', 'Torre de Thanatos');
INSERT INTO `achievement_mapname` VALUES ('tha_t02', 'Torre de Thanatos');
INSERT INTO `achievement_mapname` VALUES ('tha_t03', 'Torre de Thanatos');
INSERT INTO `achievement_mapname` VALUES ('tha_t04', 'Torre de Thanatos');
INSERT INTO `achievement_mapname` VALUES ('tha_t05', 'Torre de Thanatos');
INSERT INTO `achievement_mapname` VALUES ('tha_t06', 'Torre de Thanatos');
INSERT INTO `achievement_mapname` VALUES ('tha_t07', 'Torre de Thanatos');
INSERT INTO `achievement_mapname` VALUES ('tha_t08', 'Torre de Thanatos');
INSERT INTO `achievement_mapname` VALUES ('tha_t09', 'Torre de Thanatos');
INSERT INTO `achievement_mapname` VALUES ('tha_t10', 'Torre de Thanatos');
INSERT INTO `achievement_mapname` VALUES ('tha_t11', 'Torre de Thanatos');
INSERT INTO `achievement_mapname` VALUES ('tha_t12', 'Torre de Thanatos');
INSERT INTO `achievement_mapname` VALUES ('thana_step', 'Torre de Thanatos');
INSERT INTO `achievement_mapname` VALUES ('thana_boss', 'Torre de Thanatos');
INSERT INTO `achievement_mapname` VALUES ('thana_scene01', 'Entrada da Torre de Thanatos');
INSERT INTO `achievement_mapname` VALUES ('job_soul', 'Seu Cora��o');
INSERT INTO `achievement_mapname` VALUES ('job_star', 'O Sol, a Lua e as Estrelas');
INSERT INTO `achievement_mapname` VALUES ('hu_fild07', 'Campos de Hugel');
INSERT INTO `achievement_mapname` VALUES ('hu_fild05', 'O Lago do Abismo');
INSERT INTO `achievement_mapname` VALUES ('hu_fild04', 'Campos de Hugel');
INSERT INTO `achievement_mapname` VALUES ('hu_fild01', 'Torre de Thanatos');
INSERT INTO `achievement_mapname` VALUES ('yuno_fild06', 'Planalto de El Mes');
INSERT INTO `achievement_mapname` VALUES ('quiz_02', 'Arena de Perguntas');
INSERT INTO `achievement_mapname` VALUES ('jupe_cave', 'Entrada das Ru�nas de Juperos');
INSERT INTO `achievement_mapname` VALUES ('juperos_01', 'Ru�nas de Juperos');
INSERT INTO `achievement_mapname` VALUES ('juperos_02', 'Ru�nas de Juperos');
INSERT INTO `achievement_mapname` VALUES ('jupe_gate', 'Juperos, Zona Restrita');
INSERT INTO `achievement_mapname` VALUES ('jupe_area1', 'Juperos, Zona Restrita');
INSERT INTO `achievement_mapname` VALUES ('jupe_area2', 'Juperos, Zona Restrita');
INSERT INTO `achievement_mapname` VALUES ('jupe_ele', 'Elevador de Juperos');
INSERT INTO `achievement_mapname` VALUES ('jupe_ele_r', 'Elevador de Juperos');
INSERT INTO `achievement_mapname` VALUES ('jupe_core', 'Centro de Juperos');
INSERT INTO `achievement_mapname` VALUES ('lighthalzen', 'Lighthalzen');
INSERT INTO `achievement_mapname` VALUES ('lhz_in01', 'Sede da Corpora��o Rekenber');
INSERT INTO `achievement_mapname` VALUES ('lhz_in02', 'Interior de Lighthalzen');
INSERT INTO `achievement_mapname` VALUES ('lhz_in03', 'Interior de Lighthalzen');
INSERT INTO `achievement_mapname` VALUES ('lhz_cube', 'Sala C�bica');
INSERT INTO `achievement_mapname` VALUES ('lhz_que01', 'Interior de Lighthalzen');
INSERT INTO `achievement_mapname` VALUES ('lhz_airport', 'Aeroporto de Lighthalzen');
INSERT INTO `achievement_mapname` VALUES ('airplane_01', 'Aeroplano');
INSERT INTO `achievement_mapname` VALUES ('lhz_dun01', 'Laborat�rio de Somatologia');
INSERT INTO `achievement_mapname` VALUES ('lhz_dun02', 'Laborat�rio de Somatologia');
INSERT INTO `achievement_mapname` VALUES ('lhz_dun03', 'Laborat�rio de Somatologia');
INSERT INTO `achievement_mapname` VALUES ('lhz_fild01', 'Campos de Lighthalzen');
INSERT INTO `achievement_mapname` VALUES ('yuno_pre', 'Sede do Governo de Schwaltzwald');
INSERT INTO `achievement_mapname` VALUES ('y_airport', 'Aeroporto de Juno');
INSERT INTO `achievement_mapname` VALUES ('lhz_fild03', 'Campos de Lighthalzen');
INSERT INTO `achievement_mapname` VALUES ('lhz_fild02', 'Campos de Lighthalzen');
INSERT INTO `achievement_mapname` VALUES ('ein_fild04', 'Campos de Einbroch');
INSERT INTO `achievement_mapname` VALUES ('ein_fild03', 'Campos de Einbroch');
INSERT INTO `achievement_mapname` VALUES ('hugel', 'Hugel, a Vila do Jardim Fant�stico');
INSERT INTO `achievement_mapname` VALUES ('hu_in01', 'Interior de Hugel');
INSERT INTO `achievement_mapname` VALUES ('que_bingo', 'Sala do Bingo');
INSERT INTO `achievement_mapname` VALUES ('que_hugel', 'Subterr�neos do Santu�rio de Odin');
INSERT INTO `achievement_mapname` VALUES ('p_track01', 'Arena da Corrida de Monstros');
INSERT INTO `achievement_mapname` VALUES ('p_track02', 'Arena da Corrida de Monstros');
INSERT INTO `achievement_mapname` VALUES ('odin_tem01', 'Santu�rio de Odin');
INSERT INTO `achievement_mapname` VALUES ('odin_tem02', 'Santu�rio de Odin');
INSERT INTO `achievement_mapname` VALUES ('odin_tem03', 'Santu�rio de Odin');
INSERT INTO `achievement_mapname` VALUES ('hu_fild02', 'Campos de Hugel');
INSERT INTO `achievement_mapname` VALUES ('hu_fild03', 'Campos de Hugel');
INSERT INTO `achievement_mapname` VALUES ('hu_fild06', 'Campos de Hugel');
INSERT INTO `achievement_mapname` VALUES ('ein_fild01', 'Campos de Einbroch');
INSERT INTO `achievement_mapname` VALUES ('ein_fild02', 'Campos de Einbroch');
INSERT INTO `achievement_mapname` VALUES ('ein_fild05', 'Campos de Einbroch');
INSERT INTO `achievement_mapname` VALUES ('yuno_fild10', 'Campos de Juno');
INSERT INTO `achievement_mapname` VALUES ('kh_kiehl02', 'Aposentos de Kiehl');
INSERT INTO `achievement_mapname` VALUES ('kh_kiehl01', 'Aposentos de Kiehl');
INSERT INTO `achievement_mapname` VALUES ('kh_dun02', 'F�brica de Rob�s - N�vel 2');
INSERT INTO `achievement_mapname` VALUES ('kh_dun01', 'F�brica de Rob�s � N�vel 1');
INSERT INTO `achievement_mapname` VALUES ('kh_mansion', 'Mans�o de Kiel Hyre');
INSERT INTO `achievement_mapname` VALUES ('kh_rossi', 'A Mans�o Rosimier');
INSERT INTO `achievement_mapname` VALUES ('kh_school', 'Academia Kiel Hyre');
INSERT INTO `achievement_mapname` VALUES ('kh_vila', 'Cabana de Kiel Hyre');
INSERT INTO `achievement_mapname` VALUES ('auction_01', 'Sala de Leil�o');
INSERT INTO `achievement_mapname` VALUES ('auction_02', 'Sala de Leil�o');
INSERT INTO `achievement_mapname` VALUES ('06guild_r', 'Arena de Batalha de Cl�s');
INSERT INTO `achievement_mapname` VALUES ('06guild_01', 'Arena de Batalha de Cl�s');
INSERT INTO `achievement_mapname` VALUES ('06guild_02', 'Arena de Batalha de Cl�s');
INSERT INTO `achievement_mapname` VALUES ('06guild_03', 'Arena de Batalha de Cl�s');
INSERT INTO `achievement_mapname` VALUES ('06guild_04', 'Arena de Batalha de Cl�s');
INSERT INTO `achievement_mapname` VALUES ('06guild_05', 'Arena de Batalha de Cl�s');
INSERT INTO `achievement_mapname` VALUES ('06guild_06', 'Arena de Batalha de Cl�s');
INSERT INTO `achievement_mapname` VALUES ('06guild_07', 'Arena de Batalha de Cl�s');
INSERT INTO `achievement_mapname` VALUES ('06guild_08', 'Arena de Batalha de Cl�s');
INSERT INTO `achievement_mapname` VALUES ('rachel', 'Capital de Arunafeltz, Rachel');
INSERT INTO `achievement_mapname` VALUES ('ra_in01', 'Interior de Rachel');
INSERT INTO `achievement_mapname` VALUES ('ra_temple', 'Templo de Freya');
INSERT INTO `achievement_mapname` VALUES ('ra_temin', 'Interior do Templo');
INSERT INTO `achievement_mapname` VALUES ('que_rachel', 'Interior do Templo');
INSERT INTO `achievement_mapname` VALUES ('ra_temsky', 'Escrit�rio da Papisa');
INSERT INTO `achievement_mapname` VALUES ('ra_fild01', 'Pradaria Audhumbla');
INSERT INTO `achievement_mapname` VALUES ('ra_fild02', 'C�nion');
INSERT INTO `achievement_mapname` VALUES ('ra_fild03', 'Plan�cie de Ida');
INSERT INTO `achievement_mapname` VALUES ('ra_fild04', 'Pradaria Audhumbla');
INSERT INTO `achievement_mapname` VALUES ('ra_fild05', 'Pradaria Audhumbla');
INSERT INTO `achievement_mapname` VALUES ('ra_fild06', 'Portus Luna');
INSERT INTO `achievement_mapname` VALUES ('ra_fild07', 'C�nion');
INSERT INTO `achievement_mapname` VALUES ('ra_fild08', 'Plan�cie de Ida');
INSERT INTO `achievement_mapname` VALUES ('ra_fild09', 'Pradaria Audhumbla');
INSERT INTO `achievement_mapname` VALUES ('ra_fild10', 'C�nion');
INSERT INTO `achievement_mapname` VALUES ('ra_fild11', 'Plan�cie de Ida');
INSERT INTO `achievement_mapname` VALUES ('ra_fild12', 'Plan�cie de Ida');
INSERT INTO `achievement_mapname` VALUES ('ra_fild13', 'Costa das L�grimas');
INSERT INTO `achievement_mapname` VALUES ('ra_san01', 'Santu�rio');
INSERT INTO `achievement_mapname` VALUES ('ra_san02', 'Santu�rio');
INSERT INTO `achievement_mapname` VALUES ('ra_san03', 'Santu�rio');
INSERT INTO `achievement_mapname` VALUES ('ra_san04', 'Santu�rio');
INSERT INTO `achievement_mapname` VALUES ('ra_san05', 'Santu�rio');
INSERT INTO `achievement_mapname` VALUES ('ice_dun01', 'Caverna de Gelo');
INSERT INTO `achievement_mapname` VALUES ('ice_dun02', 'Caverna de Gelo');
INSERT INTO `achievement_mapname` VALUES ('ice_dun03', 'Caverna de Gelo');
INSERT INTO `achievement_mapname` VALUES ('ice_dun04', 'Caverna de Gelo');
INSERT INTO `achievement_mapname` VALUES ('veins', 'Veins');
INSERT INTO `achievement_mapname` VALUES ('ve_in', 'Interior de Veins');
INSERT INTO `achievement_mapname` VALUES ('ve_in02', 'Interior de Veins');
INSERT INTO `achievement_mapname` VALUES ('ve_fild01', 'Campo de Veins');
INSERT INTO `achievement_mapname` VALUES ('ve_fild02', 'Campo de Veins');
INSERT INTO `achievement_mapname` VALUES ('ve_fild03', 'Campo de Veins');
INSERT INTO `achievement_mapname` VALUES ('ve_fild04', 'Campo de Veins');
INSERT INTO `achievement_mapname` VALUES ('ve_fild05', 'Campo de Veins');
INSERT INTO `achievement_mapname` VALUES ('ve_fild06', 'Campo de Veins');
INSERT INTO `achievement_mapname` VALUES ('ve_fild07', 'Campo de Veins');
INSERT INTO `achievement_mapname` VALUES ('thor_camp', 'Acampamento do Vulc�o de Thor');
INSERT INTO `achievement_mapname` VALUES ('que_thor', 'Vulc�o de Thor');
INSERT INTO `achievement_mapname` VALUES ('thor_v01', 'Vulc�o de Thor');
INSERT INTO `achievement_mapname` VALUES ('thor_v02', 'Vulc�o de Thor');
INSERT INTO `achievement_mapname` VALUES ('thor_v03', 'Vulc�o de Thor');
INSERT INTO `achievement_mapname` VALUES ('que_qsch01', 'Vis�o de Okolnir');
INSERT INTO `achievement_mapname` VALUES ('que_qsch02', 'Vis�o de Okolnir');
INSERT INTO `achievement_mapname` VALUES ('que_qsch03', 'Vis�o de Okolnir');
INSERT INTO `achievement_mapname` VALUES ('que_qsch04', 'Vis�o de Okolnir');
INSERT INTO `achievement_mapname` VALUES ('que_qsch05', 'Vis�o de Okolnir');
INSERT INTO `achievement_mapname` VALUES ('que_qaru01', 'Vis�o de Okolnir');
INSERT INTO `achievement_mapname` VALUES ('que_qaru02', 'Vis�o de Okolnir');
INSERT INTO `achievement_mapname` VALUES ('que_qaru03', 'Vis�o de Okolnir');
INSERT INTO `achievement_mapname` VALUES ('que_qaru04', 'Vis�o de Okolnir');
INSERT INTO `achievement_mapname` VALUES ('que_qaru05', 'Vis�o de Okolnir');
INSERT INTO `achievement_mapname` VALUES ('arug_cas01', 'Mardol');
INSERT INTO `achievement_mapname` VALUES ('arug_cas02', 'Syr');
INSERT INTO `achievement_mapname` VALUES ('arug_cas03', 'Horn');
INSERT INTO `achievement_mapname` VALUES ('arug_cas04', 'Gefn');
INSERT INTO `achievement_mapname` VALUES ('arug_cas05', 'Vanadis');
INSERT INTO `achievement_mapname` VALUES ('aru_gld', 'Feudo de Valfreyja');
INSERT INTO `achievement_mapname` VALUES ('schg_cas01', 'Himinn');
INSERT INTO `achievement_mapname` VALUES ('schg_cas02', 'Andlangr');
INSERT INTO `achievement_mapname` VALUES ('schg_cas03', 'Vidblainn');
INSERT INTO `achievement_mapname` VALUES ('schg_cas04', 'Hljod');
INSERT INTO `achievement_mapname` VALUES ('schg_cas05', 'Skatyrnir');
INSERT INTO `achievement_mapname` VALUES ('sch_gld', 'Feudo de Nithafjoll');
INSERT INTO `achievement_mapname` VALUES ('itemmall', 'Mercado');
INSERT INTO `achievement_mapname` VALUES ('poring_w01', 'Guerra Poring');
INSERT INTO `achievement_mapname` VALUES ('poring_w02', 'Guerra Poring');
INSERT INTO `achievement_mapname` VALUES ('nameless_i', 'Ilha Esquecida');
INSERT INTO `achievement_mapname` VALUES ('nameless_n', 'Ilha Esquecida');
INSERT INTO `achievement_mapname` VALUES ('nameless_in', 'Interior da Ilha Esquecida');
INSERT INTO `achievement_mapname` VALUES ('abbey01', 'Monast�rio');
INSERT INTO `achievement_mapname` VALUES ('abbey02', 'Monast�rio');
INSERT INTO `achievement_mapname` VALUES ('abbey03', 'Monast�rio');
INSERT INTO `achievement_mapname` VALUES ('que_temsky', 'Sala da Papisa');
INSERT INTO `achievement_mapname` VALUES ('z_agit', 'Esconderijo da Gangue Z');
INSERT INTO `achievement_mapname` VALUES ('moscovia', 'Mosc�via');
INSERT INTO `achievement_mapname` VALUES ('mosk_in', 'Interior de Mosc�via');
INSERT INTO `achievement_mapname` VALUES ('mosk_ship', 'Navio');
INSERT INTO `achievement_mapname` VALUES ('mosk_fild01', 'Ilha Baleia');
INSERT INTO `achievement_mapname` VALUES ('mosk_fild02', 'Campo de Mosc�via');
INSERT INTO `achievement_mapname` VALUES ('mosk_dun01', 'Floresta Encantada 1');
INSERT INTO `achievement_mapname` VALUES ('mosk_dun02', 'Floresta Encantada 2');
INSERT INTO `achievement_mapname` VALUES ('mosk_dun03', 'Floresta Encantada 3');
INSERT INTO `achievement_mapname` VALUES ('cave', 'Caverna');
INSERT INTO `achievement_mapname` VALUES ('moc_fild20', 'Ruptura Dimensional');
INSERT INTO `achievement_mapname` VALUES ('moc_fild21', 'Ruptura Dimensional');
INSERT INTO `achievement_mapname` VALUES ('moc_fild22', 'Ruptura Dimensional');
INSERT INTO `achievement_mapname` VALUES ('1@cata', 'Catacumba');
INSERT INTO `achievement_mapname` VALUES ('2@cata', 'Altar do Selo');
INSERT INTO `achievement_mapname` VALUES ('e_tower', 'Ilha Misty');
INSERT INTO `achievement_mapname` VALUES ('1@tower', 'Torre Sem Fim');
INSERT INTO `achievement_mapname` VALUES ('2@tower', 'Torre Sem Fim');
INSERT INTO `achievement_mapname` VALUES ('3@tower', 'Torre Sem Fim');
INSERT INTO `achievement_mapname` VALUES ('4@tower', 'Torre Sem Fim');
INSERT INTO `achievement_mapname` VALUES ('5@tower', 'Torre Sem Fim');
INSERT INTO `achievement_mapname` VALUES ('6@tower', 'Torre Sem Fim');
INSERT INTO `achievement_mapname` VALUES ('bat_room', 'Sala de Espera do Campo de Batalha');
INSERT INTO `achievement_mapname` VALUES ('bat_a01', 'Desfiladeiro Tierra');
INSERT INTO `achievement_mapname` VALUES ('bat_a02', 'Desfiladeiro Tierra');
INSERT INTO `achievement_mapname` VALUES ('bat_b01', 'Flavian');
INSERT INTO `achievement_mapname` VALUES ('bat_b02', 'Flavian');
INSERT INTO `achievement_mapname` VALUES ('bossnia_01', 'Chef�nia');
INSERT INTO `achievement_mapname` VALUES ('bossnia_02', 'Chef�nia');
INSERT INTO `achievement_mapname` VALUES ('bossnia_03', 'Chef�nia');
INSERT INTO `achievement_mapname` VALUES ('bossnia_04', 'Chef�nia');
INSERT INTO `achievement_mapname` VALUES ('bat_c01', 'Krieger von Midgard');
INSERT INTO `achievement_mapname` VALUES ('bat_c02', 'Krieger von Midgard');
INSERT INTO `achievement_mapname` VALUES ('bat_c03', 'Krieger von Midgard');
INSERT INTO `achievement_mapname` VALUES ('mid_camp', 'Acampamento da Expedi��o da Alian�a');
INSERT INTO `achievement_mapname` VALUES ('mid_campin', 'Acampamento da Expedi��o da Alian�a');
INSERT INTO `achievement_mapname` VALUES ('man_fild01', 'Montanhas dos Manuk');
INSERT INTO `achievement_mapname` VALUES ('man_fild03', 'Montanhas dos Manuk');
INSERT INTO `achievement_mapname` VALUES ('spl_fild02', 'Campos dos Esplendores');
INSERT INTO `achievement_mapname` VALUES ('spl_fild03', 'Campos dos Esplendores');
INSERT INTO `achievement_mapname` VALUES ('moc_fild22b', 'Fenda Dimensional');
INSERT INTO `achievement_mapname` VALUES ('schg_que01', 'Pradaria de Morestone');
INSERT INTO `achievement_mapname` VALUES ('schg_dun01', 'Calabou�o Subterr�neo de Castelo');
INSERT INTO `achievement_mapname` VALUES ('1@orcs', 'Caverna Subterr�nea de Orcs');
INSERT INTO `achievement_mapname` VALUES ('2@orcs', 'Caverna Subterr�nea de Orcs');
INSERT INTO `achievement_mapname` VALUES ('que_dan01', 'Campos de Hugel');
INSERT INTO `achievement_mapname` VALUES ('que_dan02', 'Interior da Casa Abandonada de Juno');
INSERT INTO `achievement_mapname` VALUES ('arug_que01', 'Pradaria de Morestone');
INSERT INTO `achievement_mapname` VALUES ('arug_dun01', 'Calabou�o Subterr�neo de Castelo');
INSERT INTO `achievement_mapname` VALUES ('evt_hello', 'Campo Morto');
INSERT INTO `achievement_mapname` VALUES ('1@nyd', 'Ninho de Nidhogg');
INSERT INTO `achievement_mapname` VALUES ('2@nyd', 'Ninho de Nidhogg');
INSERT INTO `achievement_mapname` VALUES ('nyd_dun01', 'A Grande Ferida');
INSERT INTO `achievement_mapname` VALUES ('nyd_dun02', 'A Grande Ferida');
INSERT INTO `achievement_mapname` VALUES ('manuk', 'Vila Mineradora Manuka');
INSERT INTO `achievement_mapname` VALUES ('man_fild02', 'Montanhas dos Manuk');
INSERT INTO `achievement_mapname` VALUES ('man_in01', 'Dentro da Vila Mineradora');
INSERT INTO `achievement_mapname` VALUES ('splendide', 'Base dos Espl�ndidos, Esplendor');
INSERT INTO `achievement_mapname` VALUES ('spl_fild01', 'Campos dos Esplendores');
INSERT INTO `achievement_mapname` VALUES ('spl_in01', 'Dentro de Esplendor');
INSERT INTO `achievement_mapname` VALUES ('spl_in02', 'Dentro de Esplendor');
INSERT INTO `achievement_mapname` VALUES ('brasilis', 'Cidade de Brasilis');
INSERT INTO `achievement_mapname` VALUES ('bra_in01', 'Interior de Brasilis');
INSERT INTO `achievement_mapname` VALUES ('bra_fild01', 'Floresta de Brasilis');
INSERT INTO `achievement_mapname` VALUES ('bra_dun01', 'Caverna das Cataratas');
INSERT INTO `achievement_mapname` VALUES ('bra_dun02', 'Profundezas das Cataratas');
INSERT INTO `achievement_mapname` VALUES ('dewata', 'Dewata');
INSERT INTO `achievement_mapname` VALUES ('dew_in01', 'Dentro da Vila da Tribo Jaty');
INSERT INTO `achievement_mapname` VALUES ('dew_fild01', 'Campos de Dewata');
INSERT INTO `achievement_mapname` VALUES ('dew_dun01', 'Vulc�o Krakatau Volcano');
INSERT INTO `achievement_mapname` VALUES ('dew_dun02', 'Caverna Istana');
INSERT INTO `achievement_mapname` VALUES ('bif_fild01', 'Floresta da Neblina');
INSERT INTO `achievement_mapname` VALUES ('bif_fild02', 'Floresta da Neblina');
INSERT INTO `achievement_mapname` VALUES ('mora', 'Mora - A Vila dos Rafflen');
INSERT INTO `achievement_mapname` VALUES ('dic_in01', 'Casa em Dicastes');
INSERT INTO `achievement_mapname` VALUES ('1@mist', 'Labirinto da Neblina');
INSERT INTO `achievement_mapname` VALUES ('dicastes01', 'El Dicastes');
INSERT INTO `achievement_mapname` VALUES ('dicastes02', 'Floresta Brumbeld Jorhi');
INSERT INTO `achievement_mapname` VALUES ('dic_fild01', 'Campos de El Dicastes 01');
INSERT INTO `achievement_mapname` VALUES ('dic_fild02', 'Campos de El Dicastes 02');
INSERT INTO `achievement_mapname` VALUES ('dic_dun01', 'T�nel Kamidal 01');
INSERT INTO `achievement_mapname` VALUES ('dic_dun02', 'T�nel Kamidal 02');
INSERT INTO `achievement_mapname` VALUES ('dic_dun03', 'T�nel Kamidal');
INSERT INTO `achievement_mapname` VALUES ('malangdo', 'Malangdo');
INSERT INTO `achievement_mapname` VALUES ('mal_in01', 'Interior de Malangdo');
INSERT INTO `achievement_mapname` VALUES ('mal_in02', 'Interior do navio');
INSERT INTO `achievement_mapname` VALUES ('mal_dun01', '�rea de Coral Estrelado');
INSERT INTO `achievement_mapname` VALUES ('1@cash', 'Caverna do Polvo');
INSERT INTO `achievement_mapname` VALUES ('1@pump', 'Esgotos de malangdo');
INSERT INTO `achievement_mapname` VALUES ('2@pump', 'Esgotos de malangdo');
INSERT INTO `achievement_mapname` VALUES ('lhz_dun04', 'Laborat�rio de Somatologia');
INSERT INTO `achievement_mapname` VALUES ('que_lhz', 'Laborat�rio de Somatologia');
INSERT INTO `achievement_mapname` VALUES ('1@lhz', 'Laborat�rio de Wolfchev');
INSERT INTO `achievement_mapname` VALUES ('gld_dun01_2', '2� calabou�o da Guilda');
INSERT INTO `achievement_mapname` VALUES ('gld_dun02_2', '2� calabou�o da Guilda');
INSERT INTO `achievement_mapname` VALUES ('gld_dun03_2', '2� calabou�o da Guilda');
INSERT INTO `achievement_mapname` VALUES ('gld_dun04_2', '2� calabou�o da Guilda');
INSERT INTO `achievement_mapname` VALUES ('gld2_ald', 'Portal do Abismo: L�grimas do Her�i');
INSERT INTO `achievement_mapname` VALUES ('gld2_gef', 'Portal do Abismo: Colina dos Mortos');
INSERT INTO `achievement_mapname` VALUES ('gld2_pay', 'Portal do Abismo: Ventos Ancestrais');
INSERT INTO `achievement_mapname` VALUES ('gld2_prt', 'Portal do Abismo: Caminho do Guerreiro');
INSERT INTO `achievement_mapname` VALUES ('malaya', 'Porto Malaya');
INSERT INTO `achievement_mapname` VALUES ('ma_fild01', 'Baryo Mahiwaga');
INSERT INTO `achievement_mapname` VALUES ('ma_fild02', 'Floresta');
INSERT INTO `achievement_mapname` VALUES ('ma_scene01', 'Lago Bakonawa');
INSERT INTO `achievement_mapname` VALUES ('ma_in01', 'Interior de Malaya');
INSERT INTO `achievement_mapname` VALUES ('ma_dun01', 'Hospital de Bangungot, 1� andar');
INSERT INTO `achievement_mapname` VALUES ('1@ma_h', 'Hospital de Bangungot, 2� andar');
INSERT INTO `achievement_mapname` VALUES ('1@ma_c', 'Caverna Buwaya');
INSERT INTO `achievement_mapname` VALUES ('1@ma_b', 'Esconderijo Bakonawa');
INSERT INTO `achievement_mapname` VALUES ('ma_zif01', 'Interior de Jeepney');
INSERT INTO `achievement_mapname` VALUES ('ma_zif02', 'Interior de Jeepney');
INSERT INTO `achievement_mapname` VALUES ('ma_zif03', 'Interior de Jeepney');
INSERT INTO `achievement_mapname` VALUES ('ma_zif04', 'Interior de Jeepney');
INSERT INTO `achievement_mapname` VALUES ('ma_zif05', 'Interior de Jeepney');
INSERT INTO `achievement_mapname` VALUES ('ma_zif06', 'Interior de Jeepney');
INSERT INTO `achievement_mapname` VALUES ('ma_zif07', 'Interior de Jeepney');
INSERT INTO `achievement_mapname` VALUES ('ma_zif08', 'Interior de Jeepney');
INSERT INTO `achievement_mapname` VALUES ('ma_zif09', 'Interior de Jeepney');
INSERT INTO `achievement_mapname` VALUES ('job_ko', 'Lugar Escondido');

-- Rank SYSTEM
-- v3.0
CREATE TABLE IF NOT EXISTS `achievement_ranking` (
	`account_id` INT(11) NOT NULL,
	`score` INT(11) NOT NULL DEFAULT '0',
	`lastupdate` DATETIME NULL,
  PRIMARY KEY (`account_id`),
  KEY `id` (`account_id`)
) ENGINE=MyISAM;
	
-- Creative Profile System
-- v3.0
CREATE TABLE IF NOT EXISTS `creativesd_profile` (
  `account_id` INT(11) NOT NULL,
  `nickname` VARCHAR(20) NOT NULL DEFAULT 'Nick n�o definido',
  `name` VARCHAR(50) NOT NULL DEFAULT 'Nome n�o definido',
  `sex` SMALLINT(6) NOT NULL DEFAULT '0',
  `birthdate` DATE NULL,
  `country` VARCHAR(32) NOT NULL DEFAULT '',
  `state` VARCHAR(32) NOT NULL DEFAULT '',
  `email` VARCHAR(39) NOT NULL DEFAULT '',
  `skype` VARCHAR(39) NOT NULL DEFAULT '',
  `facebook` VARCHAR(32) NOT NULL DEFAULT '',
  `twitter` VARCHAR(32) NOT NULL DEFAULT '',
  `googleplus` VARCHAR(32) NOT NULL DEFAULT '',
  `instagram` VARCHAR(32) NOT NULL DEFAULT '',
  `linkedin` VARCHAR(32) NOT NULL DEFAULT '',
  `youtube` VARCHAR(32) NOT NULL DEFAULT '',
  `avatar` TEXT,
  `description` MEDIUMTEXT,
  PRIMARY KEY (`account_id`),
  KEY `id` (`account_id`)
) ENGINE=MyISAM;