<?php
// Requirindo Bibliotecas
require_once('../config/Config.php');
require_once('../lib/Sql.class.php');
require_once('../lib/Achievement.class.php');
require_once('../lib/Numbers.class.php');
require_once('../lib/Client.class.php');
require_once('../lib/Profile.class.php');
require_once('../lib/Ranking.class.php');
require_once('../lib/Template.class.php');

// Carregando Arrays com Listas
$BonusStatusList = require_once('../config/BonusStatus.php');
$CategoryList = require_once('../config/Category.php');
$JobNames = require_once('../config/JobName.php');
$TargetDesc = require_once('../config/TargetDesc.php');
$TargetInfo = require_once('../config/TargetInfo.php');
$TargetTypes = require_once('../config/TargetTypes.php');
$Templates = require_once('../config/Templates.php');
$Operators = require_once('../config/Operators.php');
$TargetOptions = require_once('../config/TargetOptions.php');
$RewardsType = require_once('../config/RewardsType.php');
$Country = require_once('../config/Country.php');
$ProfileCfg = require_once('../config/Profile.php');

// Set Index Page
define("CLIENT_PAGE",true);

	$Ach = new Achievements;
	$Client = new Client;
	$Profile = new Profile;
	$Tpl = new Template;
	$Ranking = new Ranking;
	
	$Tpl->init();
	
	if( !isset($_GET['account_id']) || !is_numeric($_GET['account_id']) || !$Client->CheckExist($_GET['account_id']) ) {
		die("ID da conta n�o defindo...");
	}
	else if( !isset($_GET['pass']) || $_GET['pass'] != md5(Config::$ClientPanelPass) )
	{
		die("Senha de autentica��o incorreta...");
	}
	
	$Client->RegisteSession($_GET['account_id']);
	
	$account_id = $_GET['account_id'];
	$pass = $_GET['pass'];
	
	// Configure Selector Page
	$p = !isset($_GET['p']) || empty($_GET['p']) ? 'profile' : $_GET['p'];
	
	// URL completa de backup
	$back_url = urlencode("http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
?>

<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="iso-8859-1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sistema de Conquistas</title>
	<link href="../css/client.css?v=1.0" rel="stylesheet">
	<!-- Font Awesome -->
	<link rel="stylesheet" href="../css/font-awesome.min.css">

  </head>
  <body>
	<div class="main">
		<div class="panel-left">
			<div class="profile">
				<?php
					$Profile->RequestData($Client->account_id);
				?>
				
				<div class="avatar">
					<img src="<?php echo $Profile->avatar_url ? $Profile->avatar_url : "../".$ProfileCfg['DEFAULT_AVATAR'] ?>" />
				</div>
				<ul class="info">
					<li><i class="fa fa-star" aria-hidden="true"></i>&nbsp;&nbsp;<strong>Nick:</strong> <span id="profile_nickname"><?php echo $Profile->nickname ? $Profile->nickname : "N�o definido" ?></span></li>
					<li><i class="fa fa-address-card" aria-hidden="true"></i>&nbsp;&nbsp;<strong>Nome:</strong> <span id="profile_name"><?php echo $Profile->firstname ? $Profile->firstname : "N�o definido" ?></span></li>
					<li><i class="fa fa-venus-mars" aria-hidden="true"></i>&nbsp;&nbsp;<strong>Sexo:</strong> <span id="profile_gender"><?php echo $Profile->sex !== null ? ($Profile->sex?"Feminino":"Masculino") : "N�o definido" ?></span></li>
					<li><i class="fa fa-birthday-cake" aria-hidden="true"></i>&nbsp;&nbsp;<strong>Anivers�rio:</strong> <span id="profile_age"><?php echo $Profile->birthdate ? $Profile->birthdate : "N�o definido" ?></span></li>
					<li><i class="fa fa-calendar" aria-hidden="true"></i>&nbsp;&nbsp;<strong>Idade:</strong> <span id="profile_age"><?php echo $Profile->age ? $Profile->age : "N�o definido" ?></span></li>
					<li><i class="fa fa-globe" aria-hidden="true"></i>&nbsp;&nbsp;<strong>Local:</strong> <span id="profile_birthdate"><?php echo $Profile->state ? $Profile->state : "N�o definido" ?></span></li>
					<li><i class="fa fa-trophy" aria-hidden="true"></i>&nbsp;&nbsp;<strong>Rank:</strong> <?php echo $Profile->rank ? "#".$Profile->rank : "N�o qualificado" ?></li>
					<li><i class="fa fa-spinner" aria-hidden="true"></i>&nbsp;&nbsp;<strong>Progresso:</strong> <?php echo $Profile->progress ."%" ?></li>
				</ul>
			</div>
			
			<div class="side-bar">
				<ul>
					<li class="menu-head">
						<div class="icon-menu"></div>
						<span>Painel de Conquistas</span>
					</li>
					<div class="menu">
						<li>
							<a href="?p=profile&account_id=<?php echo $_GET['account_id']?>&pass=<?php echo $_GET['pass']; if( $back_url ) { echo "&backurl=".$back_url; }?>"<?php if( $p == "profile" ) { echo " class=\"active\""; } ?>><i class="fa fa-user" aria-hidden="true"></i> Meu Perfil</a>
						</li>
						<li>
							<a href="?p=list&account_id=<?php echo $_GET['account_id']?>&pass=<?php echo $_GET['pass']; if( $back_url ) { echo "&backurl=".$back_url; }?>"<?php if( $p == "list" ) { echo " class=\"active\""; } ?>><i class="fa fa-star" aria-hidden="true"></i> Lista de Conquistas</a>
						</li>
						<li>
							<a href="?p=ranking&account_id=<?php echo $_GET['account_id']?>&pass=<?php echo $_GET['pass']; if( $back_url ) { echo "&backurl=".$back_url; }?>"<?php if( $p == "ranking" ) { echo " class=\"active\""; } ?>><i class="fa fa-trophy" aria-hidden="true"></i> Ranking</a>
						</li>
						<li>
							<a href="?p=help&account_id=<?php echo $_GET['account_id']?>&pass=<?php echo $_GET['pass']; if( $back_url ) { echo "&backurl=".$back_url; }?>"<?php if( $p == "help" ) { echo " class=\"active\""; } ?>><i class="fa fa-question-circle" aria-hidden="true"></i> Ajuda</a>
						</li>
					</div>	
				</ul>
			</div>
		</div>
		<?php
			if( !file_exists("{$p}.php") )
			{
				$help_rand = rand(1,6);
		?>
		<div class="page-error">
			<strong>Ooops!</strong>
			<p>P�gina n�o encontrada...</p>
			<?php if( isset($_GET['backurl']) && trim($_GET['backurl']) ) { ?>
			<p class="back-url"><a href="<?php echo urldecode($_GET['backurl']) ?>" class="pull-left"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Voltar</a></p>
			<?php } ?>
			<div class="alert-icon-help-<?php echo $help_rand; ?>"></div>
		</div>
		<?php
			} else {
				require_once($p.".php");
			}
		?>
    </div>
	
	<a href="#" class="go-top"></a>
  </body>
</html>