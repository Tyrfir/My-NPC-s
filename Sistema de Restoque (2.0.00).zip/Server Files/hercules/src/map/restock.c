// © Creative Services and Development
// Site Oficial: www.creativesd.com.br
// Termos de Contrato e Autoria em: http://creativesd.com.br/?p=termos

#define HERCULES_CORE

#include "map/battle.h"
#include "map/itemdb.h"
#include "map/map.h"
#include "map/pc.h"
#include "map/restock.h"
#include "map/storage.h"

#include "common/cbasetypes.h"
#include "common/mmo.h"
#include "common/nullpo.h"
#include "common/utils.h"

#include <stdlib.h>


bool restock_check_vip(struct map_session_data* sd)
{
	if (battle_config.restock_vip_type == 2 && pc_get_group_level(sd) >= battle_config.restock_group_level)
		return true;
	else if (pc_get_group_id(sd) >= battle_config.restock_group_level)
		return true;
	else
		return false;
}

int restock_get_slot(struct map_session_data *sd, int nameid, int max)
{
	int i = 0;

	nullpo_retr(0,sd);

	ARR_FIND(0, max, i, sd->status.restock[i].nameid == nameid);
	if( i >= max )
		return max;

	return i;
}

int restock_get_item(struct map_session_data *sd, int nameid, int reserved_id)
{
	struct item* it = NULL;
	int i, amount = 0, max;

	nullpo_retr(0,sd);

	// Storage Open
	if( sd->state.storage_flag == STORAGE_FLAG_NORMAL || sd->state.storage_flag == STORAGE_FLAG_GUILD )
		return 0;

	if( nameid < 0 )
		return 0;

	max = restock_check_vip(sd) ? battle_config.restock_vip_max_items : battle_config.restock_regular_max_items;
	if( (i = restock_get_slot(sd,nameid,max)) >= max )
		return 0;

	amount = sd->status.restock[i].amount;

	if (reserved_id)
		ARR_FIND(0, VECTOR_LENGTH(sd->storage.item), i, VECTOR_INDEX(sd->storage.item, i).nameid == nameid && VECTOR_INDEX(sd->storage.item, i).card[0] == CARD0_CREATE && MakeDWord(VECTOR_INDEX(sd->storage.item, i).card[2], VECTOR_INDEX(sd->storage.item, i).card[3]) == reserved_id);
	else
		ARR_FIND(0, VECTOR_LENGTH(sd->storage.item), i, VECTOR_INDEX(sd->storage.item, i).nameid == nameid);

	if( i >= VECTOR_LENGTH(sd->storage.item) )
		return 0;

	it = &VECTOR_INDEX(sd->storage.item, i);

	if( it->amount < amount )
		amount = it->amount;

	if( amount )
		storage->get(sd, i, amount);

	// Close Storage (Bug fix)
	storage->close(sd);
	return amount;
}

int restock_add_item(struct map_session_data *sd, int nameid, int amount)
{
	int i, max;

	nullpo_retr(-1,sd);

	max = restock_check_vip(sd) ? battle_config.restock_vip_max_items : battle_config.restock_regular_max_items;
	i = restock_get_slot(sd,nameid,max);
	if( i >= max )
		i = restock_get_slot(sd,0,max);

	// Check New Slot
	if( i < MAX_RESTOCK ) {
		sd->status.restock[i].nameid = nameid;
		sd->status.restock[i].amount = amount;
		return 1;
	}
	return 0;
}

int restock_del_item(struct map_session_data *sd, int nameid)
{
	int i, max;

	nullpo_retr(-1, sd);

	max = restock_check_vip(sd) ? battle_config.restock_vip_max_items : battle_config.restock_regular_max_items;
	i = restock_get_slot(sd,nameid,max);

	if( i < max ) {
		sd->status.restock[i].nameid = 0;
		sd->status.restock[i].amount = 0;
		return 1;
	}
	return 0;
}

int restock_clear(struct map_session_data* sd)
{
	int i, c = 0, max;

	nullpo_retr(-1, sd);

	max = restock_check_vip(sd) ? battle_config.restock_vip_max_items : battle_config.restock_regular_max_items;

	for( i = 0; i < MAX_RESTOCK; i++ ) {
		struct item_data* id;
		if( sd->status.restock[i].nameid == 0 )
			continue;
		else if( sd->status.restock[i].amount == 0 || (id = itemdb->exists(sd->status.restock[i].nameid)) == NULL ) {
			sd->status.restock[i].nameid = 0;
			sd->status.restock[i].amount = 0;
		}
		else c++;
	}
	return c;
}

bool restock_check_zone(int16 m)
{
	if( map->list[m].flag.restock_on )
		return true;
	if( map->list[m].flag.restock_off )
		return false;
	if( !map->list[m].flag.pvp && !map->list[m].flag.gvg && !map->list[m].flag.battleground && !map->list[m].flag.gvg_castle )
		return true;
	if( (battle_config.restock_maps&0x1) && map->list[m].flag.pvp )
		return true;
	if( (battle_config.restock_maps&0x10) && map->list[m].flag.gvg )
		return true;
	if( (battle_config.restock_maps&0x100) && map->list[m].flag.battleground )
		return true;
	if( (battle_config.restock_maps&0x200) && map->list[m].flag.gvg_castle && !map->agit_flag && !map->agit2_flag )
		return true;
	if( (battle_config.restock_maps&0x400) && map->list[m].flag.gvg_castle && (map->agit_flag || map->agit2_flag) )
		return true;

	return false;
}
