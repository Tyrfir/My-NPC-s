$(document).ready(function(){
	jQuery.fn.SearchChanged = function() {
		var element = $("option:selected", this);
		var options = element.attr("enabledOpts");
		
		if( !options || options.length <= 0 )
		{
			$(this).SearchOptions('all', false);
			return;
		}
		
		var value = options.split(",");
		
		$(this).SearchOptions('hour', (value.indexOf("hour")>=0?true:false));
		$(this).SearchOptions('timer', (value.indexOf("timer")>=0?true:false));
		$(this).SearchOptions('amount', (value.indexOf("amount")>=0?true:false));
		$(this).SearchOptions('target', (value.indexOf("target")>=0?true:false));
	}
	
	jQuery.fn.SearchOptions = function(target, flag) {
		flag = flag?false:true;
		
		// Enable Target
		if( target == 'all' || target == 'target' )
		{
			if( $("#search #search_target").is(":visible") == flag )
				$("#search #search_target").slideToggle("slow");
			
			$("#search #search_target #target").prop('disabled', flag);
		}
		
		// Enable Target Opt&Amount
		if( target == 'all' || target == 'amount')
		{
			if( $("#search #search_amount").is(":visible") == flag )
				$("#search #search_amount").slideToggle("slow");
			
			$("#search #search_amount #amount").prop('disabled', flag);
			$("#search #search_amount #amount_opt").prop('disabled', flag)
		}
		
		// Enable Target Hours
		if( target == 'all' || target == 'hour' )
		{
			if( $("#search #search_hour").is(":visible") == flag )
				$("#search #search_hour").slideToggle("slow");
			
			$("#search #search_hour #hour_opt").prop('disabled', flag);
			$("#search #search_hour #hour").prop('disabled', flag);
			$("#search #search_hour #minute").prop('disabled', flag);
		}
		
		// Enable Target Timers in Minutes
		if( target == 'all' || target == 'timer' )
		{
			if( $("#search #search_timer").is(":visible") == flag )
				$("#search #search_timer").slideToggle("slow");
			
			$("#search #search_timer #timer_opt").prop('disabled', flag);
			$("#search #search_timer #timer").prop('disabled', flag);
		}
		return;
	}
	
	$("#search #target_type").SearchChanged();
	
	$("#search #primary-search").click(function() {
		$key = $("#search #primary-key").val();
		$("#search #form-search input[name='key']").val($key);
		$("#search #form-search").submit();
	});
	
	$("#search #form-search").submit(function() {
		$key = $("#search #primary-key").val();
		$("#search #form-search input[name='key']").val($key);
		return true;
	});
		
	$("#search #primary-key").keypress(function(e) {
		if( e.which == 13 ) {
			$key = $(this).val();
			$("#search #form-search input[name='key']").val($key);
			$("#search #form-search").submit();
		}
	});
	
	$("#search #target").keydown(function(e) {
		$targettype = $("#search #target_type").val();
		$(this).AutoSuggest(e,'type='+$targettype);
	});
	
	$("#search #target_type").change(function() {
		$(this).SearchChanged();
	});
});