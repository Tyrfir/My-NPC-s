<?php
	if( !defined("MAIN_PAGE") )
		exit;
	
	// Requer esta conectado...
	if( !isset($_GET['account_id']) || empty($_GET['account_id']) || !is_numeric($_GET['account_id']) )
	{
		$Auth->RequireLogin();
	
		// Get Account_id
		$account_id = $Auth->account_id;
	}
	else {
		// Account_id from other player
		$account_id = $_GET['account_id'];
		
		if( !$Auth->CheckExist($account_id) )
		{
			$ErrorMessage = '<p>Perfil n�o encontrado.<br/> Aguarde, voc� est� sendo redirecionado...</p>';
			include_once('contents/errors/not-found.php');
			exit;
		}
	}
	
	// Get HTML Header
	require_once('contents/includes/header.php');
	if( $Auth->CheckSession() ) {
		require_once('contents/includes/menu.php');
		$class_page = 'page';
	}
	else {
		$class_page = 'page-no-menu';
?>
	<div class="logo">
		<div class="logo-icon"></div> <i class="fa fa-trophy" aria-hidden="true"></i> Conquistas
	</div>
<?php
	}
	
	// Request Data
	$Profile->RequestData($account_id);
?>
	<div class="content <?php echo $class_page; ?> page-profile margin-xs-top-10x">
		<div class="container-fluid">
			<div class="row margin-10x-top">
				<div class="col-xs-12">
					<h3><span class="glyphicon glyphicon-star" aria-hidden="true"></span>&nbsp;&nbsp;Perfil de <?php echo $Profile->nickname ?></h3>
				</div>
			</div>
			<hr>
			<div class="row margin-20x-top margin-20x-bottom">
				<div class="col-xs-12">
					<div class="avatar-box pull-left"><img class="avatar" src="<?php echo $Profile->avatar_url ? $Profile->avatar_url : $ProfileCfg['DEFAULT_AVATAR'] ?>"></div>
					<div class="info-box pull-right">
						<div class="box"><i class="fa fa-address-card" aria-hidden="true"></i> <span>Nome Completo:</span> <?php echo $Profile->name ? $Profile->name : "N�o informado" ?></div>
						<div class="box-half">
							<div class="box"><i class="fa fa-star-o" aria-hidden="true"></i> <span>Nick:</span> <?php echo $Profile->nickname ?></div>
							<div class="box"><i class="fa fa-venus-mars" aria-hidden="true"></i> <span>Sexo:</span> <?php echo $Profile->sex?"Feminino":"Masculino" ?></div>
						</div>
						<div class="box-half">
							<div class="box"><i class="fa fa-calendar" aria-hidden="true"></i> <span>Nascimento:</span> <?php echo $Profile->birthdate ? $Profile->birthdate : "N�o informado" ?></div>
							<div class="box"><i class="fa fa-asterisk" aria-hidden="true"></i> <span>Idade:</span> <?php echo $Profile->age ? $Profile->age : "N�o informado" ?></div>
							<div class="clear"></div>
						</div>
						<?php
							$tmp_local = array();
							if( $Profile->country )
								$tmp_local[] = $Profile->country;
							if( $Profile->state && count($tmp_local) )
								$tmp_local[] = "(" . $Profile->state . ")";
							else if( $Profile->state )
								$tmp_local[] = $Profile->state;
							
							$local = implode(" ", $tmp_local);
						?>
						<div class="box"><i class="fa fa-globe" aria-hidden="true"></i> <span>Local:</span> <?php echo $local ? $local : "N�o informado" ?></div>
						<div class="box"><i class="fa fa-trophy" aria-hidden="true"></i> <span>Rank:</span> <?php echo $Profile->rank?$Profile->rank."� colocado":"N�o qualificado" ?></div>
						<div class="box"><i class="fa fa-spinner" aria-hidden="true"></i> <span>Progresso:</span> <?php echo $Profile->progress ."%" ?> (<strong><?php echo $Profile->total ?></strong> de <strong><?php echo $Profile->total_db ?></strong> conquistas)</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php
	if( count($Profile->last_achievements) ) {
?>
	<div class="content <?php echo $class_page; ?> page-profile margin-xs-top-10x">
			<div class="row margin-10x-top">
				<div class="col-xs-12">
					<label><i class="fa fa-trophy" aria-hidden="true"></i> Conquistas mais recentes:</label>
					<div class="row last-achievements">
			<?php
				for( $i=0; $i < count($Profile->last_achievements); $i++ )
				{
					$name = $Profile->last_achievements[$i]['name'];
					$icon = $Profile->last_achievements[$i]['icon'];
					$date = date_create($Profile->last_achievements[$i]['date_time']);
					$date = date_format($date, "d.m.Y");
					
					if( file_exists("images/icons/{$icon}.png") )
						$img = "images/icons/{$icon}.png";
					else if( file_exists("images/icons/{$icon}.gif") )
						$img = "images/icons/{$icon}.gif";
					else
						$img = "images/null.png";
			?>
					<div class="col-xs-1 box-icon<?php if( $i >= $ProfileCfg['MAX_LAST'] ) { echo " hidden-icon"; } ?>">
						<div class="icon" data-toggle="tooltip" title="<?php echo $date; ?><br><?php echo $name; ?>"><img src="<?php echo $img; ?>"></div>
					</div>
			<?php
				}
			?>
					</div>
			<?php
				if( count($Profile->last_achievements) > $ProfileCfg['MAX_LAST'] ) {
			?>
				<div class="margin-10x-bottom pull-right">
					<a href="#" class="show-more"><span class="glyphicon glyphicon-plus"></span> Mostrar todas</a>
				</div>
			<?php
				}
			?>
				</div>
			</div>
<?php
	}
?>
		</div>
	</div>
<?php
	if( $Profile->description ) {
?>
	<div class="content <?php echo $class_page; ?> page-profile margin-xs-top-10x">
		<div class="container-fluid">
			<div class="row margin-10x-top">
				<div class="col-xs-12">
					<h3><i class="fa fa-info-circle"></i>&nbsp;&nbsp;&nbsp;Sobre mim</h3>
				</div>
			</div>
			<hr>
			<div class="row margin-20x-bottom">
				<div class="col-xs-12">
					<div class="about-me"><?php echo $Profile->description; ?></div>
				</div>
			</div>
		</div>
	</div>
<?php
	}
	
	if( $Profile->email || $Profile->skype || $Profile->facebook || $Profile->twitter || $Profile->googleplus || $Profile->instagram || $Profile->linkedin || $Profile->youtube ) {
?>
	<div class="content <?php echo $class_page; ?> page-profile margin-xs-top-10x">
		<div class="container-fluid socials">
			<div class="row margin-10x-top">
				<div class="col-xs-12">
					<h3><i class="fa fa-share-alt"></i>&nbsp;&nbsp;&nbsp;Contato e Redes Sociais</h3>
				</div>
			</div>
			<hr>
			<div class="row">
			<?php 
				if( $Profile->email ) {
			?>
				<div class="col-xs-4">
					<label for="email"><i class="fa fa-envelope" aria-hidden="true"></i> Email:</label>
					<span class="form-control"><?php echo $Profile->email ?></span>
				</div>
			<?php
				}
				
				if( $Profile->skype ) {
			?>
				<div class="col-xs-4">
					<label for="skype"><i class="fa fa-skype" aria-hidden="true"></i> Skype:</label>
					<span class="form-control"><?php echo $Profile->skype ?></span>
				</div>
			<?php
				}
				
				if( $Profile->facebook ) {
			?>
				<div class="col-xs-4">
					<label for="facebook"><i class="fa fa-facebook-official" aria-hidden="true"></i> Facebook:</label>
					<div class="input-group">
					  <span class="input-group-addon">ID</span>
					  <input type="text" name="facebook" id="facebook" class="form-control" maxlength="<?php echo $CharRules['MAX_FACEBOOK'] ?>" value="<?php echo $Profile->facebook ?>">
					</div>
				</div>
			<?php
				}
				
				if( $Profile->twitter) {
			?>
				<div class="col-xs-4">
					<label for="twitter"><i class="fa fa-twitter-square" aria-hidden="true"></i> Twitter:</label>
					<div class="input-group">
					  <span class="input-group-addon">@</span>
					  <input type="text" name="twitter" id="twitter" class="form-control" maxlength="<?php echo $CharRules['MAX_TWITTER'] ?>" value="<?php echo $Profile->twitter ?>">
					</div>
				</div>
			<?php
				}
				
				if( $Profile->googleplus ) {
			?>
				<div class="col-xs-4">
					<label for="gplus"><i class="fa fa-google-plus-official" aria-hidden="true"></i> Google+:</label>
					<div class="input-group">
					  <span class="input-group-addon">Perfil</span>
					  <input type="text" name="gplus" id="gplus" class="form-control" max="<?php echo $CharRules['MAX_GOOGLEPLUS']; ?>" value="<?php echo $Profile->googleplus ?>">
					</div>
				</div>
			<?php
				}
				
				if( $Profile->instagram ) {
			?>
				<div class="col-xs-4">
					<label for="instagram"><i class="fa fa-instagram" aria-hidden="true"></i> Instagram:</label>
					<div class="input-group">
					  <span class="input-group-addon">Perfil</span>
					  <input type="text" name="instagram" id="instagram" class="form-control" max="<?php echo $CharRules['MAX_INSTAGRAM']; ?>" value="<?php echo $Profile->instagram ?>">
					</div>
				</div>
			<?php
				}
				
				if( $Profile->linkedin ) {
			?>
				<div class="col-xs-4">
					<label for="linkedin"><i class="fa fa-linkedin-square" aria-hidden="true"></i> Linkedin:</label>
					<div class="input-group">
					  <span class="input-group-addon">Perfil</span>
					  <input type="text" name="linkedin" id="linkedin" class="form-control" maxlength="<?php echo $CharRules['MAX_LINKEDIN'] ?>" value="<?php echo $Profile->linkedin ?>">
					</div>
				</div>
			<?php
				}
				
				if( $Profile->youtube ) {
			?>
				<div class="col-xs-4">
					<label for="youtube"><i class="fa fa-youtube-square" aria-hidden="true"></i> Youtube:</label>
					<div class="input-group">
					  <span class="input-group-addon">Canal</span>
					  <input type="text" name="youtube" id="youtube" class="form-control" maxlength="<?php echo $CharRules['MAX_YOUTUBE'] ?>" value="<?php echo $Profile->youtube ?>">
					</div>
				</div>
			<?php
				}
			?>
			</div>
		</div>
	</div>
<?php
	}
	
	// Get HTML Bottom Header
	require_once('contents/includes/bottom.php');
?>