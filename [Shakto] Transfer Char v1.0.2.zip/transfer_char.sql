--
-- Table structure for table `transfer_char`
--
CREATE TABLE IF NOT EXISTS `transfer_char` (
  `unique_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `origin_accountid` int UNSIGNED NOT NULL DEFAULT '0',
  `origin_charid` int UNSIGNED NOT NULL DEFAULT '0',
  `destination_accountid` int UNSIGNED NOT NULL DEFAULT '0',
  `transfert_date` int UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`unique_id`)
) ENGINE=MyISAM;
