<?php
if (!defined('FLUX_ROOT')) exit;
?>

<h2 style="padding-top: 10px;margin-left: 20px;">Staff</h2>
<p style="margin-left: 20px;">
<img src="<?php echo $this->themePath('img/6.bmp' . $Image6[0]); ?>" alt="" /><br>
Name : <b>Your™</b><br>
Position: Owner, Administrator, Scripter, Developer, Designer, Web Developer, Web Designer
</p>
<br>
