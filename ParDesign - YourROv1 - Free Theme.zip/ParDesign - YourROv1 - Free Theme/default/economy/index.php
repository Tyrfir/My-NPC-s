<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2>Economy</h2>