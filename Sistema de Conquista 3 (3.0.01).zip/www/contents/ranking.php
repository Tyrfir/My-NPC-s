<?php
	if( !defined("MAIN_PAGE") )
		exit;
	
	// Get HTML Header
	require_once('contents/includes/header.php');
	if( $Auth->CheckSession() ) {
		require_once('contents/includes/menu.php');
		$class_page = 'page';
		$class_nav = 'navbar-bottom';
	}
	else {
		$class_page = $class_nav = 'page-no-menu';
?>
	<div class="logo">
		<div class="logo-icon"></div> <i class="fa fa-trophy" aria-hidden="true"></i> Conquistas
	</div>
<?php
	}
	
	// Paginator
	$paginator = !isset($_GET['page']) || $_GET['page'] == 0 ? 1 : $_GET['page'];
	$init = ($paginator-1)*Config::$rank_max_rows;

	// Get Ranking
	$Ranking->Load($init);
?>
	<div class="content <?php echo $class_page; ?> margin-xs-top-10x">
		<div class="container-fluid">
			<div class="row margin-10x-top">
				<div class="col-xs-12">
					<h3><span class="glyphicon glyphicon-star" aria-hidden="true"></span>&nbsp;&nbsp;Top Conquistadores</h3>
				</div>
			</div>
			<hr>
			<div class="row margin-20x-top margin-20x-bottom">
				<div class="col-xs-12">
					<table class="ranking-list">
					  <thead>
						<tr>
							<th>#</th>
							<th>Jogador</th>
							<th>Pontua��o</th>
							<th>Sexo</th>
							<th>Atualiza��o</th>
							<th>Player On-line</th>
						</tr>
					  </thead>
					  <tbody>
		<?php
			for( $i=0; $i < $Ranking->count; $i++ )
			{
				$account_id = $Ranking->players['account_id'][$i];
				$nickname = $Ranking->players['nickname'][$i];
				$sex = $Ranking->players['sex'][$i];
				$tmp_online = $Ranking->players['online'][$i];
				
				if( count($tmp_online) )
					$online = '<span data-toggle="tooltip" title="<label>Personagem encontra-se em:</label>' . $tmp_online[1] . ' ' . $tmp_online[2] . ', ' . $tmp_online[3] .'">' . $tmp_online[0] . '</span>';
				else
					$online = '<span class="off-line">OFF</span>';
		?>
						<tr>
							<td><?php echo $Ranking->players['position'][$i] ?></td>
							<td><a href="?p=perfil/visualizar&account_id=<?php echo $account_id ?>"><?php echo $nickname ? $nickname : "N�o definido" ?></a></td>
							<td><?php echo $Ranking->players['score'][$i] ?></td>
							<td><?php echo $sex !== null ? ($sex?"Feminino":"Masculino") : "N�o definido" ?></td>
							<td><?php echo $Ranking->players['lastupdate'][$i] ?></td>
							<td><?php echo $online ?></td>
						</tr>
		<?php
			}
		?>
					  </tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	
	<div class="content <?php echo $class_nav ?> no-background">
		<div class="row">
			<div class="col-xs-12 text-center navbar">
			<?php
				// CreateNavBar
				if( $Ranking->total > Config::$rank_max_rows ) {
					$Tpl->createNavBar($paginator,$Ranking->total,Config::$rank_max_rows,$_GET);
					$Tpl->showNavigation();
				}
			?>
			</div>
		</div>
	</div>
<?php
	// Get HTML Bottom Header
	require_once('contents/includes/bottom.php');
?>