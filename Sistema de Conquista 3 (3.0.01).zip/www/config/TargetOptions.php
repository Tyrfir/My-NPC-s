<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  *---------------------------------------------------------------*/
// Permite configurar as op��es de acordo com os alvos.
//
// !Isso impede dos jogadores enviar url personalizadas para personalizar seus filtros pois alguns alvos sobre poem o alvo!
//
// Valores Aceitos:
//	amount -> Habilita a Op��o quantidade
//	target -> Habilita a Op��o de Alvo
//	timer -> Habilita a Op��o de Tempo em Minutos
//	hour -> Habilita a Op��o de Hora e Minuto
//
return array(
	 0 => array('amount'),
	 1 => array('amount'),
	 2 => array('amount'),
	 3 => array('amount'),
	 4 => array('amount'),
	 5 => array('amount'),
	 6 => array('amount'),
	 7 => array('amount'),
	 8 => array('amount'),
	 9 => array('amount'),
	10 => array('timer'),
	11 => array('amount', 'target'),
	12 => array('amount', 'target'),
	13 => array('amount', 'target'),
	14 => array('amount', 'target'),
	15 => array('target'),
	// 16 nenhum alvo, � qualquer mvp.
	17 => array('hour', 'amount'),
	18 => array('amount'),
	19 => array('amount'),
	20 => array('amount'),
	21 => array('amount'),
	22 => array('target'),
	23 => array('amount', 'target'),
	24 => array('target'),
	25 => array('amount','target'),
	26 => array('amount','target'),
	27 => array('amount','target'),
	28 => array('amount','target'),
	29 => array('amount'),
	30 => array('amount'),
	31 => array('amount'),
	32 => array('amount','target'),
	33 => array('amount','target'),
	34 => array('amount','target'),
	35 => array('amount'),
	36 => array('amount'),
	37 => array('amount'),
	38 => array('amount','target'),
	39 => array('amount','target'),
	40 => array('amount','target'),
	41 => array('amount'),
	42 => array('amount'),
	43 => array('amount'),
	44 => array('amount'),
	45 => array('amount'),
	46 => array('amount'),
	47 => array('amount'),
	48 => array('amount','target'),
	49 => array('amount'),
	50 => array('amount'),
	51 => array('timer'),
	52 => array('target')
);