<?php
if (!defined('FLUX_ROOT')) exit;
?>

<h2 style="margin-left: 20px;">Server Information</h2>

<p style="margin-left: 20px;">
We do not offer item to player to join our server<br>
Official Opening: February 21, 2014<br>
Website: (Don't Know Yet)<br>
Facebook Fanpage: <a href="http://www.facebook.com/EnthusiasmRO/;">Fanpage</a><br>
Facebook Group: <a href="http://www.facebook.com/EnthusiasmGroup/;">Group</a><br><br>
Max Level: 255/120<br>
Max Stats: 255<br>
Attack Speed: 196<br>
Rate: 10k/10k/10k<br>
<br>
Friendly Community<br>
Friendly GM<br>
Balance Server<br>
Easy Quest<br>
<br>
Freebies:<br>
Gold Helm<br>
Gold Ear<br>
Gold Rune<br>
Gold Armor<br>
Gold Shield<br>
Gold Manteau<br>
Gold Shoes<br>
Gold Ring x2<br>
Doppelganger Card<br>
Ghostring Card<br>
Thara Frog Card<br>
Deviling Card<br>
Amon Ra Card<br>
Mantis Card x2<br>
</p>