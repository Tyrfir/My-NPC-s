<html>
<head>
<title>Erro 404 :: P�gina n�o encontrada</title>
<style>
body {
	text-align:center;
}
</style>
<script type="text/javascript">
	setTimeout(function() {
		window.location.href = "../../?";
	},5000);
</script>
</head>
<body>
    <img src="../../images/errors/404.png">
</body>
</html>