<?php
	if( !defined("CLIENT_PAGE") )
		exit;
?>
	<div class="page-help">
		<div class="help-content">
			<h3>Ajuda</h3>
			<p>Bem vindo a Corpora��o Kafra, estamos aqui para ajud�-lo<br/>no que precisar:</p>
			<ul class="index">
				<li><a href="#ach-about">Como realizar conquistas.</a></li>
				<li><a href="#search">Como buscar conquistas.</a>
					<ul>
						<li><a href="#ghostmode">Conquistas fantasmas.</a></li>
						<li><a href="#search-web">Na interface Web.</a></li>
						<li><a href="#search-ingame">Na interface In-Game.</a></li>
					</ul>
				</li>
				<li><a href="#profile">Informa��es do Meu Perfil.</a></li>
				<li><a href="#ranking">Ranking de Jogadores.</a></li>
				<li><a href="#devel">Sobre o Sistema de Conquistas.</a></li>
			</ul>
		</div>
		<?php if( isset($_GET['backurl']) && trim($_GET['backurl']) ) { ?>
		<p class="back-url"><a href="<?php echo urldecode($_GET['backurl']) ?>" class="pull-left"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Voltar</a></p>
		<?php } ?>
		<div class="alert-icon-help-1"></div>
	</div>
	
	<div class="page-help" id="ach-about">
		<div class="help-content">
			<h3>Como realizar conquistas</h3>
			<p>Conquistas podem ser efetuadas em seu pr�prio Gameplay, seja derrotando jogadores, monstros e at� mesmo visitando alguns mapas no jogo.</p>
			<p>Ao realizar uma conquista voc� ser� notificado e tamb�m poder� ganhar recompensas, mais n�o para por ai n�o.</p>
			<p>As recompensas garante rankeamento junto com uma data de �ltima atualiza��o que ser� exibido junto com seu Perfil em nosso Ranking.</p>
		</div>
		<?php if( isset($_GET['backurl']) && trim($_GET['backurl']) ) { ?>
		<p class="back-url"><a href="<?php echo urldecode($_GET['backurl']) ?>" class="pull-left"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Voltar</a></p>
		<?php } ?>
		<div class="alert-icon-help-2"></div>
	</div>

	<div class="page-help" id="search">
		<div class="help-content">
			<h3>Como buscar conquistas</h3>
			<p>Voc� pode buscar conquistas aqui mesmo na <strong>interface in-game</strong>, ou pode at� mesmo visitar nossa <strong>interface web</strong>, localizada em: <span class="fake-site"><?php echo Config::$WebSite ?><span></p>
			<p>Voc� pode buscar conquistas atrav�s de seus nomes e alvos, dependendo da interface � at� f�cil, podendo modelar com seus filtros avan�ados.</p>
			<p id="ghostmode"><i class="fa fa-exclamation-circle" aria-hidden="true"></i> <strong>Conquistas fantasmas</strong>, que ser� exibido ap�s voc� efetuar a conquista, ent�o voc� pode procurar por livre e espont�nea vontade conquistas fantasmas.</p>
			<p id="search-web"><i class="fa fa-exclamation-circle" aria-hidden="true"></i> Na <strong>interface web</strong> a busca se torna mais f�cil pois sua busca inteligente se adapta de acordo com o alvo a ser procurado.</p>
			<p id="search-ingame"><i class="fa fa-exclamation-circle" aria-hidden="true"></i> Na <strong>interface in-game</strong> a busca se torna um pouco mais complexo ent�o se atente aos alvos listado abaixo:
				<ul class="help-ul">
					<li><strong>Jogador, Jogador de outro Cl�, Jogador de outro Ex�rcito:</strong> N�o � necess�rio definir um alvo, ele mesmo indica que o alvo � o jogador.</li>
					<li><strong>Vencer Batalhas Campais:</strong> N�o � necess�rio definir um alvo, ele mesmo indica que o alvo � as batalhas campais.</li>
					<li><strong>Destruir o Emperium:</strong> N�o � necess�rio definir um alvo, ele mesmo indica que o alvo � o monstro Emperium.</li>
					<li><strong>Ajuntar, Gastar quantidade de Zeny em progresso ou �nica vez:</strong> N�o � necess�rio definir um alvo, ele mesmo indica que o alvo � Zeny.</li>
					<li><strong>Construir ou Destruir Runas Guardi�s ou Barricadas:</strong> N�o � necess�rio definir um alvo, ele mesmo indica que o alvo s�o Runas Guardi�s ou Barricadas.</li>
					<li><strong>Aguardar um determinado tempo:</strong> N�o precisa definir o alvo, mais a quantidade deve ser definida em minutos.</li>
					<li><strong>Estar presente em um determinado hor�rio:</strong> Voc� deve utilizar no alvo o formato <strong>HH:MM</strong>.</li>
					<li><strong>N�vel de Base ou Clase:</strong> N�o precisa definir o alvo, ele mesmo reconhece de acordo com sua especifica��o.</li>
					<li><strong>Terminar a Conquista em um determinado tempo:</strong> O alvo deve ser informado em segundos.</li>
				</ul>
			</p>
		</div>
		<?php if( isset($_GET['backurl']) && trim($_GET['backurl']) ) { ?>
		<p class="back-url"><a href="<?php echo urldecode($_GET['backurl']) ?>" class="pull-left"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Voltar</a></p>
		<?php } ?>
		<div class="alert-icon-help-3"></div>
	</div>
	
	<div class="page-help" id="profile">
		<div class="help-content">
			<h3>Informa��es do Meu Perfil</h3>
			<p>� poss�vel visualizar seu perfil e de outros jogadores durante o jogo.</p>
			<p>Seu perfil tr�s algumas informa��es pessoais e a lista de �ltimas conquistas alcan�adas por voc�, isto acontece com o mesmo de outros jogadores.</p>
		</div>
		<?php if( isset($_GET['backurl']) && trim($_GET['backurl']) ) { ?>
		<p class="back-url"><a href="<?php echo urldecode($_GET['backurl']) ?>" class="pull-left"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Voltar</a></p>
		<?php } ?>
		<div class="alert-icon-help-4"></div>
	</div>
	
	<div class="page-help" id="ranking">
		<div class="help-content">
			<h3>Ranking de Jogadores</h3>
			<p>O Sistema de Conquista possu� um Sistema de Rankeamento pr�prio, este sistema � organizado por quantidade de conquistas j� feita e a �ltima data de atualiza��o, isso defini quem foram os primeiros e quem foram os �ltimos jogadores a alcan�ar um progresso de conquista.</p>
		</div>
		<?php if( isset($_GET['backurl']) && trim($_GET['backurl']) ) { ?>
		<p class="back-url"><a href="<?php echo urldecode($_GET['backurl']) ?>" class="pull-left"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Voltar</a></p>
		<?php } ?>
		<div class="alert-icon-help-5"></div>
	</div>
	
	<div class="page-help" id="devel">
		<div class="help-content">
			<h3>Sobre o Sistema de Conquistas</h3>
			<p>Sistema de Conquistas 3.0
			<br><strong>2014 - <?php echo date("Y") ?> � Creative Services and Development</strong>
			<br>Desenvolvido por Romulo de Sousa Mangueira
			<br><strong>www.creativesd.com.br</strong></p>
			<p>Todos os Direitos Reservado</p>
		</div>
		<?php if( isset($_GET['backurl']) && trim($_GET['backurl']) ) { ?>
		<p class="back-url"><a href="<?php echo urldecode($_GET['backurl']) ?>" class="pull-left"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Voltar</a></p>
		<?php } ?>
		<div class="alert-icon-help-6"></div>
	</div>