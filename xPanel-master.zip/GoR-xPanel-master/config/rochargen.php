<?php

return [
    'useROChargen' => true,    
    // Cache
    'cache_time' => 15 * 60,

    //Cliente
    'ini_file' => 'DATA.INI',
];