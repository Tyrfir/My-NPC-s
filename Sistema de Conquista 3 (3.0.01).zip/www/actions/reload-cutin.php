<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  .---------------------------------------------------------------.
  .            Pega uma lista de Recompensas atualizada           .
  *---------------------------------------------------------------*/
// Requirindo Bibliotecas
require_once('../config/Config.php');
require_once('../lib/Sql.class.php');
require_once('../lib/Achievement.class.php');
require_once('../lib/Numbers.class.php');
require_once('../lib/Template.class.php');

	$Ach = new Achievements;
	$Tpl = new Template;
	
	if( !isset($_POST['achievement_id']) || !is_numeric($_POST['achievement_id']) || empty($_POST['achievement_id']) )
		$result = "error";
	else if( ($count = $Ach->LoadFromID($_POST['achievement_id'])) <= 0 )
		$result = "error";
	else {
		$rewards = "";
		
		if( $Ach->rewards[$_POST['achievement_id']]['count'] ) {
			$rewards = "<p>Recompensas:</p>".$Tpl->CreateRewardList($Ach->rewards[$_POST['achievement_id']]);
		}
		
		if( file_exists("../images/icons/{$Ach->achievements['icon'][0]}.png") )
		{
			$icon = "images/icons/".$Ach->achievements['icon'][0].".png";
			$Css = $Ach->achievements['icon'][0];
		}
		else if( file_exists("../images/icons/{$Ach->achievements['icon'][0]}.gif") )
		{
			$icon = "images/icons/".$Ach->achievements['icon'][0].".gif";
			$Css = $Ach->achievements['icon'][0];
		}
		else {
			$icon = "images/null.png";
			$Css = "no-cutin";
		}
			
		$result = '
			<div style="margin-left:5px; margin-bottom:10px;"><strong>Cutin:</strong> ' . $Ach->achievements['cutin'][0] . '.bmp</div>
			<div class="table-conquest">
				<div class="base-top">'. $Ach->achievements['name'][0] . '</div>
				<div class="base-image"><img src="' . $icon . '" class="img-' . $Css . '" /></div>
				<div class="base-desc">' . $Ach->achievements['desc'][0] . '</div>
				<div class="base-bottom">' . $rewards . '</div>
				<div class="clear"></div>
			</div>
		';
	}
	echo $result;
?>