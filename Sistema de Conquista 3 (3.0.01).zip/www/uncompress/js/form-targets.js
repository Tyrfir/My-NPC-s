/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  .---------------------------------------------------------------.
  .             Formul�rios de Gerenciamento de Alvos             .
  *---------------------------------------------------------------*/
$(document).ready(function(){
	$chk_submit_send = false;
	
	jQuery.fn.TargetChanged = function() {
		var element = $("option:selected", this);
		var options = element.attr("enabledOpts");
		
		if( !options || options.length <= 0 )
		{
			$(this).TargetOptions('all', false);
			$("#add-targets button").prop('disabled', true);
			return;
		}
		
		var value = options.split(",");
		
		$(this).TargetOptions('hour', (value.indexOf("hour")>=0?true:false));
		$(this).TargetOptions('timer', (value.indexOf("timer")>=0?true:false));
		$(this).TargetOptions('amount', (value.indexOf("amount")>=0?true:false));
		$(this).TargetOptions('target', (value.indexOf("target")>=0?true:false));
		
		if( value.indexOf("hour") < 0 && value.indexOf("timer") < 0 && value.indexOf("target") < 0 )
			$("#add-targets #primary-group").removeClass("col-xs-6");
		else
			$("#add-targets #primary-group").addClass("col-xs-6");
	
		$("#add-targets button").prop('disabled', false);
	}
	
	jQuery.fn.TargetOptions = function(target, flag) {
		flag = flag?false:true;
		
		// Enable Target
		if( target == 'all' || target == 'target' )
		{
			if( $("#add-targets #add_target").is(":visible") == flag )
				$("#add-targets #add_target").slideToggle("fast");
			
			$("#add-targets #add_target #target").prop('disabled', flag);
		}
		
		// Enable Target Opt&Amount
		if( target == 'all' || target == 'amount')
		{
			if( $("#add-targets #add_amount").is(":visible") == flag )
				$("#add-targets #add_amount").slideToggle("fast");
			
			$("#add-targets #add_amount #amount").prop('disabled', flag);
		}
		
		// Enable Target Hours
		if( target == 'all' || target == 'hour' )
		{
			if( $("#add-targets #add_hour").is(":visible") == flag )
				$("#add-targets #add_hour").slideToggle("fast");
			
			$("#add-targets #add_hour #hour").prop('disabled', flag);
			$("#add-targets #add_hour #minute").prop('disabled', flag);
		}
		
		// Enable Target Timers in Minutes
		if( target == 'all' || target == 'timer' )
		{
			if( $("#add-targets #add_timer").is(":visible") == flag )
				$("#add-targets #add_timer").slideToggle("fast");
			
			$("#add-targets #add_timer #timer").prop('disabled', flag);
		}
		return;
	}
	
	$("#add-targets #target_type").change(function() {
		$(this).TargetChanged();
	});
	
	$("#add-targets #add_target #target").keydown(function(e) {
		$targettype = $("#add-targets #target_type").val();
		$(this).AutoSuggest(e,'type='+$targettype);
	});
	
	$("#add-targets button[type='reset']").click(function(e) {
		e.preventDefault();
		
		$("#add-targets #add_target #target").val('');
		$("#add-targets #add_amount #amount").val('');
		$("#add-targets #add_hour #hour").val('');
		$("#add-targets #add_hour #minute").val('');
		$("#add-targets #add_timer #timer").val('');
		
	});
	
	$("#add-targets").submit(function(e) {
		e.preventDefault();
		
		if( $chk_submit_send )
			return;
		
		$send = $(this).serialize();
		$chk_submit_send = true;
		
		waitingDialog.show('Aguarde!', {dialogSize: 'sm'});
		
		$achievement_id = $("#add-targets #achievement_id").val();
		$type = $("#add-targets #target_type").val();
		
		if( $("#add-targets .alert-danger").is(":visible") == true )
			$("#add-targets .alert-danger").slideToggle("medium");
		if( $("#add-targets .alert-success").is(":visible") == true )
			$("#add-targets .alert-success").slideToggle("medium");
		
		$.ajax({
			url: 'actions/add-target.php',
			type: 'POST',
			async: true,
			cache: false,
			data: $send,
			dataType: 'json',
			success: function(result) {
				waitingDialog.hide();
				$chk_submit_send = false;
				if( result[0] == "update" )
				{
					$("#target-list .table tbody").find("tr[data-target='" + result[1] + "']").each(function() {
						$update = $(this).find("td:nth-child(1)");
						if( result[4] != $update.html() )
							$update.html(result[4]);
						
						$update = $(this).find("td:nth-child(4)");
						if( result[5] != $update.html() )
							$update.html(result[5]);
					});
					
					$("#add-targets .alert-success div").html(result[6]);
					$("#add-targets .alert-success").slideToggle("medium");
				}
				else if( result[0] == "insert" )
				{
					if( $count_targets <= 0 )
						$("#target-list .table tbody").find('.no-result').remove();
					
					$("#target-list .table tbody").append("<tr data-target='" + result[1] + "'><td>" + result[4] + "</td><td>" + result[3] + "</td><td>" + result[5] + "</td><td>" + result[6] + "</td><td>Ativado</td><td><button class='btn btn-danger btn-xs' data-action='remove' data-target='" + result[1] + "' data-toggle='tooltip' data-placement='top' title='Remover'><span class='glyphicon glyphicon-remove' aria-hidden='true'></span></button> <button class='btn btn-primary btn-xs' data-action='disable' data-target='" + result[1] + "' data-toggle='tooltip' data-placement='top' title='Ativar ou Desativar'><span class='glyphicon glyphicon-refresh' aria-hidden='true'></span></button></td></tr>");
					$('[data-toggle="tooltip"]').tooltip({html:true});
					$("#add-targets .alert-success div").html(result[7]);
					$("#add-targets .alert-success").slideToggle("medium");
					$count_targets++;
					
					// Reload Binds
					$("#target-list button[data-action='remove']").bind("click",function(e) {
						$(this).RemoveTarget(e);
					});
					
					$("#target-list button[data-action='enable'], #target-list button[data-action='disable']").bind("click",function(e) {
						$(this).ChangeTargetStatus(e);
					});
				}
				else {
					if( $("#add-targets #"+result[0]).length )
						$("#add-targets #"+result[0]).focus();
					
					$("#add-targets .alert-danger div").html(result[1]);
					$("#add-targets .alert-danger").slideToggle("medium");
					$('html, body').animate({scrollTop: $('#add-targets .alert-danger').offset().top-80}, 'medium');
				}
				
				return false;
			},
			error: function(request, status, error) {
				waitingDialog.hide();
				$chk_submit_send = false;
				console.log(arguments);
				$("#add-targets .alert-danger div").html("Houve um erro inesperado!");
				$("#add-targets .alert-danger").slideToggle("medium");
				$('html, body').animate({scrollTop: $('#add-targets .alert-danger').offset().top-80}, 'medium');
			}
		});
	});
	
	$("#target-list button[data-action='remove']").bind("click", function(e) {
		$(this).RemoveTarget(e);
	});
	
	$("#target-list button[data-action='enable'], #target-list button[data-action='disable']").bind("click", function(e) {
		$(this).ChangeTargetStatus(e);
	});

	jQuery.fn.RemoveTarget = function(e) {
		e.preventDefault();
		
		if( $chk_submit_send )
			return;
		
		$chk_submit_send = true;
		waitingDialog.show('Aguarde!', {dialogSize: 'sm'});
		
		$target = $(this).attr("data-target");
		
		if( $("#add-targets .alert-danger").is(":visible") == true )
			$("#add-targets .alert-danger").slideToggle("medium");
		if( $("#add-targets .alert-success").is(":visible") == true )
			$("#add-targets .alert-success").slideToggle("medium");
		
		$.ajax({
			url: 'actions/remove-target.php',
			type: 'POST',
			async: true,
			cache: false,
			data: 'id='+$target,
			dataType: "json",
			success: function(result) {
				waitingDialog.hide();
				$chk_submit_send = false;
					
				if( result[0] == "success" )
				{
					$("#target-list .table tbody").find("tr[data-target='" + result[1] + "']").each(function() {
						$(this).remove();
						$count_targets--;
						
						// Reset Panel Filter
						$('.filterable .btn-filter').ClearFilter();
						
						if( $count_targets <= 0 )
							$("#target-list .table tbody").append("<tr class='no-result text-center'><td colspan='5'>Nenhum alvo cadastrado!</div></tr>");
					});
				}
				else {
					$("#add-targets .alert-danger div").html(result[1]);
					
					if( $("#add-targets .alert-danger").is(":visible") == false )
						$("#add-targets .alert-danger").slideToggle("medium");	

					$('html, body').animate({scrollTop: $('#add-targets .alert-danger').offset().top-80}, 'medium');
				}
				return false;
			},
			error: function(request, status, error) {
				waitingDialog.hide();
				$chk_submit_send = false;
				console.log(arguments);
				$("#add-targets .alert-danger div").html("Houve um erro inesperado!");
				$("#add-targets .alert-danger").slideToggle("medium");
				$('html, body').animate({scrollTop: $('#add-targets .alert-danger').offset().top-80}, 'medium');
			}
		});
	}
	
	jQuery.fn.ChangeTargetStatus = function(e) {
		e.preventDefault();
		
		if( $chk_submit_send )
			return;
		
		$chk_submit_send = true;
		waitingDialog.show('Aguarde!', {dialogSize: 'sm'});
		
		$target = $(this).attr("data-target");
		$status = $(this).attr("data-action") == 'enable' ? 1 : 0;
		
		if( $("#add-targets .alert-danger").is(":visible") == true )
			$("#add-targets .alert-danger").slideToggle("medium");
		if( $("#add-targets .alert-success").is(":visible") == true )
			$("#add-targets .alert-success").slideToggle("medium");
		
		$.ajax({
			url: 'actions/change-target-status.php',
			type: 'POST',
			async: true,
			cache: false,
			data: 'id='+$target+'&status='+$status,
			dataType: 'json',
			success: function(result) {
				waitingDialog.hide();
				$chk_submit_send = false;
				if( result[0] == "success" )
				{
					$("#target-list .table tbody").find("tr[data-target='" + result[1] + "']").each(function() {
						$update = $(this).find("td:nth-child(5)");
						$update.html(result[2]==1?"Ativado":"Desativado");
						
						$update = $(this).find("td:nth-child(6) button[data-action='"+(result[2]==1?"enable":"disable")+"']");
						$update.attr("data-action", (result[2]==1?"disable":"enable"));
					});
					
					// Reload Binds
					$("#target-list button[data-action='remove']").bind("click",function(e) {
						$(this).RemoveTarget(e);
					});
					
					$("#target-list button[data-action='enable'], #target-list[data-action='disable']").bind("click",function(e) {
						$(this).ChangeTargetStatus(e);
					});
				}
				else {
					$("#add-targets .alert-danger div").html(result[1]);
					
					if( $("#add-targets .alert-danger").is(":visible") == false )
						$("#add-targets .alert-danger").slideToggle("medium");

					$('html, body').animate({scrollTop: $('#add-targets .alert-danger').offset().top-80}, 'medium');
				}
				return false;
			},
			error: function(request, status, error) {
				waitingDialog.hide();
				$chk_submit_send = false;
				console.log(arguments);
				$("#add-targets .alert-danger div").html("Houve um erro inesperado!");
				$("#add-targets .alert-danger").slideToggle("medium");
				$('html, body').animate({scrollTop: $('#add-targets .alert-danger').offset().top-80}, 'medium');
			}
		});
	}
});