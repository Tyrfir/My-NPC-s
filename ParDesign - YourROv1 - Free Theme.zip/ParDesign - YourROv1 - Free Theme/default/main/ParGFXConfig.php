<?php
return array(
	// Server Name
		'serverName'	=> 'Your RO',
		
	// Rate my server link
		'rms' 		=> 'http://www.ratemyserver.net',
		
	// Forums link here
		'forum' 	=> 'http://www.forum.com',
		
	// Facebook page link here.
		'fb' => 'http://www.facebook.com/YourRO',
		
	// Twitter link here.
		'twit' => 'http://www.twitter.com/YourRO',
		
	// Youtube link here.
		'yt' => 'http://www.youtube.com/YourRO',
		
	// Download
	
		'download' => 'http://www.mediafire.com',
		
	// Rules
	
		'rules' => 'http://www.your-ro.com/forum-rules/',
		
	// Screenshots images
		'sliders' => array(
			// Image name.extension, description ( Don't forget , ( comma ) )
			'slider.png,',
			'image1.jpg,',
			'image2.jpg,',
			'image3.jpg,',
		),

	// You tube video link
		'youtube-video'	=> '<iframe width="347" height="202" src="//www.youtube.com/embed/-c8VZx63MmM" frameborder="0" allowfullscreen></iframe>',

	// Server Time ( use http://www.timeanddate.com/ )
		'serverTime'	=>	'<iframe src="http://free.timeanddate.com/clock/i3s2kzjx/n145/fs12/fcff2229/tct/pct" frameborder="0" width="70" height="17" allowTransparency="true"></iframe>',
	
	// RSS settings
		'enablerss'		=> false,						// true/ false	true will show RSS links on index page
		'news' 			=> 'http://www.xul.fr/rss.xml',		// RSS News link

)
?>