// © Creative Services and Development
// Site Oficial: www.creativesd.com.br
// Termos de Contrato e Autoria em: http://creativesd.com.br/?p=termos

#define HERCULES_CORE

#include "common/cbasetypes.h"
#include "common/sql.h"
#include "common/mmo.h"
#include "common/showmsg.h"

#include "char/char_restock.h"
#include "char/inter.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// Restock System
bool char_restock_load(uint32 char_id, struct item *item)
{
	struct SqlStmt *stmt;
	struct item tmp_item;
	int i = 0;

	stmt = SQL->StmtMalloc(inter->sql_handle);
	if( stmt == NULL )
	{
		SqlStmt_ShowDebug(stmt);
		return 0;
	}

	memset(&tmp_item, 0, sizeof(tmp_item));
	if (SQL_ERROR == SQL->StmtPrepare(stmt, "SELECT `nameid`, `amount` FROM `restock` WHERE `char_id`='%d' LIMIT %d", char_id, MAX_RESTOCK)
		|| SQL_ERROR == SQL->StmtExecute(stmt)
		|| SQL_ERROR == SQL->StmtBindColumn(stmt, 0, SQLDT_INT,   &tmp_item.nameid, sizeof tmp_item.nameid, NULL, NULL)
		|| SQL_ERROR == SQL->StmtBindColumn(stmt, 1, SQLDT_SHORT, &tmp_item.amount, sizeof tmp_item.amount, NULL, NULL)
		) {
		SqlStmt_ShowDebug(stmt);
		return 0;
	}

	while (SQL_SUCCESS == SQL->StmtNextRow(stmt)) {
		memcpy(&item[i], &tmp_item, sizeof(tmp_item));
		i++;
	}
	return 1;
}

bool char_restock_save(uint32 char_id, struct mmo_charstatus* status)
{
	int i, errors = 0;

	if( SQL_ERROR == SQL->Query(inter->sql_handle, "DELETE FROM `restock` WHERE `char_id`='%d'", char_id) )
	{
		Sql_ShowDebug(inter->sql_handle);
		return 0;
	}

	for( i = 0; i < MAX_RESTOCK; i++ )
	{
		if( status->restock[i].nameid > 0 && status->restock[i].amount > 0 ) {
			if( SQL_ERROR == SQL->Query(inter->sql_handle, "INSERT INTO `restock` (`char_id`, `nameid`, `amount`) VALUES (%d, %d, %d)", char_id, status->restock[i].nameid, status->restock[i].amount) ) {
				Sql_ShowDebug(inter->sql_handle);
				errors++;
			}
		}
	}
	return errors ? false : true;
}
