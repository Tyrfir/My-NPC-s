<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  .---------------------------------------------------------------.
  .            A��o de alterar situa��o da Recompensas            .
  *---------------------------------------------------------------*/
// Required Files
require_once('../config/Config.php');
require_once('../lib/Sql.class.php');
require_once('../lib/Achievement.class.php');
require_once('../lib/Account.class.php');

	$Ach = new Achievements();
	$Auth = new Account();
	
	if( !$Auth->CheckAccess('CHG_REWARD') )
		$result = array("error", utf8_encode("Voc� n�o tem autoriza��o para alterar situa��o de recompensas."));
	else if( !isset($_POST['id']) || !is_numeric($_POST['id']) )
		$result = array("error", utf8_encode("Identifica��o n�o sinalizada."));
	else if( !isset($_POST['status']) || !is_numeric($_POST['status']) || $_POST['status'] < 0 || $_POST['status'] > 1 )
		$result = array("error", utf8_encode("Tipo da situa��o n�o � valida."));
	else if( $Ach->ChangeRewardStatus($_POST['id'], $_POST['status']) == false )
		$result = array("error", utf8_encode("Erro ao alterar a situa��o da recompensa."));
	else
		$result = array("success", $_POST['id'], $_POST['status']);
	
	// Return Results
	echo json_encode($result);
	exit;
?>