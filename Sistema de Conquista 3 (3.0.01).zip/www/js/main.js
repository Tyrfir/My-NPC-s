/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 © Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Versão: 3.0  .
  .---------------------------------------------------------------.
  .                           Principal                           .
  *---------------------------------------------------------------*/
$(document).ready(function(){$('[data-toggle="tooltip"]').tooltip({html:!0}),$(".go-top").click(function(e){e.preventDefault(),$("html, body").animate({scrollTop:$("body").offset().top},"medium")}),$(window).scroll(function(){$(this).scrollTop()>10&&0==$(".go-top").is(":visible")?$(".go-top").fadeIn("slow"):$(this).scrollTop()<=10&&1==$(".go-top").is(":visible")&&$(".go-top").fadeOut("slow")}),$("#change-theme").change(function(){$(this).submit()}),$(".side-bar .menu-head").click(function(e){e.preventDefault(),$(window).width()<=800&&$(".side-bar .menu").slideToggle("slow")}),$(".alert-danger .close").bind("click",function(e){$(this).parent().slideToggle("medium")}),$(".alert-success .close").bind("click",function(e){$(this).parent().slideToggle("medium")}),$profile_sm=!1,$(".page-profile .show-more").bind("click",function(e){e.preventDefault(),$(".page-profile .last-achievements .hidden-icon").slideToggle("fast"),$profile_sm=$profile_sm?!1:!0,1==$profile_sm?$(this).html('<span class="glyphicon glyphicon-eye-close"></span> Ocultar'):$(this).html('<span class="glyphicon glyphicon-plus"></span> Mostrar todas')});var e=screen.width;screen.height;600>e&&$("body").html("Este site foi feito para operar em resoluções acim de 600px de largura!")});