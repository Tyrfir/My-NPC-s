/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor Original: Desconhecido                     Vers�o: 3.0  .
  . Edi��es e Adapta��es: Romulo SM (sbk_)                        .
  .---------------------------------------------------------------.
  .           Formul�rios de Gerenciamento de Alvos               .
  *---------------------------------------------------------------*/
$(document).ready(function(){$(".filterable .btn-filter").click(function(){var e=$(this).parents(".filterable"),t=e.find(".filters input"),i=e.find(".table tbody");1==t.prop("disabled")?(t.prop("disabled",!1),t.first().focus()):(t.val("").prop("disabled",!0),i.find(".no-result").remove(),i.find("tr").show())}),$(".filterable .filters input").keyup(function(e){var t=e.keyCode||e.which;if("9"!=t){var i=$(this),n=i.val().toLowerCase(),r=i.parents(".filterable"),d=r.find(".filters th").index(i.parents("th")),l=r.find(".table"),f=l.find("tbody tr"),o=f.filter(function(){var e=$(this).find("td").eq(d).text().toLowerCase();return-1===e.indexOf(n)});l.find("tbody .no-result").remove(),f.show(),o.hide(),o.length===f.length&&l.find("tbody").prepend($('<tr class="no-result text-center"><td colspan="'+l.find(".filters th").length+'">Nenhum resultado encontrado</td></tr>'))}}),jQuery.fn.ClearFilter=function(){var e=$(this).parents(".filterable"),t=e.find(".filters input"),i=e.find(".table tbody");0==t.prop("disabled")&&(t.val("").prop("disabled",!0),i.find(".no-result").remove(),i.find("tr").show())}});