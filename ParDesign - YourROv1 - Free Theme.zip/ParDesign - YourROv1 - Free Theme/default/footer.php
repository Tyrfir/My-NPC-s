<?php if (!defined('FLUX_ROOT')) exit; ?>
						</div> <!-- containerRight -->
					</div> <!-- container -->
					<div id="containerBottom"></div>
					<div class="clear"></div>
				</div>
				<div id="footer">
					<div class="footerNav">
						<ul>
							<li><a href="<?php echo $this->url('main'); ?>">Home</a></li>
							<li><a href="<?php echo $ParGFX['forum']; ?>">Forum</a></li>
							<li><a href="<?php echo $ParGFX['download']; ?>">Download</a></li>
							<li><a href="<?php echo $this->url('account','create'); ?>">Register</a></li>
							<li><a href="<?php echo $this->url('donate'); ?>">Donate</a></li>
							<li><a href="<?php echo $this->url('voteforpoints'); ?>">Vote</a></li>
							<li><a href="<?php echo $ParGFX['rms']; ?>">Review</a></li>
						</ul>
						
					</div>
					<div class="credits">
							<a href="https://www.facebook.com/Parparazzi.Official" target="_blank"><img src="<?php echo $this->themePath('img/Par.png'); ?>" alt="ParGFX" title="Design and Coded by ParGFX"></a>
						</div>
					<div class="copyrights">
						<p style="margin-left:130px;margin-top:60px;float:left;">
						Copyright (C) 2014 <b>Your Ragnarok Online</b><br/>
						All other trademarks and images belongs to their respective owners.<br>
						Ragnarok Online and all related content are property of Gravity Corp.
						</p>
					</div>
				</div>
			</div> <!-- main -->
		</div> <!-- wrapper -->
	</body>
</html>
