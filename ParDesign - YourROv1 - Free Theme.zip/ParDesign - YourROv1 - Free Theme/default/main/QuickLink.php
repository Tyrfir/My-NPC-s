<?php if (!defined('FLUX_ROOT')) exit; ?>
<div id="ButtonsQL">

<div class="DL">
<a href="<?php echo $ParGFX['download']; ?>" target="_blank"><img src="<?php echo $this->themePath('img/Download.png'); ?>" alt="" title="Download Now"></a>
</div>

<div class="VPS">
<a href="<?php echo $this->url('voteforpoints'); ?>"><img src="<?php echo $this->themePath('img/VPS.png'); ?>" alt="" title="Vote For Points"></a>
</div>

<div class="RMS">
<a href="<?php echo $ParGFX['rms']; ?>" target="_blank"><img src="<?php echo $this->themePath('img/RMS.png'); ?>" alt="" title="Write Us A Review"></a>
</div>

</div>

