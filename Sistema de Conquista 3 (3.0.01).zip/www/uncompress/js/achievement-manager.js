/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  .---------------------------------------------------------------.
  .           Formul�rios de Gerenciamento de Conquistas          .
  *---------------------------------------------------------------*/
$("#new-achievement button[type='reset']").click(function() {
	defaultIcon = $("#new-achievement .table-conquest .base-image").attr("default-icon");
	defaultCss = $("#new-achievement .table-conquest .base-image").attr("default-css");
	
	$("#new-achievement .table-conquest .base-image img").attr("src", defaultIcon);
	$("#new-achievement .table-conquest .base-image img").removeClass();
	$("#new-achievement .table-conquest .base-image img").addClass('img-'+defaultCss);
	$("#new-achievement .table-conquest .base-top").html("Sem nome");
	$("#new-achievement .table-conquest .base-desc").html("Sem Descri��o")
});

$("#new-achievement #icon").change(function() {
	text = $("option:selected", this).text();
	$("#new-achievement .table-conquest .base-image img").attr("src", text);
	$("#new-achievement .table-conquest .base-image img").removeClass();
	$("#new-achievement .table-conquest .base-image img").addClass('img-'+$(this).val());
});

$("#new-achievement #name").keydown(function() {
	setTimeout(function() { 
		new_name = $("#new-achievement #name").val();
		if( new_name.length <= 0 )
			$("#new-achievement .table-conquest .base-top").html("Sem nome");
		else
			$("#new-achievement .table-conquest .base-top").html(new_name);
	},300);
});

$("#new-achievement #desc").keydown(function() {
	setTimeout(function() { 
		new_desc = $("#new-achievement #desc").val();
		if( new_desc.length <= 0 )
			$("#new-achievement .table-conquest .base-desc").html("Sem Descri��o");
		else
			$("#new-achievement .table-conquest .base-desc").html(new_desc.replace(/\n/g, "<br />"));
	},300);
});

$("#new-achievement .alert-danger .close").bind("click", function() {
	$("#new-achievement .alert-danger").slideToggle("medium");
});

$("#edit-achievement button[type='reset']").click(function() {
	defaultIcon = $("#cutin-generator .table-conquest .base-image").attr("default-icon");
	defaultCss = $("#cutin-generator .table-conquest .base-image").attr("default-css");
	defaultName = $("#cutin-generator .table-conquest .base-top").attr("default-name");
	defaultDesc = $("#cutin-generator .table-conquest .base-desc").attr("default-desc");
	
	$("#cutin-generator .table-conquest .base-image img").attr("src", defaultIcon);
	$("#cutin-generator .table-conquest .base-image img").removeClass();
	$("#cutin-generator .table-conquest .base-image img").addClass('img-'+defaultCss);
	$("#cutin-generator .table-conquest .base-top").html(defaultName);
	$("#cutin-generator .table-conquest .base-desc").html(defaultDesc);
});

$("#edit-achievement #icon").change(function() {
	text = $("option:selected", this).text();
	$("#cutin-generator .table-conquest .base-image img").attr("src", text);
	$("#cutin-generator .table-conquest .base-image img").removeClass();
	$("#cutin-generator .table-conquest .base-image img").addClass('img-'+$(this).val());
});

$("#edit-achievement #name").keydown(function() {
	setTimeout(function() { 
		newName = $("#edit-achievement #name").val();
		defaultName = $("#cutin-generator .table-conquest .base-top").attr("default-name");
		if( newName.length <= 0 )
			$("#cutin-generator .table-conquest .base-top").html(defaultName);
		else
			$("#cutin-generator .table-conquest .base-top").html(newName);
	},300);
});

$("#edit-achievement #desc").keydown(function() {
	setTimeout(function() { 
		newDesc = $("#edit-achievement #desc").val();
		defaultDesc = $("#cutin-generator .table-conquest .base-desc").attr("default-desc");
		if( newDesc.length <= 0 )
			$("#cutin-generator .table-conquest .base-desc").html(defaultDesc);
		else
			$("#cutin-generator .table-conquest .base-desc").html(newDesc.replace(/\n/g, "<br />"));
	
		$(this).CutinResize();
	},300);
});

$chk_submit_send = false;
$("#new-achievement").submit(function(e) {
	e.preventDefault();
	
	if( $chk_submit_send )
		return;
	
	$send = $(this).serialize();
	$chk_submit_send = true;
	
	waitingDialog.show('Aguarde!', {dialogSize: 'sm'});
	
	if( $("#new-achievement .alert-danger").is(":visible") == true )
		$("#new-achievement .alert-danger").slideToggle("medium");
	
	$.ajax({
		url: 'actions/new.php',
		type: 'POST',
		async: true,
		cache: false,
		data: $send,
		dataType: 'json',
		success: function(result) {
			if( result[0] != 'success' )
			{
				$("#"+result[0]).focus();
				$("#new-achievement .alert-danger div").html(result[1]);
				$("#new-achievement .alert-danger").slideToggle("medium");
				$("html, body").animate({scrollTop: $("#new-achievement .alert-danger").offset().top-80}, 'medium');
				waitingDialog.hide();
				$chk_submit_send = false;
			}
			else {
				window.location = result[1];
			}
			return false;
		},
		error: function(request, status, error) {
			waitingDialog.hide();
			$chk_submit_send = false;
			console.log(arguments);
			$("#new-achievement .alert-danger div").html("Houve um erro inesperado!");
			$("#new-achievement .alert-danger").slideToggle("medium");
		}
	});
});

$("#edit-achievement").submit(function(e) {
	e.preventDefault();
	
	if( $chk_submit_send )
		return;
	
	$send = $(this).serialize();
	$chk_submit_send = true;
	
	waitingDialog.show('Aguarde!', {dialogSize: 'sm'});
	
	if( $("#edit-achievement .alert-success").is(":visible") == true )
		$("#edit-achievement .alert-success").slideToggle("medium");
				
	if( $("#edit-achievement .alert-danger").is(":visible") == true )
		$("#edit-achievement .alert-danger").slideToggle("medium");
	
	$.ajax({
		url: 'actions/edit.php',
		type: 'POST',
		async: true,
		cache: false,
		data: $send,
		dataType: 'json',
		success: function(result) {
			if( result[0] != 'success' )
			{
				$("#"+result[0]).focus();
				$("#edit-achievement .alert-danger div").html(result[1]);
				$("#edit-achievement .alert-danger").slideToggle("medium");
				$("html, body").animate({scrollTop: $("#edit-achievement .alert-danger").offset().top-80}, "medium");
				waitingDialog.hide();
				$chk_submit_send = false;
			}
			else {
				$("#edit-achievement .alert-success div").html(result[1]);
				$("#edit-achievement .alert-success").slideToggle("medium");
			
				waitingDialog.hide();
				$chk_submit_send = false;
			}
			return false;
		},
		error: function(request, status, error) {
			waitingDialog.hide();
			$chk_submit_send = false;
			console.log(arguments);
			$("#edit-achievement .alert-danger div").html("Houve um erro inesperado!");
			$("#edit-achievement .alert-danger").slideToggle("medium");
		}
	});
});

$target_remove = null;
$remove_name = null;
$("a[action='remove-achievement']").click(function(e) {
	e.preventDefault();
	$target_remove = $(this).attr("data-target");
	$remove_name = $(this).attr("data-name");
	$('#remove-achievement .btn-success').bind("click", function() {
		$(this).RemoveAchAction()
	});
	$('#remove-achievement #remove-name').html($remove_name);
	$('#remove-achievement').modal('show');
});

$('#remove-achievement .btn-danger').click(function() {
	$target_remove = null;
	$remove_name = null;
	$('#remove-achievement .btn-success').unbind("click");
});

jQuery.fn.RemoveAchAction = function() {
	
	//$('#remove-result').modal('show');
	//$('#remove-result .modal-header').addClass('modal-header-success');
	//return;
		
	if( $chk_submit_send )
		return;
		
	$chk_submit_send = true;
	$('#remove-achievement').modal('hide');
	waitingDialog.show('Aguarde!', {dialogSize: 'sm'});
		
	$target = $(this).attr("data-target");
		
	$.ajax({
		url: 'actions/remove-achievement.php',
		type: 'POST',
		async: true,
		cache: false,
		data: 'id='+$target_remove,
		dataType: "json",
		success: function(result) {
			waitingDialog.hide();
			$chk_submit_send = false;
			if( result[0] == "success" )
			{
				$('#remove-result .modal-header').addClass('modal-header-success');
				$('#remove-result .modal-title').html('Sucesso!');
				$('#remove-result .modal-body').html(result[1]);
				$('#remove-result .modal-footer').hide();
			}
			else {
				$('#remove-result .modal-header').addClass('modal-header-danger');
				$('#remove-result .modal-title').html("Houve um erro inesperado!");
				$('#remove-result .modal-body').html(result[1]);
			}
			$('#remove-result').modal('show');
			$target_remove = null;
			$remove_name = null;
			setTimeout(function() {
				location.reload();
			},5000);
			return false;
		},
		error: function(request, status, error) {
			waitingDialog.hide();
			$chk_submit_send = false;
			$target_remove = null;
			$remove_name = null;
			console.log(arguments);
			$('#remove-result .modal-header').addClass('modal-header-danger');
			$('#remove-result .modal-title').html("Houve um erro inesperado!");
			$('#remove-result .modal-body').html("<p>Houve um erro inesperado, reporte aos Desenvolvedores!</p>");
			$('#remove-result').modal('show');
		}
	});
}