<?php if (!defined('FLUX_ROOT')) exit; ?>
<div class="indexPage">
	<div class="Message">
	<h2 style="text-align:center;">WELCOME TO YOUR RAGNAROK ONLINE</h2>
	<p style="text-align:center;margin-left: 280px;">A newly released unique High Rate Server that will<br>
		truly take your breath away! Your RO has been made <br>
		to give you exhilarating moments be it on Farming, <br>
		Exciting PvPing and Instense WoE! We boast to you our very own Realm <br>
		Dimension filled with devious mobs that will surely give <br>
		you countless of things to do! And of course, a lot more! <br>
		Come and check our server and be part of the fun.
	</p>
	</div>
	<div class="videoArea">
		<?php echo $ParGFX['youtube-video']; ?>
	</div><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	<div id="NewsAndUpdates">
			<?php include 'newsandupdates.php'; ?>
	</div>

</div>