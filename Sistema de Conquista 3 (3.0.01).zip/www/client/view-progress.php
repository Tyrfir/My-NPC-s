<?php
	if( !defined("CLIENT_PAGE") )
		exit;
	
	$help_rand = rand(1,6);
	if( !isset($_GET['achievement_id']) || !is_numeric($_GET['achievement_id']) )
	{
?>
	<div class="page-error">
		<strong>Ooops!</strong>
		<p>Identifica��o n�o sinalizada, reformule sua busca...</p>
		<?php if( isset($_GET['backurl']) && trim($_GET['backurl']) ) { ?>
		<p class="back-url"><a href="<?php echo urldecode($_GET['backurl']) ?>" class="pull-left"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Voltar</a></p>
		<?php } ?>
		<div class="alert-icon-help-<?php echo $help_rand; ?>"></div>
	</div>
<?php } else if( !$Ach->LoadFromID($_GET['achievement_id'],null,null,null,$account_id) ) { ?>
	<div class="page-error">
		<strong>Ooops!</strong>
		<p>Conquista n�o encontrada, reformule sua busca...</p>
		<?php if( isset($_GET['backurl']) && trim($_GET['backurl']) ) { ?>
		<p class="back-url"><a href="<?php echo urldecode($_GET['backurl']) ?>" class="pull-left"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Voltar</a></p>
		<?php } ?>
		<div class="alert-icon-help-<?php echo $help_rand; ?>"></div>
	</div>
<?php } else if( $Ach->getInfo($_GET['achievement_id'],'ghost') &&  $Client->group_id > 1 ) { ?>
	<div class="page-error">
		<strong>Ooops!</strong>
		<p>Voc� n�o pode visualizar o progresso desta conquista...</p>
		<?php if( isset($_GET['backurl']) && trim($_GET['backurl']) ) { ?>
		<p class="back-url"><a href="<?php echo urldecode($_GET['backurl']) ?>" class="pull-left"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Voltar</a></p>
		<?php } ?>
		<div class="alert-icon-help-<?php echo $help_rand; ?>"></div>
	</div>
<?php } else { ?>

	<div class="content">
		<div class="header">
			<h4><i class="fa fa-spinner" aria-hidden="true"></i> Progresso de <?php echo $Ach->achievements['name'][0] ?></h4>
			<hr>
		</div>
		
		<?php
			if( $Ach->targets[$_GET['achievement_id']]['count'] ) {
				$targets = $Tpl->CreateTargetList($Ach->targets[$_GET['achievement_id']]);
				echo $targets;
			}
			else {
		?>
			<p>Nenhum progresso para esta conquista.</p>
		<?php } if( isset($_GET['backurl']) && trim($_GET['backurl']) ) { ?>
		<p class="back-url"><a href="<?php echo urldecode($_GET['backurl']) ?>" class="pull-left"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Voltar</a></p>
		<?php } ?>
	</div>
<?php } ?>