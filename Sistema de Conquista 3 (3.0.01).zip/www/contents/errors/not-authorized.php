<?php
	if( !defined("MAIN_PAGE") )
		exit;
	
	require_once('contents/includes/header.php');
?>
	<div class="container margin-20x-top">
		<div class="row">
			<div class="col-xs-12 col-sm-6 col-sm-push-3">
				<div class="alert alert-warning" role="alert">
					 <h4><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> Voc� n�o est� autorizado!</h4>
					 <p>Voc� n�o tem autoriza��o para acessar esta p�gina.<br/> Aguarde, voc� est� sendo redirecionado...</p>
					 <div class="alert-icon-help-5"></div>
				</div>
			</div>
		</div>
	</div>
	
	<script type="text/javascript">
		setTimeout(function() {
			window.location = "?p=perfil/visualizar";
		},5000);
	</script>
  </body>	
</html>