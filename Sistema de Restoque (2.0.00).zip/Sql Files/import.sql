CREATE TABLE IF NOT EXISTS `restock` (
  `char_id` INT(11) UNSIGNED NOT NULL DEFAULT '0',
  `nameid` INT(11) UNSIGNED NOT NULL DEFAULT '0',
  `amount` SMALLINT(11) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`char_id`,`nameid`),
  KEY `char_id` (`char_id`)
) ENGINE=MyISAM;