<?php
return [
    'vote4points' => [
        'active' => true,
        'rankings' => [
            [
                'id'      =>  0,
                'name'    =>  'RagnaTOP',
                'img_url' =>  'https://ragnatop.org/images/button.gif',
                'url'     =>  'https://ragnatop.org/index.php?a=in&u=rov',
                'points'  =>  1,
            ],
            [
                'id'      =>  1,
                'name'    =>  'TopRagnarok',
                'img_url' =>  'https://www.topragnarok.org/images/votebanner.gif',
                'url'     =>  'https://www.topragnarok.org/votar/id8744/',
                'points'  =>   1,
            ]
        ]
    ]
];
