<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2>E-mail Changes</h2>