/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  .---------------------------------------------------------------.
  .              Formul�rios de Edi��o de Conquistas             .
  *---------------------------------------------------------------*/
$chk_submit_send = false;
$(document).ready(function() {
	$("#edit-achievement button[type='reset']").click(function() {
		defaultIcon = $("#cutin-generator .table-conquest .base-image").attr("default-icon");
		defaultCss = $("#cutin-generator .table-conquest .base-image").attr("default-css");
		defaultName = $("#cutin-generator .table-conquest .base-top").attr("default-name");
		defaultDesc = $("#cutin-generator .table-conquest .base-desc").attr("default-desc");
		
		$("#cutin-generator .table-conquest .base-image img").attr("src", defaultIcon);
		$("#cutin-generator .table-conquest .base-image img").removeClass();
		$("#cutin-generator .table-conquest .base-image img").addClass('img-'+defaultCss);
		$("#cutin-generator .table-conquest .base-top").html(defaultName);
		$("#cutin-generator .table-conquest .base-desc").html(defaultDesc);
	});

	$("#edit-achievement #icon").change(function() {
		text = $("option:selected", this).text();
		$("#cutin-generator .table-conquest .base-image img").attr("src", text);
		$("#cutin-generator .table-conquest .base-image img").removeClass();
		$("#cutin-generator .table-conquest .base-image img").addClass('img-'+$(this).val());
	});

	$("#edit-achievement #name").keydown(function() {
		setTimeout(function() { 
			newName = $("#edit-achievement #name").val();
			defaultName = $("#cutin-generator .table-conquest .base-top").attr("default-name");
			if( newName.length <= 0 )
				$("#cutin-generator .table-conquest .base-top").html(defaultName);
			else
				$("#cutin-generator .table-conquest .base-top").html(newName);
		},300);
	});

	$("#edit-achievement #desc").keydown(function() {
		setTimeout(function() { 
			newDesc = $("#edit-achievement #desc").val();
			defaultDesc = $("#cutin-generator .table-conquest .base-desc").attr("default-desc");
			if( newDesc.length <= 0 )
				$("#cutin-generator .table-conquest .base-desc").html(defaultDesc);
			else
				$("#cutin-generator .table-conquest .base-desc").html(newDesc.replace(/\n/g, "<br />"));
		
			$(this).CutinResize();
		},300);
	});

	$("#edit-achievement").submit(function(e) {
		e.preventDefault();
		
		if( $chk_submit_send )
			return;
		
		$send = $(this).serialize();
		$chk_submit_send = true;
		
		waitingDialog.show('Aguarde!', {dialogSize: 'sm'});
		
		if( $("#edit-achievement .alert-success").is(":visible") == true )
			$("#edit-achievement .alert-success").slideToggle("medium");
					
		if( $("#edit-achievement .alert-danger").is(":visible") == true )
			$("#edit-achievement .alert-danger").slideToggle("medium");
		
		$.ajax({
			url: 'actions/edit.php',
			type: 'POST',
			async: true,
			cache: false,
			data: $send,
			dataType: 'json',
			success: function(result) {
				if( result[0] != 'success' )
				{
					$("#"+result[0]).focus();
					$("#edit-achievement .alert-danger div").html(result[1]);
					$("#edit-achievement .alert-danger").slideToggle("medium");
					$("html, body").animate({scrollTop: $("#edit-achievement .alert-danger").offset().top-80}, "medium");
					waitingDialog.hide();
					$chk_submit_send = false;
				}
				else {
					$("#edit-achievement .alert-success div").html(result[1]);
					$("#edit-achievement .alert-success").slideToggle("medium");
				
					waitingDialog.hide();
					$chk_submit_send = false;
				}
				return false;
			},
			error: function(request, status, error) {
				waitingDialog.hide();
				$chk_submit_send = false;
				console.log(arguments);
				$("#edit-achievement .alert-danger div").html("Houve um erro inesperado!");
				$("#edit-achievement .alert-danger").slideToggle("medium");
			}
		});
	});
	
	$subprev = "#main";
		
	$("#submenus a").click(function(e) {
		e.preventDefault();
		target = $(this).attr("href");
		
		if( target == $subprev )
			return;
			
		if( $($subprev).is(":visible") == true ) {
			$($subprev).fadeOut("medium", function() {
				$(target).fadeIn("medium");
			});
		}
		else {
			$(target).fadeIn("medium");
		}
		
		$subprev = target;
		
		if( target == "#cutin-generator" ) {
			setTimeout(function() {
				$(this).CutinResize()
			}, 500);
		}
		
	});
});