<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                       Sistema de Perfil                       .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 1.0  .
  *---------------------------------------------------------------*/
// Configura��es do Sistema de Perfil.
// !Configura��es de Caracteres est�o no Script de Configura��o CharRules.php!
//
//	[Nota 1]: Sim � 1 ou true, N�o � 0 ou false.
//
return array(
	'DUPLICATE_NAME'		=> false,							// Habilitar Nomes duplicados? [Nota 1]
	'DUPLICATE_NICKNAME'	=> false,							// Habilitar Nickname duplicados? [Nota 1]
	'MAX_AVATAR_WIDTH'		=> 180,								// Largura m�xima para avatares.
	'MAX_AVATAR_HEIGHT'		=> 240,								// Altura m�xima para avatares.
	'IMPORT_AVATAR'			=> true,							// Fazer Upload do Avatar importado pela URL?
	'UPLOAD_AVATAR'			=> true,							// Habilitar Upload do Avatar?
	'MAX_LAST'				=> 12,								// M�ximo de Conquistas recentes no perfil.
	
	// Permiss�es de Duplica��es [Nota 1]
	'DUPLICATE'				=> array(
		'NAME'      => false,		// Permitir que os Jogadores utilizem nomes j� cadastrado? 
		'NICKNAME'  => false,		// Permitir que os Jogadores utilizem nickname j� cadastro?
		'EMAIL'     => false,		// Permitir que os Jogadores utilizem e-mails j� cadastrado?
		'SKYPE'     => false,		// Permitir que os Jogadores utilizem Skype j� cadastrado?
		'FACEBOOK'  => false,		// Permitir que os Jogadores utilizem Facebook j� cadastrado?
		'TWITTER'   => false,		// Permitir que os Jogadores utilizem Twitter j� cadastrado?
		'GOOGLEP'	=> false,		// Permitir que os Jogadores utilizem Google+ j� cadastrado?
		'INSTAGRAM'	=> false,		// Permitir que os Jogadores utilizem Instagram j� cadastrado?
		'LINKEDIN'  => false,		// Permitir que os Jogadores utilizem Linkedin j� cadastrado?
		'YOUTUBE'   => false,		// Permitir que os Jogadores utilizem Youtube j� cadastrado?
	),
	
	// Configura��es de Locais
	'DEFAULT_AVATAR'		=> 'images/avatar-default.jpg',		// Local aonde encontra-se o avatar padr�o.
	'PATH_AVATAR'			=> 'images/avatar',					// Local aonde encontra-se os avatares dos usu�rios.
	
	// Extens�es aceita em avatares.
	// Voc� deve definir o n�mero correspondente da imagem que se encontra em:
	// http://php.net/manual/pt_BR/function.getimagesize.php
	'AVATAR_EXTENSIONS'		=> array(
		'gif' => 1,
		'jpg' => 2,
		'jpeg' => 2,
		'png' => 3
	),
);