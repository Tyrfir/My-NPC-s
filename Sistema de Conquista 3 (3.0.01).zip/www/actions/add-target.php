<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  .---------------------------------------------------------------.
  .                    A��o de Adi��o de Alvos                    .
  *---------------------------------------------------------------*/
// Required Files
require_once('../config/Config.php');
require_once('../lib/Sql.class.php');
require_once('../lib/Achievement.class.php');
require_once('../lib/Numbers.class.php');
require_once('../lib/Account.class.php');

$TargetTypes = require_once('../config/TargetTypes.php');
$TargetOptions = require_once('../config/TargetOptions.php');
$JobNames = require_once('../config/JobName.php');
$CharRules = require_once('../config/CharRules.php');

	$Ach = new Achievements();
	$Auth = new Account();
	
	$result = array();
	if( !$Auth->CheckAccess('ADD_TARGET') )
		$result = array("error", utf8_encode("Voc� n�o tem autoriza��o para adicionar um alvo."));
	else if( !isset($_POST['achievement_id']) || !is_numeric($_POST['achievement_id']) )
		$result = array("submit", utf8_encode("Identifica��o n�o sinalizada."));
	else if( !isset($_POST['target_type']) || !is_numeric($_POST['target_type']) )
		$result = array("target_type", utf8_encode("Voc� deve selecionar o tipo do alvo."));
	else if( !isset($TargetTypes[$_POST['target_type']]) )
		$result = array("target_type", utf8_encode("O tipo do alvo deve ser v�lido!"));
	else {
		$achievement_id = $_POST['achievement_id'];
		$target_type = $_POST['target_type'];
		$target = null;
		$amount = 1;
		$target_name = "Desconhecido";
		$target_desc = "Desconhecido";
		
		if( in_array("target",$TargetOptions[$target_type]) )
		{
			if( !isset($_POST['target']) || !trim($_POST['target']) )
			{
				// Return Results
				$result = array("target", utf8_encode("Voc� deve informar o alvo a ser adicionado."));
				echo json_encode($result);
				exit;
			}
			
			if( strlen($_POST['target']) < $CharRules['MIN_TARGET'] || strlen($_POST['target']) > $CharRules['MAX_TARGET'] )
			{
				// Return Results
				$result = array("target", utf8_encode(sprintf("Voc� deve entrar entre <strong>%d a %d caracteres</strong> no alvo.", $CharRules['MIN_TARGET'], $CharRules['MAX_TARGET'])));
				echo json_encode($result);
				exit;
			}
			
			$target = $_POST['target'];
		}
		
		if( in_array("amount",$TargetOptions[$target_type]) )
		{
			if( !isset($_POST['amount']) || !is_numeric($_POST['amount']) || $_POST['amount'] <= 0 )
			{
				// Return Results
				$result = array("amount", utf8_encode("Voc� deve informar a quantidade para adicionar este alvo."));
				echo json_encode($result);
				exit;
			}
			
			if( $_POST['amount'] < $CharRules['MIN_TARGET_VALUE'] || $_POST['amount'] > $CharRules['MAX_TARGET_VALUE'] )
			{
				// Return Results
				$result = array("amount", utf8_encode(sprintf("O valor de alvos deve ser entre <strong>%d a %d</strong>.", $CharRules['MIN_TARGET_VALUE'], $CharRules['MAX_TARGET_VALUE'])));
				echo json_encode($result);
				exit;
			}
			
			$amount = $_POST['amount'];
		}
		
		if( in_array("timer",$TargetOptions[$target_type]) )
		{
			if( !isset($_POST['timer']) || !is_numeric($_POST['timer']) || $_POST['timer'] <= 0 ) 
			{
				// Return Results
				$result = array("timer", utf8_encode("Voc� deve informar o tempo para adicionar este alvo."));
				echo json_encode($result);
				exit;
			}
			
			if( $_POST['amount'] < $CharRules['MIN_TARGET_VALUE'] || $_POST['amount'] > $CharRules['MAX_TARGET_VALUE'] )
			{
				// Return Results
				$result = array("timer", utf8_encode(sprintf("O valor de tempo deve ser entre <strong>%d a %d</strong>.", $CharRules['MIN_TARGET_VALUE'], $CharRules['MAX_TARGET_VALUE'])));
				echo json_encode($result);
				exit;
			}
			
			$amount = $_POST['timer'];
		}
		
		if( in_array("hour",$TargetOptions[$target_type]) )
		{
			if( !isset($_POST['hour']) || !is_numeric($_POST['hour']) || ($_POST['hour'] < 0 || $_POST['hour'] > 24) )
			{
				// Return Results
				$result = array("hour", utf8_encode("Voc� deve informar o hor�rio em formato de 00~23 horas."));
				echo json_encode($result);
				exit;
			}
			
			$hour = $_POST['hour'] >= 24 ? 0 : $_POST['hour'];
			
			if( !isset($_POST['minute']) || !is_numeric($_POST['minute']) || ($_POST['minute'] < 0 || $_POST['minute'] > 60) )
			{
				// Return Results
				$result = array("hour", utf8_encode("Voc� deve informar o hor�rio em formato de 00~59 minutos."));
				echo json_encode($result);
				exit;
			}
		
			$minute = $_POST['minute'] >= 60 ? 0 : $_POST['minute'];
			$target = sprintf("%02d:%02d", $hour, $minute);
			
			if( strlen($target) != 5 )
			{
				// Return Results
				$result = array("hour", utf8_encode("Hor�rio incorreto, entre com um hor�rio v�lido."));
				echo json_encode($result);
				exit;
			}
		}
		
		// Checando e Reconfigurando alvos de acordo com o tipo da conquista.
		//
		switch($target_type)
		{
			case 0:
			case 1:
			case 2:
			case 3:
				$target = "player";
				$target_name = "Jogador";
				break;
			case 4:
				$target = "emperium";
				$target_name = "Emperium";
				break;
			case 5:
			case 6:
			case 7:
			case 18:
			case 44:
			case 45:
			case 46:
			case 47:
				$target = "zeny";
				$target_name = "Zeny";
				break;
			case 8:
			case 50:
				$target = "runestone";
				$target_name = "Runa Guardi�";
				break;
			case 9:
			case 49:
				$target = "barricade";
				$target_name = "Barricada";
				break;
			case 10:
				$target = "timer";
				$target_name = Numbers::calc_timer($amount);
				break;
			case 11:
			case 15:
				if( ($target = $Ach->getmapgat($target)) == false )
				{
					// Return Results
					$result = array("target", utf8_encode("Mapa inexistente no banco de dados, por favor tente outro Mapa."));
					echo json_encode($result);
					exit;
				}
				$target_name = $Ach->getmapname($target) . " # " . $target;
				break;
			case 12:
			case 14:
				if( ($target = $Ach->getmobid($target)) == false )
				{
					// Return Results
					$result = array("target", utf8_encode("Monstro inexistente no banco de dados, por favor tente outro Monstro."));
					echo json_encode($result);
					exit;
				}
				$target_name = $Ach->getmobname($target) . " # " . $target;
				break;
			case 13:
			case 25:
			case 26:
			case 27:
			case 28:
			case 32:
			case 33:
			case 34:
			case 38:
			case 39:
			case 40:
			case 48:
				if( ($target = $Ach->getitemid($target)) == false )
				{
					// Return Results
					$result = array("target", "Item inexistente no banco de dados, por favor tente outro Item.");
					echo json_encode($result);
					exit;
				}
				$target_name = $Ach->getitemname($target) . " # " . $target;
				break;
			case 16:
				$target = "anymvp";
				$target_name = "MvP";
				break;
			case 17:
				$target_name = "Hor�rio # " . $target;
				break;
			case 19:
				$target = "BaseLevel";
				$target_name = "N�vel";
				break;
			case 20:
				$target = "JobLevel";
				$target_name = "N�vel";
				break;
			case 21:
				$target = "AnyLevel";
				$target_name = "N�vel";
				break;
			case 22:
			case 23:
			case 24:
				if( ($target = $Ach->getclassid($target)) == false )
				{
					// Return Results
					$result = array("target", utf8_encode("Classe inexistente, por favor tente outra Classe."));
					echo json_encode($result);
					exit;
				}
				$target_name = $JobNames[$target] . " # " . $target;
				break;
			case 29:
			case 30:
			case 31:
			case 35:
			case 36:
			case 37:
			case 41:
			case 42:
			case 43:
				$target = "anyitem";
				$target_name = "Qualquer Item";
				break;
			case 51:
				$target = "countdown";
				$target_name = "Contagem Regressiva";
				break;
			case 52:
				if( ($target = $Ach->getachievementid($target)) == false )
				{
					// Return Results
					$result = array("target", utf8_encode("Conquista inexistente no banco de dados, por favor tente outra Conquista."));
					echo json_encode($result);
					exit;
				}
				
				$name = $Ach->getInfo($target, 'name');
				$target_name = $name . " # " . $target;
				break;
			default:
				$target_name = $target;
				break;
		}
		
		$add_target = $Ach->AddTarget($achievement_id,$target_type,$target,$amount,1);
		switch($add_target[0])
		{
			case 0:
				// Erro ao Atualizar.
				$result = array("error", utf8_encode("Houve um erro ao atualizar o alvo, tente novamente."));
				break;
			case 1:
				// Erro ao inserir.
				$result = array("error", utf8_encode("Houve um erro ao inserir o alvo, tente novamente."));
				break;
			case 2:
				// Atualizado com sucesso.
				$result = array("update", $add_target[1], utf8_encode($target), $target_type, utf8_encode($target_name), $amount, utf8_encode("Alvo atualizado com sucesso!"));
				break;
			case 3:
				// Inserido com sucesso.
				$target_desc = $TargetTypes[$target_type];
				$result = array("insert", $add_target[1], utf8_encode($target), $target_type, utf8_encode($target_name), utf8_encode($target_desc), $amount, utf8_encode("Alvo inserido com sucesso!"));
				break;
			default:
				$result = array("error", utf8_encode("Houve um erro desconhecido, reporte ao Desenvolvedor."));
				break;
		}
	}
	
	// Return Results
	echo json_encode($result);
	exit;
?>