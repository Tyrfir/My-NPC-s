/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 © Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Versão: 3.0  .
  .---------------------------------------------------------------.
  .                           Consultas                           .
  *---------------------------------------------------------------*/
$(document).ready(function(){jQuery.fn.SearchChanged=function(){var e=$("option:selected",this),r=e.attr("enabledOpts");if(!r||r.length<=0)return void $(this).SearchOptions("all",!1);var a=r.split(",");$(this).SearchOptions("hour",a.indexOf("hour")>=0?!0:!1),$(this).SearchOptions("timer",a.indexOf("timer")>=0?!0:!1),$(this).SearchOptions("amount",a.indexOf("amount")>=0?!0:!1),$(this).SearchOptions("target",a.indexOf("target")>=0?!0:!1)},jQuery.fn.SearchOptions=function(e,r){r=r?!1:!0,("all"==e||"target"==e)&&($("#search #search_target").is(":visible")==r&&$("#search #search_target").slideToggle("slow"),$("#search #search_target #target").prop("disabled",r)),("all"==e||"amount"==e)&&($("#search #search_amount").is(":visible")==r&&$("#search #search_amount").slideToggle("slow"),$("#search #search_amount #amount").prop("disabled",r),$("#search #search_amount #amount_opt").prop("disabled",r)),("all"==e||"hour"==e)&&($("#search #search_hour").is(":visible")==r&&$("#search #search_hour").slideToggle("slow"),$("#search #search_hour #hour_opt").prop("disabled",r),$("#search #search_hour #hour").prop("disabled",r),$("#search #search_hour #minute").prop("disabled",r)),("all"==e||"timer"==e)&&($("#search #search_timer").is(":visible")==r&&$("#search #search_timer").slideToggle("slow"),$("#search #search_timer #timer_opt").prop("disabled",r),$("#search #search_timer #timer").prop("disabled",r))},$("#search #target_type").SearchChanged(),$("#search #primary-search").click(function(){$key=$("#search #primary-key").val(),$("#search #form-search input[name='key']").val($key),$("#search #form-search").submit()}),$("#search #form-search").submit(function(){return $key=$("#search #primary-key").val(),$("#search #form-search input[name='key']").val($key),!0}),$("#search #primary-key").keypress(function(e){13==e.which&&($key=$(this).val(),$("#search #form-search input[name='key']").val($key),$("#search #form-search").submit())}),$("#search #target").keydown(function(e){$targettype=$("#search #target_type").val(),$(this).AutoSuggest(e,"type="+$targettype)}),$("#search #target_type").change(function(){$(this).SearchChanged()})});