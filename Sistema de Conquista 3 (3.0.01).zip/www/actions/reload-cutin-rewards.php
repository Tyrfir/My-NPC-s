<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  .---------------------------------------------------------------.
  .            Pega uma lista de Recompensas atualizada           .
  *---------------------------------------------------------------*/
// Requirindo Bibliotecas
require_once('../config/Config.php');
require_once('../lib/Sql.class.php');
require_once('../lib/Achievement.class.php');
require_once('../lib/Numbers.class.php');
require_once('../lib/Template.class.php');

	$Ach = new Achievements;
	$Tpl = new Template;
	
	if( !isset($_POST['achievement_id']) || !is_numeric($_POST['achievement_id']) || empty($_POST['achievement_id']) )
		echo "error";
	else if( ($count = $Ach->LoadFromID($_POST['achievement_id'])) <= 0 )
		echo "error";
	else {
		$rewards = $Tpl->CreateRewardList($Ach->rewards[$_POST['achievement_id']]);
		echo $rewards;
	}
?>