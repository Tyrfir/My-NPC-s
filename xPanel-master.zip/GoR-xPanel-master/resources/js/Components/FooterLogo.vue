<template>
    <img src="/img/footer.png" alt="" />
</template>
