// � Creative Services and Development
// Site Oficial: www.creativesd.com.br
// Termos de Contrato e Autoria em: http://creativesd.com.br/?p=termos

#ifndef _ACHIEVEMENT_H_
#define _ACHIEVEMENT_H_

#include "../common/sql.h"
#include "clif.h"
#include "map.h" // EVENT_NAME_LENGTH

#ifndef RGB2BGR
	#define RGB2BGR(c) ((c & 0x0000FF) << 16 | (c & 0x00FF00) | (c & 0xFF0000) >> 16)
#endif

// M�ximo de Cutins a entrar no queue em m�ltiplas conquistas alcan�ada.
#define	MAX_ACH_QUEUE_CUTIN	5
// M�nimo de Recompensas a ser entregue aleat�riamente.
#define	MAX_ACH_RW_MIN_RANDOM	1
// M�ximo de Recompensas a ser entregue aleat�riamente.
#define MAX_ACH_RW_MAX_RANDOM	2
// Cores de Mensagem
static unsigned long achievement_color[4] = {0xFF0000, 0x00FA9A, 0x00FA9A, 0x1E90FF};

struct Achievement_Config {
	int reward_rate;
	int reward_rate_min;
	int reward_rate_max;
	char panel_link[127];
	char panel_pass[32];
} achievement_config;

enum ach_status {
	ACH_INPROGRESS,
	ACH_COMPLETE,
	ACH_FAIL
};

enum ach_message {
	ACH_M_FAIL,	// To Countdown fail!
	ACH_M_SUCCESS,
	ACH_M_REWARD,
	ACH_M_INIT
};

enum ach_lv {
	ACH_LV_ANYONE = 21,
	ACH_LV_BASE = 19,
	ACH_LV_JOB = 20
};

enum ach_reward {
	ACH_RW_ITEM,
	ACH_RW_ZENY,
	ACH_RW_CASH,
	ACH_RW_KAFRA,
	ACH_RW_BEXP,
	ACH_RW_JEXP,
	ACH_RW_BLVL,
	ACH_RW_JLVL,
	ACH_RW_STATUS
};

enum ach_secundary {
	ACH_SEC_MOB = 14,
	ACH_SEC_MAP = 15,
	ACH_SEC_JOB = 22,
	ACH_SEC_JOB2 = 24
};

enum ach_query {
	ACH_INCREMENT,
	ACH_UPDATE
};

enum ach_buysell_flag {
	ACH_BUY_NPC,
	ACH_BUY_PC,
	ACH_SELL_NPC,
	ACH_SELL_PC,
	ACH_TRADE_IN,
	ACH_TRADE_OUT
};

enum ach_zeny_flag {
	ACH_GET_ZENY,
	ACH_PAY_ZENY,
	ACH_GET_ZENY_T,
	ACH_PAY_ZENY_T
};

enum ach_battle {
	ACH_PVP,
	ACH_GVG,
	ACH_BG
};

enum ach_mob_type {
	ACH_NONE = 0,
	ACH_EMPERIUM = 4,
	ACH_NORMAL = 12,
	ACH_BARRICADE = 40,
	ACH_RUNESTONE = 41
};

enum ach_script_type {
	ACH_S_BATTLEGROUND = 3,
	ACH_S_GUARDIAN_STONE = 8,
	ACH_S_BARRICADE = 9
};

// Achievements Functions
int achievement_lvup(struct map_session_data *sd, int getlevel, enum ach_lv flag);
int achievement_jobchange(struct map_session_data *sd);
int achievement_negotiation_item(struct map_session_data *sd, int count, short item_list[], short amount_list[], enum ach_buysell_flag flag);
int achievement_zeny(struct map_session_data *sd, int zeny, enum ach_zeny_flag flag);
int achievement_takeitem(struct map_session_data *sd, int nameid, int amount, int mobid);
int achievement_useitem(struct map_session_data *sd, int nameid, int amount);
int achievement_pckill(struct map_session_data *sd, struct map_session_data *tsd);
int achievement_mobkill(struct map_session_data *sd, int mobid);
int achievement_is_mvp(int mobid);
int achievement_map(struct map_session_data *sd);
int achievement_refinement(struct map_session_data *sd, int item_id, int amount);
int achievement_timer(int tid, int64 tick, int id, intptr_t data);

// Achievement Scripts
//	- Construct Guardian Stone or Barrier.
//	- Winner Battleground
//
int achievement_scripts(struct map_session_data *sd, int amount, enum ach_script_type type);

// Achievement Count Down
int achievement_countdown(int tid, int64 tick, int id, intptr_t data);
int achievement_set_countdown(int achievement_id, int account_id);

// Data Functions
int achievement_data_status(int achievement_id, int account_id);
int achievement_secundary(int achievement_id, const char *target, enum ach_secundary type);
int achievement_target_value(int achievement_id, int type, const char *target) ;
int achievement_progress_value(int achievement_id, int account_id, int type, const char *target);
int achievement_update_data(int achievement_id, int account_id,  enum ach_status status);
int achievement_update_progress(int achievement_id, int account_id, int type, const char *target, int value, int flag);
int achievement_check_progress(int achievement_id, int account_id);
int achievement_check_target(int achievement_id, int type, const char *target);
int achievement_completed(struct map_session_data *sd, int achievement_id);
int achievement_clear(int achievement_id, int account_id);
int achievement_reward(struct map_session_data *sd, int achievement_id);
unsigned int achievement_rate_adjust(int baserate, int rate_adjust, unsigned short rate_min, unsigned short rate_max);
int achievement_cutin(int tid, int64 tick, int id, intptr_t data);
void achievement_message(int fd, enum ach_message flag, const char *msg);
void achievement_update_rank(int account_id);
int achievement_run_link(struct map_session_data *sd);
int achievement_config_read(void);

void do_init_achievement(void);
void do_final_achievement(void);

#endif /* _ACHIEVEMENT_H_ */
