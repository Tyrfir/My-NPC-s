<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  *---------------------------------------------------------------*/
class Template extends Achievements {
	// Temas
	public $theme = "";
	public $Templates = array();
	
	// Barra de Navega��o
	public $navBar = null;
	
	// Recompensas
	public $Rewards;
	
	// Exporta��o de Vari�veis
	public $JobNames;
	public $TargetDesc;
	
	// Iniciliza��o
	public function init($path = null) {
		$this->Templates = require(dirname(dirname(__FILE__))."\config\Templates.php");
		$this->JobNames = require(dirname(dirname(__FILE__))."\config\JobName.php");
		$this->TargetDesc = require(dirname(dirname(__FILE__))."\config\TargetDesc.php");
		$this->RewardsType = require(dirname(dirname(__FILE__))."\config\RewardsType.php");
		
		if( !count($this->Templates) )
			die("N�o h� templates cadastrada, por favor, verifique se as templates foram registrada!");
	
		//if( (isset($_GET['theme']) && $_GET['theme'] == 'default') || (!isset($_GET['theme']) && isset($_COOKIE['theme']) && $_COOKIE['theme'] == 'default') )
		//	$this->theme = Config::$TemplateDefault;
		//else
		if( isset($_GET['theme']) && isset($this->Templates[$_GET['theme']]) && file_exists($path.$this->Templates[$_GET['theme']]) )
			$this->theme = $_GET['theme'];
		else if( !isset($_COOKIE['theme']) || !isset($this->Templates[$_COOKIE['theme']]) || !file_exists($path.$this->Templates[$_COOKIE['theme']]) )
			$this->theme = $this->theme = Config::$TemplateDefault;
		else
			$this->theme = $_COOKIE['theme'];
		
		if( !empty($this->theme) )
			setcookie("theme",$this->theme, time() + (86400*30));
		
		return $this->theme;
	}
	
	// Cria uma navega��o num�rica
	public function createNavBar($current, $total, $max, $args, $custom = null) {
		$num = ceil($total/$max);
		
		$url = ($custom!=null?$custom:"?");
		foreach( $args as $key => $value ) {
			if( $key == 'backurl' )
				$value = urlencode($value);
			if( $key == 'page' )
				continue;	
			$url .= $key."=".$value."&";
		}
		
		$navBar = '<ul class="pagination">';
		if( $current <= 1 )
			$navBar .= '<li class="disabled"><a aria-label="Anterior"><span aria-hidden="true">&laquo;</span></a></li>';
		else
			$navBar .= '<li><a aria-label="Anterior" href="' . $url . 'page=' . ($current-1) . '"><span aria-hidden="true">&laquo;</span></a></li>';
		
		$count = 0;
		for( $i=0; $i < $num; $i++ ) {
			if( $count > 12 )
			{
				$navBar .= "</ul>";
				$navBar .= '<ul class="pagination">';
				$count = 0;
			}
			
			$navBar .= '<li'.($i==($current-1)?' class="active"':'').'><a href="' . $url . 'page=' . ($i+1) . '">' . ($i+1) . '</a></li>';
			$count++;
		}
		
		if( $current >= $num )
			$navBar .= '<li class="disabled"><a aria-label="Pr�ximo"><span aria-hidden="true">&raquo;</span></a></li>';
		else
			$navBar .= '<li><a href="' . $url . 'page=' . ($current+1) . '" aria-label="Pr�ximo"><span aria-hidden="true">&raquo;</span></a></li>';
	  
		$navBar .= '</ul>';
		$this->navBar = $navBar;
		return;
	}
	
	// Mostra a Barra de Navega��o
	public function showNavigation() {
		return print($this->navBar);
	}
	
	// Transforma sua url em inputs invis�veis.
	//
	// $ignore: Lista em Array com os par�metros que deve ser ignorado.
	//
	public function getUrlInput($ignore = array()) {
		$buff = "";
		foreach( $_GET as $key => $value ) {
			if( in_array($key, $ignore) )
				continue;
			
			$buff .= "<input type=\"hidden\" name=\"{$key}\" value=\"{$value}\">";
		}
		return $buff;
	}
	
	// Cria uma Lista de Itens
	//
	public function CreateRewardList($reward_list, $enable_percent = true, $correction_url = null) {
		$rewards = "";
		$path = str_replace("\\", "/", dirname(dirname(__FILE__)));
		for( $r=0, $count = 0; $r < $reward_list['count']; $r++ )
		{
			$object = str_replace("#", "", $reward_list['object'][$r]);
			$value = $reward_list['value'][$r];
			$type = $reward_list['type'][$r];
			$desc = $reward_list['desc'][$r];
			$percent = $reward_list['rate_percent'][$r];
			
			if( file_exists($path."/images/items/{$object}.gif") )
				$item_img = "images/items/{$object}.gif";
			else if( file_exists($path."/images/items/{$object}.png") )
				$item_img = "images/items/{$object}.png";
			else
				$item_img = "images/null.png";
			
			if( !$count )
				$rewards .= "<tr>";
			
			// Itens
			if( $type == 0 )
			{
				$item_name = parent::getitemname($object);
				
				if( empty($item_name) ) {
					if( empty($desc) )
						$item_name = "Desconhecido";
					else
						$item_name = $desc;
				}
				
				if( $enable_percent )
					$item_name .= "<span class=\"drop_chance\"> ({$percent}%)</span>";
				
				$value = Numbers::format_amount($value);
				$rewards .= "<td><img src='{$correction_url}{$item_img}'> <strong>{$value}x</strong> {$item_name}</td>";
			}
			// Zeny, Cash & Kafra Point, Base & Job Exp, Base & Job Level.
			else if( $type >= 1 && $type <= 7 ) {
				if( empty($desc) ) {
					$var_name = isset($this->RewardsType[$type])?$this->RewardsType[$type]:$object;
				}
				else
					$var_name = $desc;
				
				if( $enable_percent )
					$var_name .= "<span class=\"drop_chance\"> ({$percent}%)</span>";
				
				$value = Numbers::format_amount($value);
				$rewards .= "<td><img src='{$correction_url}{$item_img}'> <strong>{$value}x</strong> {$var_name}</td>";
			}
			// Bonus
			else {
				if( empty($desc) )
				{
					if( isset($BonusStatusList[$object]) )
						$bonus_name = $BonusStatusList[$object];
					else
						$bonus_name = "B�nus Desconhecido";
				}
				else
					$bonus_name = $desc;
				
				if( $enable_percent )
					$bonus_name .= "<span class=\"drop_chance\"> ({$percent}%)</span>";
				
				$value = Numbers::format_amount($value);
				$rewards .= "<td><img src='{$correction_url}{$item_img}'> <strong>+{$value}</strong> {$bonus_name}</td>";
			}
			$count++;
			if( $count >= 2 ) {
				$rewards .= "</tr>";
				$count = 0;
			}
		}
		
		$rewards = "<table class=\"table-reward\">{$rewards}</table>";
		return $rewards;
	}
	
	// Cria uma Lista de Objetivos
	//
	public function CreateTargetList($target_list)
	{
		// Preparar para aceitar valores.
		$targets = "";
		$in_mob = array();
		$in_map = array();
		$in_class = array();
		$in_class2 = array();
		$countdown = 0;
		
		for( $t=0; $t < $target_list['count']; $t++ ) {
			$type = $target_list['type'][$t];
			$target = $target_list['target'][$t];
			$value = $target_list['value'][$t];
			$progress = $target_list['progress'][$t];
			
			if( $progress > $value )
				$progress = $value;
			
			switch( $type ) {
				case 10:
					$desc = $this->TargetDesc[$type];
					$fvalue = $value - $progress;
					$f_progress = Numbers::calc_timer($fvalue);
					break;
				case 11:
					$desc = sprintf($this->TargetDesc[$type], parent::getmapname($target), $target);
					$f_value = Numbers::format_amount($value);
					$f_progress = Numbers::format_amount($progress);
					break;
				case 12:
					$db_url = sprintf("%s%s%d", Config::$roDB['url'], Config::$roDB['mob'], $target);
					$desc = sprintf($this->TargetDesc[$type], $db_url, parent::getmobname($target));
					$f_value = Numbers::format_amount($value);
					$f_progress = Numbers::format_amount($progress);
					break;
				case 13: case 25: case 26: case 27: case 28:
				case 32: case 33: case 34:
					$db_url = sprintf("%s%s%d", Config::$roDB['url'], Config::$roDB['item'], $target);
					$desc = sprintf($this->TargetDesc[$type], $db_url, parent::getitemname($target));
					$f_value = Numbers::format_amount($value);
					$f_progress = Numbers::format_amount($progress);
					break;
				case 14:
					$in_mob[] = $target;
					continue 2;
				case 15:
					$in_map[] = $target;
					continue 2;
				case 17:
					$desc = sprintf($this->TargetDesc[$type], $target);
					$f_value = Numbers::format_amount($value);
					$f_progress = Numbers::format_amount($progress);
					break;
				case 22:
					if(
						($target == 7 && in_array(13, $in_class)) || ($target == 13 && in_array(7, $in_class)) ||			// Cavaleiro
						($target == 14 && in_array(21, $in_class)) || ($target == 21 && in_array(14, $in_class)) ||			// Templ�rio
						($target == 4008 && in_array(4014, $in_class)) || ($target == 4014 && in_array(4008, $in_class)) ||	// Lorde
						($target == 4015 && in_array(4022, $in_class)) || ($target == 4022 && in_array(4015, $in_class)) ||	// Paladino
						($target == 4030 && in_array(4036, $in_class)) || ($target == 4036 && in_array(4030, $in_class)) ||	// Mini Cavaleiro
						($target == 4037 && in_array(4044, $in_class)) || ($target == 4044 && in_array(4037, $in_class)) ||	// Mini Templ�rio
						($target == 4047 && in_array(4048, $in_class)) || ($target == 4048 && in_array(4047, $in_class)) ||	// Mestre Taekwon
						($target == 4054 && in_array(4080, $in_class)) || ($target == 4080 && in_array(4054, $in_class)) ||	// Guardi�o R�nico
						($target == 4060 && in_array(4081, $in_class)) || ($target == 4081 && in_array(4060, $in_class)) ||	// Guardi�o R�nico T.
						($target == 4066 && in_array(4082, $in_class)) || ($target == 4082 && in_array(4066, $in_class)) ||	// Guardi�o Real
						($target == 4073 && in_array(4084, $in_class)) || ($target == 4084 && in_array(4073, $in_class)) ||	// Guardi�o Real T.
						($target == 4058 && in_array(4086, $in_class)) || ($target == 4086 && in_array(4058, $in_class)) ||	// Mec�nico
						($target == 4064 && in_array(4087, $in_class)) || ($target == 4087 && in_array(4064, $in_class)) ||	// Mec�nico T.
						($target == 4056 && in_array(4084, $in_class)) || ($target == 4084 && in_array(4054, $in_class)) ||	// Sentinela
						($target == 4062 && in_array(4085, $in_class)) || ($target == 4085 && in_array(4062, $in_class))	// Sentinela T.
					) continue 2;
					
					$in_class[] = $target;
					continue 2;
				case 24:
					if(
						($target == 7 && in_array(13, $in_class2)) || ($target == 13 && in_array(7, $in_class2)) ||			// Cavaleiro
						($target == 14 && in_array(21, $in_class2)) || ($target == 21 && in_array(14, $in_class2)) ||			// Templ�rio
						($target == 4008 && in_array(4014, $in_class2)) || ($target == 4014 && in_array(4008, $in_class2)) ||	// Lorde
						($target == 4015 && in_array(4022, $in_class2)) || ($target == 4022 && in_array(4015, $in_class2)) ||	// Paladino
						($target == 4030 && in_array(4036, $in_class2)) || ($target == 4036 && in_array(4030, $in_class2)) ||	// Mini Cavaleiro
						($target == 4037 && in_array(4044, $in_class2)) || ($target == 4044 && in_array(4037, $in_class2)) ||	// Mini Templ�rio
						($target == 4047 && in_array(4048, $in_class2)) || ($target == 4048 && in_array(4047, $in_class2)) ||	// Mestre Taekwon
						($target == 4054 && in_array(4080, $in_class2)) || ($target == 4080 && in_array(4054, $in_class2)) ||	// Guardi�o R�nico
						($target == 4060 && in_array(4081, $in_class2)) || ($target == 4081 && in_array(4060, $in_class2)) ||	// Guardi�o R�nico T.
						($target == 4066 && in_array(4082, $in_class2)) || ($target == 4082 && in_array(4066, $in_class2)) ||	// Guardi�o Real
						($target == 4073 && in_array(4084, $in_class2)) || ($target == 4084 && in_array(4073, $in_class2)) ||	// Guardi�o Real T.
						($target == 4058 && in_array(4086, $in_class2)) || ($target == 4086 && in_array(4058, $in_class2)) ||	// Mec�nico
						($target == 4064 && in_array(4087, $in_class2)) || ($target == 4087 && in_array(4064, $in_class2)) ||	// Mec�nico T.
						($target == 4056 && in_array(4084, $in_class2)) || ($target == 4084 && in_array(4054, $in_class2)) ||	// Sentinela
						($target == 4062 && in_array(4085, $in_class2)) || ($target == 4085 && in_array(4062, $in_class2))	// Sentinela T.
					) continue 2;
					
					$in_class2[] = $target;
					continue 2;
				case 51:
					// Especial Countdown!
					$countdown = $value-$progress;
					continue 2;
				case 52:
					$name = parent::getInfo($target, 'name');
					$desc = sprintf($this->TargetDesc[$type], $name);
					break;
				default:
					$desc = $this->TargetDesc[$type];
					$f_value = Numbers::format_amount($value);
					$f_progress = Numbers::format_amount($progress);
					break;
			}
			
			if( $type == 10 ) {
				if( $progress >= $value )
					$targets .= "<tr><td>{$desc}</td><td><span class=\"completed\">COMPLETADO</span><td></td></tr>";
				else
					$targets .= "<tr><td>{$desc}</td><td><span class=\"in-progress-val\">{$f_progress}</span> <span class=\"in-progress\">restantes</span></td></tr>";
			}
			else {
				if( $progress >= $value )
					$targets .= "<tr><td>{$desc}</td><td><span class=\"completed\">COMPLETADO</span></td></tr>";
				else
					$targets .= "<tr><td>{$desc}</td><td><span class=\"in-progress-val\">{$f_progress}</span><span class=\"in-progress\">/{$f_value}</span></td></tr>";
			}
		}
		
		if( !empty($targets) )
			$targets = "<table class=\"table-progress\"><tr><th>Objetivo</th><th>Progresso</th>{$targets}</table>";
		
		if( count($in_map) || count($in_mob) || count($in_class) || count($in_class2) )
		{
			$targets .= "<div class=\"pre-requeriments\"><span class=\"title\">Pr�-Requisitos</span><ul>";
			if( count($in_class) )
			{
				if( count($in_class) > 1 )
					$targets .= "<li>Estar em uma das seguintes Classes:<ul>";
				else
					$targets .= "<li>Estar na seguinte Classe:<ul>";
				
				for( $d=0; $d < count($in_class); $d++ ) {
					if( !array_key_exists($in_class[$d],$this->JobNames) )
						$dname = "Classe ({$in_class[$d]}) Desconhecida";
					else
						$dname = $this->JobNames[$in_class[$d]];
					
					$targets .= "<li>{$dname}</li>";
				}
				
				$targets .= "</ul></li>";
			}
			
			if( count($in_class2) )
			{
				if( count($in_class2) > 1 )
					$targets .= "<li>O Jogador alvo deve estar em uma das seguintes Classes:<ul>";
				else
					$targets .= "<li>O Jogador alvo deve estar na seguinte Classe:<ul>";
				
				for( $d=0; $d < count($in_class2); $d++ ) {
					if( !array_key_exists($in_class2[$d],$this->JobNames) )
						$dname = "Classe ({$in_class2[$d]}) Desconhecida";
					else
						$dname = $this->JobNames[$in_class2[$d]];
					
					$targets .= "<li>{$dname}</li>";
				}
				
				$targets .= "</ul></li>";
			}
			
			if( count($in_map) )
			{
				if( count($in_map) > 1 )
					$targets .= "<li>Estar em um dos seguintes Mapas:<ul>";
				else
					$targets .= "<li>Estar no seguinte Mapa:<ul>";
				
				for( $d=0; $d < count($in_map); $d++ ) {
					$dname = parent::getmapname($in_map[$d]) . " ({$in_map[$d]})";
					$targets .= "<li>{$dname}</li>";
				}
				
				$targets .= "</ul></li>";
			}
			
			if( count($in_mob) )
			{
				if( count($in_mob) > 1 )
					$targets .= "<li>Estar em um dos seguintes Monstros:<ul>";
				else
					$targets .= "<li>Estar no seguinte Monstro:<ul>";
				
				for( $d=0; $d < count($in_mob); $d++ ) {
					$dname = parent::getmobname($in_mob[$d]);
					$db_url = sprintf("%s%s%d", Config::$roDB['url'], Config::$roDB['mob'], $in_mob[$d]);
					$targets .= sprintf("<li><a href=\"%s\">%s</a></li>", $db_url, $dname);
				}
				
				$targets .= "</ul></li>";
			}
			
			$targets .= "</ul></div>";
		}
		
		if( $countdown )
		{
			$f_value = Numbers::calc_timer_sec($countdown);
			$targets .= "<div class=\"countdown\"><strong>Tempo para Expirar:</strong> {$f_value}</div>";
		}
		return $targets;
	}
}
?>