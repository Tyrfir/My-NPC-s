// � Creative Services and Development
// Site Oficial: www.creativesd.com.br
// Termos de Contrato e Autoria em: http://creativesd.com.br/?p=termos

#include "../common/cbasetypes.h"
#include "../common/timer.h"
#include "../common/malloc.h"
#include "../common/md5calc.h"
#include "../common/nullpo.h"
#include "../common/showmsg.h"
#include "../common/socket.h"
#include "../common/strlib.h"
#include "../common/sql.h"
#include "../common/utils.h"

#include "achievement.h"
#include "clif.h"
#include "map.h"
#include "party.h"
#include "pc.h"
#include "storage.h"
#include "script.h"
#include "npc.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

struct Achievement_Config achievement_config;

// Achievements Base/Job Level.
//
int achievement_lvup(struct map_session_data *sd, int getlevel, enum ach_lv flag)
{
	SqlStmt* stmt = SqlStmt_Malloc(mmysql_handle);
	int achievement_id, type;
	char job[50];
	char target[2][50] = { "BaseLevel", "JobLevel" };
	short level[2];

	nullpo_ret(sd);

	if( sd == NULL )
		return 0;

	level[0] = sd->status.base_level;
	level[1] = sd->status.job_level;

	type = flag == ACH_LV_BASE ? 0 : 1;

	/// Convert job int to char
	itoa(sd->status.class_, job, 10);

	if( SQL_ERROR == SqlStmt_Prepare(stmt, "SELECT `a`.`id` FROM `achievement_db` AS `a` WHERE `a`.`status`='1' AND ((SELECT COUNT(*) FROM `achievement_data` WHERE `account_id`='%d' AND `achievement_id`=`a`.`id` AND `status`!='0') <= '0') AND (SELECT COUNT(*) FROM `achievement_req` WHERE `achievement_id`=`a`.`id` AND `status`='1' AND (`type`='%d' OR `type`='%d')) > 0", sd->status.account_id, ACH_LV_ANYONE, flag)
		|| SQL_ERROR == SqlStmt_Execute(stmt)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 0,  SQLDT_INT, &achievement_id, 0, NULL, NULL)
	) {
		SqlStmt_ShowDebug(stmt);
		SqlStmt_Free(stmt);
		return 0;
	}

	while( SQL_SUCCESS == SqlStmt_NextRow(stmt) )
	{
		int status, check_map, check_job, get_value_1, get_value_2, check_progress, n_level = 0;
		status = achievement_data_status(achievement_id, sd->status.account_id);
		
		if( status > 0 )
			continue;

		check_map = achievement_secundary(achievement_id, map[sd->bl.m].name, ACH_SEC_MAP);
		check_job = achievement_secundary(achievement_id, (const char*)job, ACH_SEC_JOB);

		if( check_map <= 0 || check_job <= 0 )
			continue;

		get_value_1 = achievement_target_value(achievement_id, flag, (const char*)target[type]);
		get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, flag, (const char*)target[type]);

		if( get_value_2 < get_value_1 && ((int)level[type] >= get_value_1 || (int)level[type] >= get_value_2) ) {
			n_level = n_level > get_value_1 ? get_value_1 : (int)level[type];
			achievement_update_progress(achievement_id, sd->status.account_id, flag, (const char*)target[type], n_level, ACH_UPDATE);
		}

		get_value_1 = achievement_target_value(achievement_id, ACH_LV_ANYONE, "AnyLevel");
		get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, ACH_LV_ANYONE, "AnyLevel");

		if( get_value_2 < get_value_1  )
			achievement_update_progress(achievement_id, sd->status.account_id, ACH_LV_ANYONE, "AnyLevel", getlevel, ACH_INCREMENT);

		if( status < 0 ) {
			achievement_update_data(achievement_id, sd->status.account_id, ACH_INPROGRESS);
			achievement_set_countdown(achievement_id, sd->status.account_id);
		}

		check_progress = achievement_check_progress(achievement_id, sd->status.account_id);
		if( check_progress )
			achievement_completed(sd,achievement_id);
	}
	SqlStmt_FreeResult(stmt);
	return 1;
}

// Achievements JobChange
//
int achievement_jobchange(struct map_session_data *sd)
{
	SqlStmt* stmt = SqlStmt_Malloc(mmysql_handle);
	char job[50];
	int achievement_id;

	nullpo_ret(sd);

	if( sd == NULL )
		return 0;

	// Convert job int to char
	itoa(sd->status.class_, job, 10);

	if( SQL_ERROR == SqlStmt_Prepare(stmt, "SELECT `a`.`id` FROM `achievement_db` AS `a` WHERE `a`.`status`='1' AND ((SELECT COUNT(*) FROM `achievement_data` WHERE `account_id`='%d' AND `achievement_id`=`a`.`id` AND `status`!='0') <= '0') AND (SELECT COUNT(*) FROM `achievement_req` WHERE `achievement_id`=`a`.`id` AND `status`='1' AND (`type`='22' OR `type`='23') AND `target`='%d') > 0", sd->status.account_id, sd->status.class_)
		|| SQL_ERROR == SqlStmt_Execute(stmt)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 0,  SQLDT_INT, &achievement_id, 0, NULL, NULL)
	) {
		SqlStmt_ShowDebug(stmt);
		SqlStmt_Free(stmt);
		return 0;
	}

	while( SQL_SUCCESS == SqlStmt_NextRow(stmt) )
	{
		int status, check_map, check_job, get_value_1, get_value_2, check_progress, ach_type_1, ach_type_2;
		status = achievement_data_status(achievement_id, sd->status.account_id);
		
		if( status > 0 )
			continue;

		ach_type_1 = achievement_check_target(achievement_id, 22, (const char*)job);
		ach_type_2 = achievement_check_target(achievement_id, 23, (const char*)job);

		check_map = achievement_secundary(achievement_id, map[sd->bl.m].name, ACH_SEC_MAP);
		check_job = achievement_secundary(achievement_id, (const char*)job, ACH_SEC_JOB);

		if( check_map <= 0 || check_job <= 0 || (!ach_type_1 && !ach_type_2) )
			continue;

		if( ach_type_2 )
		{
			get_value_1 = achievement_target_value(achievement_id, 23, (const char*)job);
			get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, 23, (const char*)job);

			if( get_value_1 < get_value_2 )
				achievement_update_progress(achievement_id, sd->status.account_id, 23, (const char*)sd->status.class_, 1, ACH_INCREMENT);
		
			if( status < 0 ) {
				achievement_update_data(achievement_id, sd->status.account_id, ACH_INPROGRESS);
				achievement_set_countdown(achievement_id, sd->status.account_id);
			}
		}

		check_progress = achievement_check_progress(achievement_id, sd->status.account_id);
		if( check_progress )
			achievement_completed(sd,achievement_id);
	}
	SqlStmt_FreeResult(stmt);
	return 1;
}

// Achievement Buy, Sell or Trade Item.
//
int achievement_negotiation_item(struct map_session_data *sd, int count, short item_list[], short amount_list[], enum ach_buysell_flag flag)
{
	SqlStmt* stmt = SqlStmt_Malloc(mmysql_handle);
	int achievement_id, i;
	char job[50];
	short type[4];

	nullpo_ret(sd);

	if( sd == NULL )
		return 0;

	if( count <= 0 )
		return 1;

	// Configure Types
	//
	switch( flag )
	{
		case ACH_BUY_NPC:
			type[0] = 26; type[1] = 28; type[2] = 29; type[3] = 31;
			break;
		case ACH_BUY_PC:
			type[0] = 27; type[1] = 28; type[2] = 29; type[3] = 31;
			break;
		case ACH_SELL_NPC:
			type[0] = 32; type[1] = 34; type[2] = 35; type[3] = 37;
			break;
		case ACH_SELL_PC:
			type[0] = 33; type[1] = 34; type[2] = 36; type[3] = 37;
			break;
		case ACH_TRADE_IN:
			type[0] = 38; type[1] = 40; type[2] = 41; type[3] = 43;
			break;
		case ACH_TRADE_OUT:
			type[0] = 39; type[1] = 40; type[2] = 42; type[3] = 43;
			break;
		default:
			ShowError("achievement_negotiation_item: Unknown flag type '%d'.\n", flag);
			return 0;
	}

	// Convert job int to char
	itoa(sd->status.class_, job, 10);

	ShowDebug("SELECT `a`.`id` FROM `achievement_db` AS `a` WHERE `a`.`status`='1' AND((SELECT COUNT(*) FROM `achievement_data` WHERE `account_id`='%d' AND `achievement_id`=`a`.`id` AND `status`! = '0') <= '0') AND (SELECT COUNT(*) FROM `achievement_req` WHERE `achievement_id`=`a`.`id` AND `status`='1' AND(`type`='%d' OR `type`='%d' OR `type`='%d' OR `type`='%d')) > 0\n", sd->status.account_id, type[0], type[1], type[2], type[3]);
	if( SQL_ERROR == SqlStmt_Prepare(stmt, "SELECT `a`.`id` FROM `achievement_db` AS `a` WHERE `a`.`status`='1' AND ((SELECT COUNT(*) FROM `achievement_data` WHERE `account_id`='%d' AND `achievement_id`=`a`.`id` AND `status`!='0') <= '0') AND (SELECT COUNT(*) FROM `achievement_req` WHERE `achievement_id`=`a`.`id` AND `status`='1' AND (`type`='%d' OR `type`='%d' OR `type`='%d' OR `type`='%d')) > 0", sd->status.account_id, type[0], type[1], type[2], type[3])
		|| SQL_ERROR == SqlStmt_Execute(stmt)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 0,  SQLDT_INT, &achievement_id, 0, NULL, NULL)
	) {
		SqlStmt_ShowDebug(stmt);
		SqlStmt_Free(stmt);
		return 0;
	}

	while( SQL_SUCCESS == SqlStmt_NextRow(stmt) )
	{
		char target[50];
		int status, check_map, check_job, get_value_1, get_value_2, check_progress, type_1, type_2, type_3, type_4;
		status = achievement_data_status(achievement_id, sd->status.account_id);
		
		if( status > 0 )
			continue;

		check_map = achievement_secundary(achievement_id, map[sd->bl.m].name, ACH_SEC_MAP);
		check_job = achievement_secundary(achievement_id, (const char*)job, ACH_SEC_JOB);

		if( check_map <= 0 || check_job <= 0 )
			continue;

		// Achievement item
		for( i = 0; i < count; i++ )
		{
			if( item_list[i] <= 0 || amount_list[i] <= 0 )
				continue;

			// Convert target int to char
			itoa(item_list[i], target, 10);

			type_1 = achievement_check_target(achievement_id, (int)type[0], target);
			type_2 = achievement_check_target(achievement_id, (int)type[1], target);
			type_3 = achievement_check_target(achievement_id, (int)type[2], "anyitem");
			type_4 = achievement_check_target(achievement_id, (int)type[3], "anyitem");

			if( !type_1 && !type_2 && !type_3 && !type_4 )
				continue;

			if( type_1 ) {
				get_value_1 = achievement_target_value(achievement_id, (int)type[0], (const char*)target);
				get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, (int)type[0], (const char*)target);

				if( get_value_2 < get_value_1 )
					achievement_update_progress(achievement_id, sd->status.account_id, (int)type[0], (const char*)target, (int)amount_list[i], ACH_INCREMENT);
			}

			if( type_2 ) {
				get_value_1 = achievement_target_value(achievement_id, (int)type[1], (const char*)target);
				get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, (int)type[1], (const char*)target);

				if( get_value_2 < get_value_1 )
					achievement_update_progress(achievement_id, sd->status.account_id, (int)type[1], (const char*)target, (int)amount_list[i], ACH_INCREMENT);
			}

			if( type_3 ) {
				get_value_1 = achievement_target_value(achievement_id, (int)type[2], "anyitem");
				get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, (int)type[2], "anyitem");

				if( get_value_2 < get_value_1 )
					achievement_update_progress(achievement_id, sd->status.account_id, (int)type[2], "anyitem", (int)amount_list[i], ACH_INCREMENT);
			}

			if( type_4 ) {
				get_value_1 = achievement_target_value(achievement_id, (int)type[3], "anyitem");
				get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, (int)type[3], "anyitem");

				if( get_value_2 < get_value_1 )
					achievement_update_progress(achievement_id, sd->status.account_id, (int)type[3], "anyitem", (int)amount_list[i], ACH_INCREMENT);
			}
		}

		if( status < 0 ) {
			achievement_update_data(achievement_id, sd->status.account_id, ACH_INPROGRESS);
			achievement_set_countdown(achievement_id, sd->status.account_id);
		}

		check_progress = achievement_check_progress(achievement_id, sd->status.account_id);
		if( check_progress )
			achievement_completed(sd,achievement_id);
	}
	SqlStmt_FreeResult(stmt);
	return 1;
}

// Achievement Zeny
//
int achievement_zeny(struct map_session_data *sd, int zeny, enum ach_zeny_flag flag)
{
	SqlStmt* stmt = SqlStmt_Malloc(mmysql_handle);
	int achievement_id;
	char job[50];
	short type[2];

	nullpo_ret(sd);

	if( sd == NULL )
		return 0;

	if( zeny <= 0 )
		return 1;

	// Configure Types
	//
	switch( flag )
	{
		case ACH_GET_ZENY:
			type[0] = 5; type[1] = 18;
			break;
		case ACH_PAY_ZENY:
			type[0] = 6; type[1] = 7;
			break;
		case ACH_GET_ZENY_T:
			type[0] = 44; type[1] = 46;
			break;
		case ACH_PAY_ZENY_T:
			type[0] = 45; type[1] = 47;
			break;
		default:
			ShowError("achievement_zeny: Unknown flag type '%d'.\n", flag);
			return 0;
	}

	// Convert job int to char
	itoa(sd->status.class_, job, 10);

	if( SQL_ERROR == SqlStmt_Prepare(stmt, "SELECT `a`.`id` FROM `achievement_db` AS `a` WHERE `a`.`status`='1' AND ((SELECT COUNT(*) FROM `achievement_data` WHERE `account_id`='%d' AND `achievement_id`=`a`.`id` AND `status`!='0') <= '0') AND (SELECT COUNT(*) FROM `achievement_req` WHERE `achievement_id`=`a`.`id` AND `status`='1' AND (`type`='%d' OR (`type`='%d' AND `value`='%d'))) > 0", sd->status.account_id, type[0], type[1], zeny)
		|| SQL_ERROR == SqlStmt_Execute(stmt)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 0,  SQLDT_INT, &achievement_id, 0, NULL, NULL)
	) {
		SqlStmt_ShowDebug(stmt);
		SqlStmt_Free(stmt);
		return 0;
	}

	while( SQL_SUCCESS == SqlStmt_NextRow(stmt) )
	{
		int status, check_map, check_job, get_value_1, get_value_2, check_progress, type_1, type_2;
		status = achievement_data_status(achievement_id, sd->status.account_id);
		
		if( status > 0 )
			continue;

		check_map = achievement_secundary(achievement_id, map[sd->bl.m].name, ACH_SEC_MAP);
		check_job = achievement_secundary(achievement_id, (const char*)job, ACH_SEC_JOB);

		if( check_map <= 0 || check_job <= 0 )
			continue;

		type_1 = achievement_check_target(achievement_id, (int)type[0], "zeny");
		type_2 = achievement_check_target(achievement_id, (int)type[1], "zeny");

		if( !type_1 && !type_2 )
			continue;

		if( type_1 ) {
			get_value_1 = achievement_target_value(achievement_id, (int)type[0], "zeny");
			get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, (int)type[0], "zeny");

			if( get_value_2 < get_value_1 )
				achievement_update_progress(achievement_id, sd->status.account_id, (int)type[0], "zeny", zeny, ACH_INCREMENT);
		}

		if( type_2 ) {
			get_value_1 = achievement_target_value(achievement_id, (int)type[1], "zeny");
			get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, (int)type[1], "zeny");

			if( get_value_2 < get_value_1 && zeny > get_value_2 )
				achievement_update_progress(achievement_id, sd->status.account_id, (int)type[1], "zeny", zeny, ACH_UPDATE);
		}

		if( status < 0 ) {
			achievement_update_data(achievement_id, sd->status.account_id, ACH_INPROGRESS);
			achievement_set_countdown(achievement_id, sd->status.account_id);
		}

		check_progress = achievement_check_progress(achievement_id, sd->status.account_id);
		if( check_progress )
			achievement_completed(sd,achievement_id);
	}
	SqlStmt_FreeResult(stmt);
	return 1;
}

// Take Item
//
int achievement_takeitem(struct map_session_data *sd, int nameid, int amount, int mobid)
{
	SqlStmt* stmt = SqlStmt_Malloc(mmysql_handle);
	int achievement_id;
	char job[50], mob[50], item[50];

	nullpo_ret(sd);

	if( sd == NULL )
		return 0;

	if( nameid <= 0 || amount <= 0 || mobid <= 0 )
		return 0;

	// Convert job/mob/item, int to char
	itoa(sd->status.class_, job, 10);
	itoa(mobid, mob, 10);
	itoa(nameid, item, 10);

	if( SQL_ERROR == SqlStmt_Prepare(stmt, "SELECT `a`.`id` FROM `achievement_db` AS `a` WHERE `a`.`status`='1' AND ((SELECT COUNT(*) FROM `achievement_data` WHERE `account_id`='%d' AND `achievement_id`=`a`.`id` AND `status`!='0') <= '0') AND (SELECT COUNT(*) FROM `achievement_req` WHERE `achievement_id`=`a`.`id` AND `status`='1' AND (`type`='13' AND target='%d')) > 0", sd->status.account_id, nameid)
		|| SQL_ERROR == SqlStmt_Execute(stmt)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 0,  SQLDT_INT, &achievement_id, 0, NULL, NULL)
	) {
		SqlStmt_ShowDebug(stmt);
		SqlStmt_Free(stmt);
		return 0;
	}

	while( SQL_SUCCESS == SqlStmt_NextRow(stmt) )
	{
		int status, check_map, check_job, check_mob, get_value_1, get_value_2, check_progress;
		status = achievement_data_status(achievement_id, sd->status.account_id);
		
		if( status > 0 )
			continue;

		check_map = achievement_secundary(achievement_id, map[sd->bl.m].name, ACH_SEC_MAP);
		check_job = achievement_secundary(achievement_id, (const char*)job, ACH_SEC_JOB);
		check_mob = achievement_secundary(achievement_id, (const char*)mob, ACH_SEC_MOB);

		if( check_map <= 0 || check_job <= 0 || check_mob <= 0 )
			continue;

		get_value_1 = achievement_target_value(achievement_id, 13, (const char*)item);
		get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, 13, (const char*)item);

		if( get_value_2 < get_value_1 )
			achievement_update_progress(achievement_id, sd->status.account_id, 13, (const char*)item, amount, ACH_INCREMENT);

		if( status < 0 ) {
			achievement_update_data(achievement_id, sd->status.account_id, ACH_INPROGRESS);
			achievement_set_countdown(achievement_id, sd->status.account_id);
		}

		check_progress = achievement_check_progress(achievement_id, sd->status.account_id);
		if( check_progress )
			achievement_completed(sd,achievement_id);
	}
	SqlStmt_FreeResult(stmt);
	return 1;
}

// Use Item
//
int achievement_useitem(struct map_session_data *sd, int nameid, int amount)
{
	SqlStmt* stmt = SqlStmt_Malloc(mmysql_handle);
	int achievement_id;
	char job[50], item[50];

	nullpo_ret(sd);

	if( sd == NULL )
		return 0;

	if( nameid <= 0 )
		return 0;

	// Convert job/mob/item, int to char
	itoa(sd->status.class_, job, 10);
	itoa(nameid, item, 10);

	if( SQL_ERROR == SqlStmt_Prepare(stmt, "SELECT `a`.`id` FROM `achievement_db` AS `a` WHERE `a`.`status`='1' AND ((SELECT COUNT(*) FROM `achievement_data` WHERE `account_id`='%d' AND `achievement_id`=`a`.`id` AND `status`!='0') <= '0') AND (SELECT COUNT(*) FROM `achievement_req` WHERE `achievement_id`=`a`.`id` AND `status`='1' AND (`type`='25' AND target='%d'))) > 0", sd->status.account_id, nameid)
		|| SQL_ERROR == SqlStmt_Execute(stmt)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 0,  SQLDT_INT, &achievement_id, 0, NULL, NULL)
	) {
		SqlStmt_ShowDebug(stmt);
		SqlStmt_Free(stmt);
		return 0;
	}

	while( SQL_SUCCESS == SqlStmt_NextRow(stmt) )
	{
		int status, check_map, check_job, get_value_1, get_value_2, check_progress;
		status = achievement_data_status(achievement_id, sd->status.account_id);
		
		if( status > 0 )
			continue;

		check_map = achievement_secundary(achievement_id, map[sd->bl.m].name, ACH_SEC_MAP);
		check_job = achievement_secundary(achievement_id, (const char*)job, ACH_SEC_JOB);

		if( check_map <= 0 || check_job <= 0 )
			continue;

		get_value_1 = achievement_target_value(achievement_id, 25, (const char*)item);
		get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, 25, (const char*)item);

		if( get_value_2 < get_value_1 )
			achievement_update_progress(achievement_id, sd->status.account_id, 25, (const char*)item, amount, ACH_INCREMENT);

		if( status < 0 ) {
			achievement_update_data(achievement_id, sd->status.account_id, ACH_INPROGRESS);
			achievement_set_countdown(achievement_id, sd->status.account_id);
		}

		check_progress = achievement_check_progress(achievement_id, sd->status.account_id);
		if( check_progress )
			achievement_completed(sd,achievement_id);
	}
	SqlStmt_FreeResult(stmt);
	return 1;
}

// Players Kill Achievement
//
int achievement_pckill(struct map_session_data *sd, struct map_session_data *tsd)
{
	SqlStmt* stmt = SqlStmt_Malloc(mmysql_handle);
	int achievement_id;
	char job1[50], job2[50];
	enum ach_battle type;

	nullpo_ret(sd);
	nullpo_ret(tsd);

	if( sd == NULL || tsd == NULL )
		return 0;

	// Convert job/mob/item, int to char
	itoa(sd->status.class_, job1, 10);
	itoa(tsd->status.class_, job2, 10);

	if( map[sd->bl.m].flag.battleground && sd->bg_id != tsd->bg_id )
		type = ACH_BG;
	else if( (map[sd->bl.m].flag.gvg || map[sd->bl.m].flag.gvg_castle) && sd->status.guild_id && tsd->status.guild_id && sd->status.guild_id != tsd->status.guild_id )
		type = ACH_GVG;
	else
		type = ACH_PVP;

	if( SQL_ERROR == SqlStmt_Prepare(stmt, "SELECT `a`.`id` FROM `achievement_db` AS `a` WHERE `a`.`status`='1' AND ((SELECT COUNT(*) FROM `achievement_data` WHERE `account_id`='%d' AND `achievement_id`=`a`.`id` AND `status`!='0') <= '0') AND (SELECT COUNT(*) FROM `achievement_req` WHERE `achievement_id`=`a`.`id` AND `status`='1' AND (`type`='0' AND type='%d')) > 0", sd->status.account_id, type)
		|| SQL_ERROR == SqlStmt_Execute(stmt)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 0,  SQLDT_INT, &achievement_id, 0, NULL, NULL)
	) {
		SqlStmt_ShowDebug(stmt);
		SqlStmt_Free(stmt);
		return 0;
	}

	while( SQL_SUCCESS == SqlStmt_NextRow(stmt) )
	{
		int status, check_map, check_job1, check_job2, get_value_1, get_value_2, check_progress, type_1, type_2 = 0;
		status = achievement_data_status(achievement_id, sd->status.account_id);
		
		if( status > 0 )
			continue;

		check_map = achievement_secundary(achievement_id, map[sd->bl.m].name, ACH_SEC_MAP);
		check_job1 = achievement_secundary(achievement_id, (const char*)job1, ACH_SEC_JOB);
		check_job2 = achievement_secundary(achievement_id, (const char*)job2, ACH_SEC_JOB2);

		if( check_map <= 0 || check_job1 <= 0 || check_job2 <= 0 )
			continue;

		type_1 = achievement_check_target(achievement_id, ACH_PVP, "player");

		if( type != ACH_PVP )
			type_2 = achievement_check_target(achievement_id, type, "player");

		if( type_1 ) {
			get_value_1 = achievement_target_value(achievement_id, ACH_PVP, "player");
			get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, ACH_PVP, "player");

			if( get_value_2 < get_value_1 )
				achievement_update_progress(achievement_id, sd->status.account_id, ACH_PVP, "player", 1, ACH_INCREMENT);
		}

		if( type_2 ) {
			get_value_1 = achievement_target_value(achievement_id, type, "player");
			get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, type, "player");

			if( get_value_2 < get_value_1 )
				achievement_update_progress(achievement_id, sd->status.account_id, type, "player", 1, ACH_INCREMENT);
		}

		if( status < 0 ) {
			achievement_update_data(achievement_id, sd->status.account_id, ACH_INPROGRESS);
			achievement_set_countdown(achievement_id, sd->status.account_id);
		}

		check_progress = achievement_check_progress(achievement_id, sd->status.account_id);
		if( check_progress )
			achievement_completed(sd,achievement_id);
	}
	SqlStmt_FreeResult(stmt);
	return 1;
}

// Achievement Mob Kill
//
int achievement_mobkill(struct map_session_data *sd, int mobid)
{
	SqlStmt* stmt = SqlStmt_Malloc(mmysql_handle);
	StringBuf buff;
	int achievement_id, is_mvp;
	char job[50], target[50], target2[50];
	enum ach_mob_type type = ACH_NONE;

	if( sd == NULL )
		return 0;

	if( mobid <= 0 )
		return 0;

	/// Convert mobid/job int to char
	itoa(sd->status.class_, job, 10);
	itoa(mobid, target, 10);

	switch(mobid)
	{
		case MOBID_EMPERIUM:
			{
				struct guild_castle *gc = guild_mapindex2gc(sd->mapindex);
				if( gc && !sd->status.guild_id && (agit_flag || agit2_flag) )
				{
					type = ACH_EMPERIUM;
					strcpy(target2,"emperium");
				}
			}
			break;
		case MOBID_BARRICADE1:
		case MOBID_BARRICADE2:
			type = ACH_BARRICADE;
			strcpy(target2,"barricade");
			break;
		case MOBID_GUARDIAN_STONE1:
		case MOBID_GUARDIAN_STONE2:
			type = ACH_RUNESTONE;
			strcpy(target2,"runestone");
			break;
		default:
			break;
	}

	StringBuf_Init(&buff);
	StringBuf_AppendStr(&buff, "SELECT `a`.`id` FROM `achievement_db` AS `a` WHERE `a`.`status`='1' AND ((SELECT COUNT(*) FROM `achievement_data` WHERE");
	StringBuf_Printf(&buff, "  `account_id`='%d' AND `achievement_id`=`a`.`id` AND `status`!='0') <= '0') AND (SELECT COUNT(*) FROM `achievement_req` WHERE `achievement_id`=`a`.`id` AND `status`='1' AND (`type`='12' AND `target`='%d'", sd->status.account_id, mobid);

	if( type != ACH_NONE )
		StringBuf_Printf(&buff, " OR `type`='%d' AND `target`='%s'", type, target2);

	is_mvp = achievement_is_mvp(mobid);

	if( is_mvp )
		StringBuf_Printf(&buff, " OR `type`='16' AND `target`='mvp'");

	StringBuf_Printf(&buff, ")) > 0");
	
	if( SQL_ERROR == SqlStmt_Prepare(stmt, StringBuf_Value(&buff))
		|| SQL_ERROR == SqlStmt_Execute(stmt)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 0,  SQLDT_INT, &achievement_id, 0, NULL, NULL)
	) {
		SqlStmt_ShowDebug(stmt);
		SqlStmt_Free(stmt);
		return 0;
	}

	while( SQL_SUCCESS == SqlStmt_NextRow(stmt) )
	{
		int status, check_map, check_job, get_value_1, get_value_2, check_progress, type_1, type_2 = 0, type_3 = 0;
		status = achievement_data_status(achievement_id, sd->status.account_id);
		
		if( status > 0 )
			continue;

		check_map = achievement_secundary(achievement_id, map[sd->bl.m].name, ACH_SEC_MAP);
		check_job = achievement_secundary(achievement_id, (const char*)job, ACH_SEC_JOB);

		type_1 = achievement_check_target(achievement_id, 12, (const char*)target);
		
		if( type != ACH_NONE )
			type_2 = achievement_check_target(achievement_id, type, target2);

		if( is_mvp )
			type_3 = achievement_check_target(achievement_id, 16, "mvp");

		if( check_map <= 0 || check_job <= 0 || (!type_1 && !type_2 && !type_3) )
			continue;

		if( type_1 ) {
			get_value_1 = achievement_target_value(achievement_id, 12, (const char*)target);
			get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, 12, (const char*)target);

			if( get_value_2 < get_value_1 )
				achievement_update_progress(achievement_id, sd->status.account_id, 12, (const char*)target, 1, ACH_INCREMENT);
		}

		if( type_2 ) {
			get_value_1 = achievement_target_value(achievement_id, type, (const char*)target2);
			get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, type, (const char*)target2);

			if( get_value_2 < get_value_1 )
				achievement_update_progress(achievement_id, sd->status.account_id, type, (const char*)target2, 1, ACH_INCREMENT);
		}

		if( type_3 ) {
			get_value_1 = achievement_target_value(achievement_id, 16, "mvp");
			get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, 16, "mvp");

			if( get_value_2 < get_value_1 )
				achievement_update_progress(achievement_id, sd->status.account_id, 16, "mvp", 1, ACH_INCREMENT);
		}
		
		if( status < 0 ) {
			achievement_update_data(achievement_id, sd->status.account_id, ACH_INPROGRESS);
			achievement_set_countdown(achievement_id, sd->status.account_id);
		}

		check_progress = achievement_check_progress(achievement_id, sd->status.account_id);
		if( check_progress )
			achievement_completed(sd,achievement_id);
	}
	StringBuf_Destroy(&buff);
	SqlStmt_FreeResult(stmt);
	return 1;
}

int achievement_is_mvp(int mobid) {
	short mvp_list[72] = {1059, 1647, 1511, 2362, 1645, 1650, 1785, 1039, 2320, 2317, 1873, 1086, 1871, 2068, 2319, 1251, 2188, 2189, 2187, 2190, 2234, 2229, 2232, 1719, 1046, 2131, 1112, 1389, 1115, 1652, 1952, 1157, 1150, 1159, 2253, 1312, 2251, 1885, 2255, 1252, 1734, 2202, 1779, 1980, 1630, 1688, 2156, 1946, 1147, 1708, 2233, 2231, 1648, 1917, 1956, 1087, 2228, 1768, 2194, 2230, 2249, 1623, 1492, 1272, 1373, 1190, 1418, 2022, 1649, 1583, 1751, 2106 };
	int i;

	ARR_FIND(0, ARRAYLENGTH(mvp_list), i, mvp_list[i] == mobid);
	return (i < ARRAYLENGTH(mvp_list)) ? 1 : 0; 
}

int achievement_map(struct map_session_data *sd) {
	SqlStmt* stmt = SqlStmt_Malloc(mmysql_handle);
	int achievement_id;
	char job[50];

	nullpo_ret(sd);

	if( sd == NULL )
		return 0;

	// Convert job int to char
	itoa(sd->status.class_, job, 10);

	if( SQL_ERROR == SqlStmt_Prepare(stmt, "SELECT `a`.`id` FROM `achievement_db` AS `a` WHERE `a`.`status`='1' AND ((SELECT COUNT(*) FROM `achievement_data` WHERE `account_id`='%d' AND `achievement_id`=`a`.`id` AND `status`!='0') <= '0') AND (SELECT COUNT(*) FROM `achievement_req` WHERE `achievement_id`=`a`.`id` AND `status`='1' AND (`type`='11' AND target='%s')) > 0", sd->status.account_id, map[sd->bl.m].name)
		|| SQL_ERROR == SqlStmt_Execute(stmt)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 0,  SQLDT_INT, &achievement_id, 0, NULL, NULL)
	) {
		SqlStmt_ShowDebug(stmt);
		SqlStmt_Free(stmt);
		return 0;
	}

	while( SQL_SUCCESS == SqlStmt_NextRow(stmt) )
	{
		int status, check_map, check_job, get_value_1, get_value_2, check_progress;
		status = achievement_data_status(achievement_id, sd->status.account_id);

		if( status > 0 )
			continue;

		check_map = achievement_secundary(achievement_id, map[sd->bl.m].name, ACH_SEC_MAP);
		check_job = achievement_secundary(achievement_id, (const char*)job, ACH_SEC_JOB);

		if( check_map <= 0 || check_job <= 0)
			continue;

		get_value_1 = achievement_target_value(achievement_id, 11, map[sd->bl.m].name);
		get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, 11, map[sd->bl.m].name);

		if( get_value_2 < get_value_1 )
			achievement_update_progress(achievement_id, sd->status.account_id, 11, map[sd->bl.m].name, 1, ACH_INCREMENT);

		if( status < 0 ) {
			achievement_update_data(achievement_id, sd->status.account_id, ACH_INPROGRESS);
			achievement_set_countdown(achievement_id, sd->status.account_id);
		}

		check_progress = achievement_check_progress(achievement_id, sd->status.account_id);
		if( check_progress )
			achievement_completed(sd,achievement_id);
	}
	SqlStmt_FreeResult(stmt);
	return 1;
}

int achievement_refinement(struct map_session_data *sd, int item_id, int amount) {
	return 1;
}

int achievement_timer(int tid, unsigned int tick, int id, intptr_t data)
{
	SqlStmt* stmt = SqlStmt_Malloc(mmysql_handle);
	time_t timer;
	struct tm *t;
	struct map_session_data *sd = map_id2sd(id);
	int achievement_id;
	char hour[50], job[50];
	nullpo_ret(sd);

	if( !sd )
		return 0;

	// Prevent event autotrade
	if( sd->state.autotrade )
	{
		delete_timer(sd->achievement.timer, achievement_timer);
		return 0;
	}

	// Get Timer
	time(&timer);
	t=localtime(&timer);
	sprintf(hour, "%02d:%02d", t->tm_hour, t->tm_min);

	// Convert job int to char
	itoa(sd->status.class_, job, 10);

	if( SQL_ERROR == SqlStmt_Prepare(stmt, "SELECT `a`.`id` FROM `achievement_db` AS `a` WHERE `a`.`status`='1' AND ((SELECT COUNT(*) FROM `achievement_data` WHERE `account_id`='%d' AND `achievement_id`=`a`.`id` AND `status`!='0') <= '0') AND (SELECT COUNT(*) FROM `achievement_req` WHERE `achievement_id`=`a`.`id` AND `status`='1' AND (`type`='10' OR `type`='17' AND target='%s')) > 0", sd->status.account_id, hour)
		|| SQL_ERROR == SqlStmt_Execute(stmt)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 0,  SQLDT_INT, &achievement_id, 0, NULL, NULL)
	) {
		SqlStmt_ShowDebug(stmt);
		SqlStmt_Free(stmt);
		return 0;
	}

	while( SQL_SUCCESS == SqlStmt_NextRow(stmt) )
	{
		int status, check_map, check_job, get_value_1, get_value_2, check_progress, type_1, type_2;
		status = achievement_data_status(achievement_id, sd->status.account_id);

		if( status > 0 )
			continue;

		check_map = achievement_secundary(achievement_id, map[sd->bl.m].name, ACH_SEC_MAP);
		check_job = achievement_secundary(achievement_id, (const char*)job, ACH_SEC_JOB);

		type_1 = achievement_check_target(achievement_id, 10, "timer");
		type_2 = achievement_check_target(achievement_id, 17, (const char *)hour);
		
		if( check_map <= 0 || check_job <= 0 || (!type_1 && !type_2))
			continue;

		if( type_1 ) {
			get_value_1 = achievement_target_value(achievement_id, 10, "timer");
			get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, 10, "timer");

			if( get_value_2 < get_value_1 )
				achievement_update_progress(achievement_id, sd->status.account_id, 10, "timer", 1, ACH_INCREMENT);
		}

		if( type_2 ) {
			get_value_1 = achievement_target_value(achievement_id, 17, (const char*)hour);
			get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, 17, (const char*)hour);

			if( get_value_2 < get_value_1 )
				achievement_update_progress(achievement_id, sd->status.account_id, 17, (const char*)hour, 1, ACH_INCREMENT);
		}

		if( status < 0 ) {
			achievement_update_data(achievement_id, sd->status.account_id, ACH_INPROGRESS);
			achievement_set_countdown(achievement_id, sd->status.account_id);
		}

		check_progress = achievement_check_progress(achievement_id, sd->status.account_id);
		if( check_progress )
			achievement_completed(sd,achievement_id);
	}
	SqlStmt_FreeResult(stmt);
	sd->achievement.timer = add_timer(gettick()+60000, achievement_timer, sd->bl.id, 0);
	return 0;
}

int achievement_scripts(struct map_session_data *sd, int amount, enum ach_script_type type)
{
	SqlStmt* stmt = SqlStmt_Malloc(mmysql_handle);
	int achievement_id;
	char job[50], target[50];

	nullpo_ret(sd);

	if( sd == NULL )
		return 0;
	
	// Copy Target
	switch(type) {
		case ACH_S_BATTLEGROUND:
			strcpy(target, "battleground");
			break;
		case ACH_S_GUARDIAN_STONE:
			strcpy(target, "runestone");
			break;
		case ACH_S_BARRICADE:
			strcpy(target, "barricade");
			break;
	}

	// Convert job int to char
	itoa(sd->status.class_, job, 10);

	if( SQL_ERROR == SqlStmt_Prepare(stmt, "SELECT `a`.`id` FROM `achievement_db` AS `a` WHERE `a`.`status`='1' AND ((SELECT COUNT(*) FROM `achievement_data` WHERE `account_id`='%d' AND `achievement_id`=`a`.`id` AND `status`!='0') <= '0') AND (SELECT COUNT(*) FROM `achievement_req` WHERE `achievement_id`=`a`.`id` AND `status`='1' AND (`type`='%d' AND target='%s')) > 0", sd->status.account_id, type, target)
		|| SQL_ERROR == SqlStmt_Execute(stmt)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 0,  SQLDT_INT, &achievement_id, 0, NULL, NULL)
	) {
		SqlStmt_ShowDebug(stmt);
		SqlStmt_Free(stmt);
		return 0;
	}

	while( SQL_SUCCESS == SqlStmt_NextRow(stmt) )
	{
		int status, check_map, check_job, get_value_1, get_value_2, check_progress;
		status = achievement_data_status(achievement_id, sd->status.account_id);

		if( status > 0 )
			continue;

		check_map = achievement_secundary(achievement_id, map[sd->bl.m].name, ACH_SEC_MAP);
		check_job = achievement_secundary(achievement_id, (const char*)job, ACH_SEC_JOB);

		if( check_map <= 0 || check_job <= 0 )
			continue;

		get_value_1 = achievement_target_value(achievement_id, type, (const char*)target);
		get_value_2 = achievement_progress_value(achievement_id, sd->status.account_id, type, (const char*)target);

		if( get_value_2 < get_value_1 )
			achievement_update_progress(achievement_id, sd->status.account_id, type, (const char*)target, amount, ACH_INCREMENT);

		if( status < 0 ) {
			achievement_update_data(achievement_id, sd->status.account_id, ACH_INPROGRESS);
			achievement_set_countdown(achievement_id, sd->status.account_id);
		}

		check_progress = achievement_check_progress(achievement_id, sd->status.account_id);
		if( check_progress )
			achievement_completed(sd,achievement_id);
	}
	SqlStmt_FreeResult(stmt);
	return 1;
}

// Countdown Achievement
//
int achievement_countdown(int tid, unsigned int tick, int id, intptr_t data)
{
	SqlStmt* stmt = SqlStmt_Malloc(mmysql_handle);
	struct map_session_data *sd = NULL;
	char name[50], output[200];
	int achievement_id, account_id;

	if( SQL_ERROR == Sql_Query(mmysql_handle, "UPDATE `achievement_progress` SET `value`=`value`+'1' WHERE `type`='51' AND target='countdown'") ) {
		Sql_ShowDebug(mmysql_handle);
		Sql_FreeResult(mmysql_handle);
		return false;
	}
	Sql_FreeResult(mmysql_handle);

	if( SQL_ERROR == SqlStmt_Prepare(stmt, "SELECT `a`.`achievement_id`, `a`.`account_id`, `d`.`name` FROM `achievement_progress` AS `a`, `achievement_db` AS `d` WHERE `a`.`type`='51' AND `a`.`target`='countdown' AND `a`.`achievement_id`=`d`.`id` AND `d`.`status`='1' AND ((SELECT COUNT(*) FROM `achievement_req` WHERE `achievement_id`=`a`.`achievement_id` AND `target`=`a`.`target` AND `a`.`value`>=`value` AND `status`='1') > '0')")
		|| SQL_ERROR == SqlStmt_Execute(stmt)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 0,  SQLDT_INT, &achievement_id, 0, NULL, NULL)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 1,  SQLDT_INT, &account_id, 0, NULL, NULL)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 2,  SQLDT_STRING, &name, sizeof(name), NULL, NULL)
	) {
		SqlStmt_ShowDebug(stmt);
		SqlStmt_Free(stmt);
		return 0;
	}

	if( SqlStmt_NumRows(stmt) <= 0 )
	{
		SqlStmt_Free(stmt);
		return 0;
	}

	while( SQL_SUCCESS == SqlStmt_NextRow(stmt) )
	{
		achievement_clear(achievement_id, account_id);
		achievement_update_data(achievement_id, account_id, ACH_FAIL);

		if( account_id && (sd = map_id2sd(account_id)) != NULL ) {
			sprintf(output, "O tempo para terminar a Conquista '%s' expirou!", name);
			achievement_message(sd->fd, ACH_M_FAIL, output);
		}
	}
	return 0;
}

// Set CountDown Achievement
//
int achievement_set_countdown(int achievement_id, int account_id) {
	char* data;
	size_t len;
	struct map_session_data *sd = NULL;
	int check_target, target_value;
	int timer = 0, sec = 0, min = 0, hour = 0, days = 0;
	char output[200], name[50];

	if( !achievement_id || !account_id )
		return 0;

	if( SQL_ERROR == Sql_Query(mmysql_handle, "SELECT `name` FROM `achievement_db` WHERE `id`='%d' LIMIT 1", achievement_id) ) {
		Sql_ShowDebug(mmysql_handle);
		return false;
	}

	if( SQL_SUCCESS != Sql_NextRow(mmysql_handle) )
	{
		Sql_ShowDebug(mmysql_handle);
		Sql_FreeResult(mmysql_handle);
		return 0;
	}

	Sql_GetData(mmysql_handle, 0, &data, &len); safestrncpy(name, data, sizeof(name));
	Sql_FreeResult(mmysql_handle);

	check_target = achievement_check_target(achievement_id, 51, "countdown");
	target_value = achievement_target_value(achievement_id, 51, "countdown");

	if( !check_target || !target_value )
		return 1;

	if( SQL_ERROR == Sql_Query(mmysql_handle, "REPLACE INTO `achievement_progress` (`achievement_id`, `account_id`, `type`, `target`, `value`) VALUES (%d, %d, 51, 'countdown', 0)", achievement_id, account_id) ) {
		Sql_ShowDebug(mmysql_handle);
		Sql_FreeResult(mmysql_handle);
		return 0;
	}
	Sql_FreeResult(mmysql_handle);

	if( (sd = map_id2sd(account_id)) != NULL )
	{
		timer = target_value;
		if( timer < 60 )
			sprintf(output, "Voc� tem %d segundo(s) para completar a Conquista '%s'.", timer, name);
		else {
			min = timer/60;
			sec = timer - (min*60);

			if( min < 60 && sec > 0 )
				sprintf(output, "Voc� tem %d minuto(s) e %d segundo(s) para completar a Conquista '%s'.", min, sec, name);
			else if( min < 60 )
				sprintf(output, "Voc� tem %d minuto(s) para completar a Conquista '%s'.", min, name);
			else {
				hour = min/60;
				min = min - (hour*60);
				if( hour < 24 && min > 0 && sec > 0 )
					sprintf(output, "Voc� tem %d hora(s) %d minuto(s) e %d segundo(s) para completar a Conquista '%s'.", hour, min, sec, name);
				else if( hour < 24 && min > 0 )
					sprintf(output, "Voc� tem %d hora(s) e %d minuto(s) para completar a Conquista '%s'.", hour, min, name);
				else if( hour < 24 && sec > 0 )
					sprintf(output, "Voc� tem %d hora(s) e %d segundo(s) para completar a Conquista '%s'.", hour, sec, name);
				else {
					days = hour/24;
					hour = hour - (days*24);

					if( days && hour > 0 && min > 0 && sec > 0 )
						sprintf(output, "Voc� tem %d dia(s) %d hora(s) %d minuto(s) e %d segundo(s) para completar a Conquista '%s'.", days, hour, min, sec, name);
					else if( days && hour > 0 && min > 0 )
						sprintf(output, "Voc� tem %d dia(s) %d hora(s) %d minuto(s) para completar a Conquista '%s'.", days, hour, min, name);
					else if( days && hour > 0 && sec > 0 )
						sprintf(output, "Voc� tem %d dia(s) %d hora(s) %d segundo(s) para completar a Conquista '%s'.", days, hour, sec, name);
					else if( days && min > 0 && sec > 0 )
						sprintf(output, "Voc� tem %d dia(s) %d minuto(s) e %d segundo(s) para completar a Conquista '%s'.", days, min, sec, name);
					else if( days && hour > 0 )
						sprintf(output, "Voc� tem %d dia(s) e %d hora(s) para completar a Conquista '%s'.", days, hour, name);
					else if( days && min > 0 )
						sprintf(output, "Voc� tem %d dia(s) e %d minuto(s) para completar a Conquista '%s'.", days, min, name);
					else if( days && sec > 0 )
						sprintf(output, "Voc� tem %d dia(s) e %d segundo(s) para completar a Conquista '%s'.", days, sec, name);
					else
						sprintf(output, "Voc� tem %d dia(s) para completar a Conquista '%s'.", days, name);
				}
			}
		}
		achievement_message(sd->fd, ACH_M_INIT, output);
	}
	return 1;
}

// Get Status Achievement from Player
//
int achievement_data_status(int achievement_id, int account_id)
{
	SqlStmt* stmt = SqlStmt_Malloc(mmysql_handle);
	int status = 0;
	if( SQL_ERROR == SqlStmt_Prepare(stmt, "SELECT `status` FROM `achievement_data` WHERE `achievement_id`='%d' AND `account_id`='%d' LIMIT 1", achievement_id, account_id)
		|| SQL_ERROR == SqlStmt_Execute(stmt)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 0,  SQLDT_INT, &status, 0, NULL, NULL)
	) {
		SqlStmt_ShowDebug(stmt);
		SqlStmt_Free(stmt);
		return -2;
	}

	if( SqlStmt_NumRows(stmt) <= 0 )
	{
		SqlStmt_FreeResult(stmt);
		return -1;
	}

	if( SQL_SUCCESS != SqlStmt_NextRow(stmt) )
	{
		SqlStmt_ShowDebug(stmt);
		SqlStmt_FreeResult(stmt);
		return 0;
	}

	SqlStmt_FreeResult(stmt);
	return status;
}

// Check Secundary Targets
//
int achievement_secundary(int achievement_id, const char *target, enum ach_secundary type)
{
	char* data;
	int count;

	if( SQL_ERROR == Sql_Query(mmysql_handle, "SELECT COUNT(*) FROM `achievement_req` WHERE `achievement_id`='%d' AND `type`='%d'", achievement_id, type) ) {
		Sql_ShowDebug(mmysql_handle);
		return false;
	}

	if( SQL_SUCCESS != Sql_NextRow(mmysql_handle) )
	{
		Sql_ShowDebug(mmysql_handle);
		Sql_FreeResult(mmysql_handle);
		return 0;
	}

	Sql_GetData(mmysql_handle, 0, &data, NULL); count = atoi(data);
	Sql_FreeResult(mmysql_handle);

	if( count <= 0 )
		return 1;

	if( SQL_ERROR == Sql_Query(mmysql_handle, "SELECT COUNT(*) FROM `achievement_req` WHERE `achievement_id`='%d' AND `type`='%d' AND `target`='%s'", achievement_id, type, target) ) {
		Sql_ShowDebug(mmysql_handle);
		Sql_FreeResult(mmysql_handle);
		return false;
	}

	Sql_GetData(mmysql_handle, 0, &data, NULL); count = atoi(data);
	Sql_FreeResult(mmysql_handle);

	if( count <= 0 )
		return 0;

	return 1;
}

// Get Target value from Achievement Requeriment DB
//
int achievement_target_value(int achievement_id, int type, const char *target) {
	SqlStmt* stmt = SqlStmt_Malloc(mmysql_handle);
	int value = 0;
	if( SQL_ERROR == SqlStmt_Prepare(stmt, "SELECT `value` FROM `achievement_req` WHERE `achievement_id`='%d' AND `type`='%d' AND `target`='%s' LIMIT 1", achievement_id, type, target)
		|| SQL_ERROR == SqlStmt_Execute(stmt)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 0,  SQLDT_INT, &value, 0, NULL, NULL)
	) {
		SqlStmt_ShowDebug(stmt);
		SqlStmt_Free(stmt);
		return 0;
	}

	if( SqlStmt_NumRows(stmt) <= 0 )
	{
		SqlStmt_FreeResult(stmt);
		return 0;
	}

	if( SQL_SUCCESS != SqlStmt_NextRow(stmt) )
	{
		SqlStmt_ShowDebug(stmt);
		SqlStmt_FreeResult(stmt);
		return 0;
	}

	SqlStmt_FreeResult(stmt);
	return value;
}

// Get Progress value from Player
//
int achievement_progress_value(int achievement_id, int account_id, int type, const char *target) {
	SqlStmt* stmt = SqlStmt_Malloc(mmysql_handle);
	int value = 0;
	if( SQL_ERROR == SqlStmt_Prepare(stmt, "SELECT `value` FROM `achievement_progress` WHERE `achievement_id`='%d' AND `account_id`='%d' AND `type`='%d' AND `target`='%s' LIMIT 1", achievement_id, account_id, type, target)
		|| SQL_ERROR == SqlStmt_Execute(stmt)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 0,  SQLDT_INT, &value, 0, NULL, NULL)
	) {
		SqlStmt_ShowDebug(stmt);
		SqlStmt_Free(stmt);
		return 0;
	}

	if( SqlStmt_NumRows(stmt) <= 0 )
	{
		SqlStmt_FreeResult(stmt);
		return 0;
	}

	if( SQL_SUCCESS != SqlStmt_NextRow(stmt) )
	{
		SqlStmt_ShowDebug(stmt);
		SqlStmt_FreeResult(stmt);
		return 0;
	}

	SqlStmt_FreeResult(stmt);
	return value;
}

// Update Achievement Data from Player
//
int achievement_update_data(int achievement_id, int account_id,  enum ach_status status)
{
	/*char* data;
	int count;

	if( SQL_ERROR == Sql_Query(mmysql_handle, "SELECT COUNT(*) FROM `achievement_data` WHERE `achievement_id`='%d' AND `account_id`='%d'", achievement_id, account_id) ) {
		Sql_ShowDebug(mmysql_handle);
		Sql_FreeResult(mmysql_handle);
		return false;
	}

	if( SQL_SUCCESS != Sql_NextRow(mmysql_handle) )
	{
		Sql_ShowDebug(mmysql_handle);
		Sql_FreeResult(mmysql_handle);
		return 0;
	}

	Sql_GetData(mmysql_handle, 0, &data, NULL); count = atoi(data);
	Sql_FreeResult(mmysql_handle);
	*/
	if( status == ACH_FAIL )
	{
		if( SQL_ERROR == Sql_Query(mmysql_handle, "DELETE FROM `achievement_data` WHERE `account_id`='%d' AND `achievement_id`='%d'", account_id, achievement_id) ) {
			Sql_ShowDebug(mmysql_handle);
			Sql_FreeResult(mmysql_handle);
			return false;
		}
	} 
	else {
		if( SQL_ERROR == Sql_Query(mmysql_handle, "INSERT INTO `achievement_data` (`account_id`, `achievement_id`, `status`, `date_time`) VALUES (%d, %d, %d, NOW()) ON DUPLICATE KEY UPDATE `status`='%d'", account_id, achievement_id, status, status) ) {
			Sql_ShowDebug(mmysql_handle);
			Sql_FreeResult(mmysql_handle);
			return false;
		}
	}
	/*else {
		if( SQL_ERROR == Sql_Query(mmysql_handle, "UPDATE `achievement_data` SET `status`='%d', `date_time`=NOW() WHERE `account_id`='%d' AND `achievement_id`='%d'", status, account_id, achievement_id) ) {
			Sql_ShowDebug(mmysql_handle);
			Sql_FreeResult(mmysql_handle);
			return false;
		}
	}*/
	return true;
}

// Update Achievement Progress from Player
//
int achievement_update_progress(int achievement_id, int account_id, int type, const char *target, int value, int flag)
{
	/*char* data;
	int count;
	
	if( SQL_ERROR == Sql_Query(mmysql_handle, "SELECT COUNT(*) FROM `achievement_progress` WHERE `account_id`='%d' AND `achievement_id`='%d' AND `type`='%d' AND `target`='%s'", account_id, achievement_id, type, target) ) {
		Sql_ShowDebug(mmysql_handle);
		Sql_FreeResult(mmysql_handle);
		return false;
	}

	if( SQL_SUCCESS != Sql_NextRow(mmysql_handle) )
	{
		Sql_ShowDebug(mmysql_handle);
		Sql_FreeResult(mmysql_handle);
		return 0;
	}

	Sql_GetData(mmysql_handle, 0, &data, NULL); count = atoi(data);
	Sql_FreeResult(mmysql_handle);
	
	if( count <= 0 ) {
		if( SQL_ERROR == Sql_Query(mmysql_handle, "INSERT INTO `achievement_progress` (`account_id`, `achievement_id`, `type`, `target`, `value`) VALUES (%d, %d, %d, '%s', %d)", account_id, achievement_id, type, target, value) ) {
			Sql_ShowDebug(mmysql_handle);
			Sql_FreeResult(mmysql_handle);
			return false;
		}
	}
	*/
	if( flag == ACH_INCREMENT ) {
		if( SQL_ERROR == Sql_Query(mmysql_handle, "INSERT INTO `achievement_progress` (`account_id`, `achievement_id`, `type`, `target`, `value`) VALUES (%d, %d, %d, '%s', %d) ON DUPLICATE KEY UPDATE `value`=`value`+'%d'", account_id, achievement_id, type, target, value, value) ) {
		//if( SQL_ERROR == Sql_Query(mmysql_handle, "UPDATE `achievement_progress` SET `value`=`value`+'%d' WHERE `account_id`='%d' AND `achievement_id`='%d' AND `type`='%d' AND `target`='%s'", value, account_id, achievement_id, type, target) ) {
			Sql_ShowDebug(mmysql_handle);
			Sql_FreeResult(mmysql_handle);
			return false;
		}
	}
	else {
		if( SQL_ERROR == Sql_Query(mmysql_handle, "INSERT INTO `achievement_progress` (`account_id`, `achievement_id`, `type`, `target`, `value`) VALUES (%d, %d, %d, '%s', %d) ON DUPLICATE KEY UPDATE `value`='%d'", account_id, achievement_id, type, target, value, value) ) {
		//if( SQL_ERROR == Sql_Query(mmysql_handle, "UPDATE `achievement_progress` SET `value`='%d' WHERE `account_id`='%d' AND `achievement_id`='%d' AND `type`='%d' AND `target`='%s'", value, account_id, achievement_id, type, target) ) {
			Sql_ShowDebug(mmysql_handle);
			Sql_FreeResult(mmysql_handle);
			return false;
		}
	}
	return true;
}

// Check all Progress from Achievement & Player
//
int achievement_check_progress(int achievement_id, int account_id)
{
	SqlStmt* stmt = SqlStmt_Malloc(mmysql_handle);
	int type, value;
	char target[50];

	if( SQL_ERROR == SqlStmt_Prepare(stmt, "SELECT `type`, `target`, `value` FROM `achievement_req`  WHERE `achievement_id`='%d' AND `status`='1' AND (`type`!='14' AND `type`!='15' AND `type`!='16' AND `type`!='22' AND `type`!='24' AND `type`!='51')", achievement_id)
		|| SQL_ERROR == SqlStmt_Execute(stmt)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 0, SQLDT_INT, &type, 0, NULL, NULL) 
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 1, SQLDT_STRING, &target, sizeof(target), NULL, NULL) 
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 2, SQLDT_INT, &value, 0, NULL, NULL)
	) {
		SqlStmt_ShowDebug(stmt);
		SqlStmt_Free(stmt);
		return 0;
	}

	while( SQL_SUCCESS == SqlStmt_NextRow(stmt) )
	{
		int progress = achievement_progress_value(achievement_id,account_id,type,(const char*)target);
		if( progress <= 0 || progress < value )
			return false;
	}
	SqlStmt_FreeResult(stmt);
	return true;
}

// Check Target Exist
//
int achievement_check_target(int achievement_id, int type, const char *target) {
	char* data;
	int count;

	if( SQL_ERROR == Sql_Query(mmysql_handle, "SELECT COUNT(*) FROM `achievement_req` WHERE `achievement_id`='%d' AND `type`='%d' AND `target`='%s'", achievement_id, type, target) ) {
		Sql_ShowDebug(mmysql_handle);
		Sql_FreeResult(mmysql_handle);
		return false;
	}

	if( SQL_SUCCESS != Sql_NextRow(mmysql_handle) )
	{
		Sql_ShowDebug(mmysql_handle);
		Sql_FreeResult(mmysql_handle);
		return 0;
	}

	Sql_GetData(mmysql_handle, 0, &data, NULL); count = atoi(data);
	Sql_FreeResult(mmysql_handle);
	return count ? 1 : 0;
}

// Complete Achievement
//
int achievement_completed(struct map_session_data *sd, int achievement_id) {
	SqlStmt* stmt = SqlStmt_Malloc(mmysql_handle);
	char* data;
	size_t len;
	char name[50], cutin[50], output[200], target[50];
	int i, achievement_id2;

	// Get Data DB
	if( SQL_ERROR == Sql_Query(mmysql_handle, "SELECT `name`, `cutin` FROM `achievement_db` WHERE `id`='%d' AND `status`='1' LIMIT 1", achievement_id) )
	{
		Sql_ShowDebug(mmysql_handle);
		Sql_FreeResult(mmysql_handle);
		return false;
	}

	if( SQL_SUCCESS != Sql_NextRow(mmysql_handle) )
	{
		Sql_ShowDebug(mmysql_handle);
		Sql_FreeResult(mmysql_handle);
		return 0;
	}

	Sql_GetData(mmysql_handle, 0, &data, &len); safestrncpy(name, data, sizeof(name));
	Sql_GetData(mmysql_handle, 1, &data, &len); safestrncpy(cutin, data, sizeof(cutin));
	Sql_FreeResult(mmysql_handle);

	// Set Cutins in Queue
	if( sd->achievement.cutin_count < MAX_ACH_QUEUE_CUTIN ) {
		for( i=0; i < MAX_ACH_QUEUE_CUTIN; i++ )
		{
			if( strlen(sd->achievement.cutin[i]) <= 0 )
			{
				sd->achievement.cutin_count++;
				safestrncpy(sd->achievement.cutin[i], cutin, sizeof(sd->achievement.cutin[i]));

				if( sd->achievement.cutin_timer <= 0 )
					sd->achievement.cutin_timer = add_timer(gettick()+1000, achievement_cutin, sd->bl.id, 0);
				break;
			}
		}
	}

	// Display Congratulations
	sprintf(output, "Parab�ns!! Voc� completou a Conquista '%s'.", name);
	achievement_message(sd->fd, ACH_M_SUCCESS, output);

	// Clear Progress
	achievement_clear(achievement_id, sd->status.account_id);

	// Get Rewards
	achievement_reward(sd, achievement_id);

	// Update Achievement Status
	achievement_update_data(achievement_id, sd->status.account_id, ACH_COMPLETE);

	// Update Ranking
	achievement_update_rank(sd->status.account_id);

	// Char Target
	sprintf(target, "%d", achievement_id);

	// Update Achievements Req Achievement
	if (SQL_ERROR == SqlStmt_Prepare(stmt, "SELECT `a`.`id` FROM `achievement_db` AS `a` WHERE `a`.`status`='1' AND ((SELECT COUNT(*) FROM `achievement_data` WHERE `account_id`='%d' AND `achievement_id`=`a`.`id` AND `status`!='0') <= '0') AND (SELECT COUNT(*) FROM `achievement_req` WHERE `achievement_id`=`a`.`id` AND `status`='1' AND `type`='52' AND `target`='%d') > 0", sd->status.account_id, achievement_id)
		|| SQL_ERROR == SqlStmt_Execute(stmt)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 0, SQLDT_INT, &achievement_id2, 0, NULL, NULL)
		) {
		SqlStmt_ShowDebug(stmt);
		SqlStmt_Free(stmt);
		return 0;
	}

	while (SQL_SUCCESS == SqlStmt_NextRow(stmt))
	{
		int status, get_value_1, get_value_2, check_progress;
		status = achievement_data_status(achievement_id2, sd->status.account_id);

		if (status > 0)
			continue;

		get_value_1 = achievement_target_value(achievement_id2, 52, target);
		get_value_2 = achievement_progress_value(achievement_id2, sd->status.account_id, 52, target);

		if (get_value_2 < get_value_1)
			achievement_update_progress(achievement_id2, sd->status.account_id, 52, target, 1, ACH_INCREMENT);

		if (status < 0) {
			achievement_update_data(achievement_id2, sd->status.account_id, ACH_INPROGRESS);
			achievement_set_countdown(achievement_id2, sd->status.account_id);
		}

		check_progress = achievement_check_progress(achievement_id2, sd->status.account_id);
		if (check_progress)
			achievement_completed(sd, achievement_id2);
	}
	SqlStmt_FreeResult(stmt);
	return true;
}

// Clear Progress
//
int achievement_clear(int achievement_id, int account_id)
{
	// Clear Progress
	if( SQL_ERROR == Sql_Query(mmysql_handle, "DELETE FROM `achievement_progress` WHERE `achievement_id`='%d' AND `account_id`='%d'", achievement_id, account_id) )
	{
		Sql_ShowDebug(mmysql_handle);
		Sql_FreeResult(mmysql_handle);
		return false;
	}

	return true;
}

int achievement_reward(struct map_session_data *sd, int achievement_id)
{
	SqlStmt* stmt = SqlStmt_Malloc(mmysql_handle);
	StringBuf buff;
	char output[200], object[32], desc[32];
	int value, rtype, chance, rate, rate_adjust, rate_min, rate_max;

	rate_adjust = achievement_config.reward_rate;
	rate_min = achievement_config.reward_rate_min;
	rate_max = achievement_config.reward_rate_max;

	StringBuf_Init(&buff);
	StringBuf_AppendStr(&buff, "SELECT `object`, `value`, `type`, `rate`, `desc` FROM `achievement_rewards` WHERE `achievement_id`=?");
	
	if( SQL_ERROR == SqlStmt_PrepareStr(stmt, StringBuf_Value(&buff))
		|| SQL_ERROR == SqlStmt_BindParam(stmt,  0, SQLDT_INT, &achievement_id, 0)
		|| SQL_ERROR == SqlStmt_Execute(stmt)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 0, SQLDT_STRING, &object, sizeof(object), NULL, NULL) 
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 1, SQLDT_INT, &value, 0, NULL, NULL)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 2, SQLDT_INT, &rtype, 0, NULL, NULL)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 3, SQLDT_INT, &rate, 0, NULL, NULL)
		|| SQL_ERROR == SqlStmt_BindColumn(stmt, 4, SQLDT_STRING, &desc, sizeof(desc), NULL, NULL)
	) {
		SqlStmt_ShowDebug(stmt);
		SqlStmt_Free(stmt);
		return 0;
	}

	if( SqlStmt_NumRows(stmt) <= 0 )
	{
		SqlStmt_FreeResult(stmt);
		return 1;
	}
	
	while( SQL_SUCCESS == SqlStmt_NextRow(stmt) )
	{
		// Check Rate Drop Reward
		chance = achievement_rate_adjust(rate, rate_adjust, rate_min, rate_max);
		if( chance <= rand()%10000+1 )
			continue;

		// Selecte Reward type
		switch(rtype)
		{
			// Item Reward
			case ACH_RW_ITEM:
				{
					struct item it;
					struct item_data *i_data;
					int nameid = atoi(object), amount = value, i, get_count, weight, flag = 0;

					if( !nameid || !amount )
						break;

					i_data = itemdb_exists(nameid);
					if( i_data == NULL )
						break;

					memset(&it,0,sizeof(it));
					it.nameid = nameid;
					it.identify=1;

					get_count = itemdb_isstackable(nameid)?amount:1;
					weight = itemdb_weight(nameid)*amount;

					if( (weight+sd->weight) < sd->max_weight )
					{
						for (i = 0; i < amount; i += get_count)
						{
							flag = 1;
							pc_additem(sd, &it, get_count, LOG_TYPE_NONE);
						}
					}
					else if( sd->storage.max_amount < MAX_STORAGE && itemdb_canstore(&it,pc_get_group_level(sd)) ) {
						for (i =0 ; i < amount; i += get_count)
						{
							if( storage_additem(sd, &sd->storage, &it, get_count) == 0 )
								flag = 2;
						}

						storage_storageclose(sd);
					}
					else if( itemdb_isdropable(&it,pc_get_group_level(sd)) )
					{
						for (i =0 ; i < amount; i += get_count)
						{
							if( map_addflooritem(&it,get_count,sd->bl.m,sd->bl.x,sd->bl.y,sd->status.char_id,0,0,0,0,0) )
								flag = 3;
						}
					}

					switch(flag)
					{
						case 1:
							sprintf(output, "Conquista: Voc� recebeu como recompensa %dx %s em seu invent�rio.", amount, i_data->jname);
							achievement_message(sd->fd, ACH_M_SUCCESS, output);
							break;
						case 2:
							sprintf(output, "Conquista: Voc� recebeu como recompensa %dx %s em seu Armaz�m Pessoal.", amount, i_data->jname);
							achievement_message(sd->fd, ACH_M_SUCCESS, output);
							break;
						case 3:
							sprintf(output, "Conquista: Voc� recebeu como recompensa %dx %s mais est� com o peso acima do permitido, o item ficar� caido por pouco tempo...", amount, i_data->jname);
							achievement_message(sd->fd, ACH_M_SUCCESS, output);
							break;
						default:
							break;
					}
				}
				break;
			// Zeny Reward
			case ACH_RW_ZENY:
				{
					int amount = value;

					if( amount > MAX_ZENY-sd->status.zeny )
						amount = MAX_ZENY - sd->status.zeny;

					if( amount > 0 ) {
						pc_getzeny(sd, amount, LOG_TYPE_NONE, NULL);
						sprintf(output, "Conquista: Voc� recebeu como recompensa %dx %s.", amount, desc);
						achievement_message(sd->fd, ACH_M_REWARD, output);
					}
				}
				break;
			// Cash Point
			case ACH_RW_CASH:
				{
					int amount = value;
					
					if( amount > MAX_ZENY-sd->cashPoints )
						amount = MAX_ZENY - sd->cashPoints; 

					if( amount > 0 ) {
						pc_setaccountreg(sd, add_str("#CASHPOINTS"), sd->cashPoints+amount);
						sprintf(output, "Conquista: Voc� recebeu como recompensa %dx %s.", amount, desc);
						achievement_message(sd->fd, ACH_M_REWARD, output);
					}
				}
				break;
			// Kafra Point
			case ACH_RW_KAFRA:
				{
					int amount = value;
				
					if( amount > MAX_ZENY-sd->kafraPoints )
						amount = MAX_ZENY - sd->kafraPoints; 

					if( amount > 0 ) {
						pc_setaccountreg(sd, add_str("#KAFRAPOINTS"), sd->kafraPoints+amount);
						sprintf(output, "Conquista: Voc� recebeu como recompensa %dx %s.", amount, desc);
						achievement_message(sd->fd, ACH_M_REWARD, output);
					}
				}
				break;
			// Base EXP Reward
			case ACH_RW_BEXP:
				{
					int amount = value;

					pc_gainexp(sd,NULL,amount,0,true);
					sprintf(output, "Conquista: Voc� recebeu como recompensa %dx de %s.", amount, desc);
					achievement_message(sd->fd, ACH_M_REWARD, output);
				}
				break;
			// Job EXP Reward
			case ACH_RW_JEXP:
				{
					int amount = value;
				
					pc_gainexp(sd,NULL,0,amount,true);
					sprintf(output, "Conquista: Voc� recebeu como recompensa %dx de %s.", amount, desc);
					achievement_message(sd->fd, ACH_M_REWARD, output);
				}
				break;
			// Base Level Reward
			case ACH_RW_BLVL:
				{
					int status_point = 0, level = value, i;

					if( sd->status.base_level >= pc_maxbaselv(sd) )
						break;

					if( (unsigned int)level > pc_maxbaselv(sd) || (unsigned int)level > (pc_maxbaselv(sd)-sd->status.base_level) )
						level = pc_maxbaselv(sd) - sd->status.base_level;

					for( i = 0; i < level; i++ )
						status_point += pc_gets_status_point(sd->status.base_level + i);
				
					sd->status.status_point += status_point;
					sd->status.base_level += (unsigned int)level;
					status_percent_heal(&sd->bl, 100, 100);
					clif_misceffect(&sd->bl, 0);

					sd->status.base_exp = 0;
					clif_updatestatus(sd, SP_STATUSPOINT);
					clif_updatestatus(sd, SP_BASELEVEL);
					clif_updatestatus(sd, SP_BASEEXP);
					clif_updatestatus(sd, SP_NEXTBASEEXP);
					status_calc_pc(sd, 0);
					if(sd->status.party_id)
						party_send_levelup(sd);

					sprintf(output, "Conquista: Voc� recebeu como recompensa (%d) %s.", level, desc);
					achievement_message(sd->fd, ACH_M_REWARD, output);
				}
				break;
			// Job Level Reward
			case ACH_RW_JLVL:
				{
					int skill_point = 0, level = value;

					if( sd->status.base_level >= pc_maxbaselv(sd) )
						break;

					if( (unsigned int)level > pc_maxjoblv(sd) || (unsigned int)level > (pc_maxjoblv(sd)-sd->status.job_level) )
						level = pc_maxjoblv(sd) - sd->status.job_level;

					sd->status.skill_point += (unsigned int)level;
					sd->status.job_level += (unsigned int)level;
					clif_misceffect(&sd->bl, 1);

					sd->status.job_exp = 0;
					clif_updatestatus(sd, SP_JOBLEVEL);
					clif_updatestatus(sd, SP_JOBEXP);
					clif_updatestatus(sd, SP_NEXTJOBEXP);
					clif_updatestatus(sd, SP_SKILLPOINT);
					status_calc_pc(sd, 0);

					sprintf(output, "Conquista: Voc� recebeu como recompensa (%d) %s.", level, desc);
					achievement_message(sd->fd, ACH_M_REWARD, output);
				}
				break;
			// Status
			case ACH_RW_STATUS:
				{
					int i = atoi(object), amount = value, new_value;
					short* status[6];

					if( i < 0 || i > MAX_STATUS_TYPE )
						break;

					status[0] = &sd->status.str;
					status[1] = &sd->status.agi;
					status[2] = &sd->status.vit;
					status[3] = &sd->status.int_;
					status[4] = &sd->status.dex;
					status[5] = &sd->status.luk;

					if( amount < 0 && *status[i] <= -amount )
						new_value = 1;
					else if( SHRT_MAX - *status[i] < amount )
						new_value = SHRT_MAX;
					else
						new_value = amount;

					if( new_value != *status[i] )
					{
						*status[i] += new_value;
						clif_updatestatus(sd, SP_STR + i);
						clif_updatestatus(sd, SP_USTR + i);
						status_calc_pc(sd, 0);
						sprintf(output, "Conquista: Voc� recebeu como recompensa +%d %s", new_value, desc);
						achievement_message(sd->fd, ACH_M_REWARD, output);
					}
				}
				break;
			// Unknown type!
			default:
				ShowDebug("achievement_reward: Type %d is unknown in Object %s from (Achievement_id: %d). (CID/AID: %d, %d)\n", rtype, object, achievement_id, sd->status.char_id, sd->status.account_id);
				break;
		}
	}
	StringBuf_Destroy(&buff);
	SqlStmt_FreeResult(stmt);
	return 1;
}

//Adjusts Rate Reward
unsigned int achievement_rate_adjust(int baserate, int rate_adjust, unsigned short rate_min, unsigned short rate_max)
{
	double rate = baserate;

	if (battle_config.logarithmic_drops && rate_adjust > 0 && baserate > 0) //Logarithmic drops equation by Ishizu-Chan
		//Equation: Droprate(x,y) = x * (5 - log(x)) ^ (ln(y) / ln(5))
		//x is the normal Droprate, y is the Modificator.
		rate = rate * pow((5.0 - log10(rate)), (log(rate_adjust/100.) / log(5.0))) + 0.5;
	else
		//Classical linear rate adjustment.
		rate = rate * rate_adjust/100;

	return (unsigned int)cap_value(rate,rate_min,rate_max);
}

int achievement_cutin(int tid, unsigned int tick, int id, intptr_t data)
{
	struct map_session_data *sd = map_id2sd(id);
	int i = 0;
	nullpo_ret(sd);

	if( !sd )
		return 0;

	if( sd->achievement.cutin_count <= 0 )
	{
		delete_timer(sd->achievement.cutin_timer, achievement_cutin);
		sd->achievement.cutin_timer = INVALID_TIMER;
		return 0;
	}

	for( i=0; i < MAX_ACH_QUEUE_CUTIN; i++ )
	{
		if( strlen(sd->achievement.cutin[i]) > 0 )
		{
			clif_cutin(sd, (const char*)sd->achievement.cutin[i], 4);
			memset(sd->achievement.cutin[i], '\0', sizeof(sd->achievement.cutin[i]));
			sd->achievement.cutin_count--;
			break;
		}
	}

	sd->achievement.cutin_timer = add_timer(gettick()+3000, achievement_cutin, sd->bl.id, 0);
	return 0;
}

// Achievement Message
void achievement_message(int fd, enum ach_message flag, const char *msg)
{
	unsigned short msg_len = (unsigned short)(strlen(msg) + 1);

	WFIFOHEAD(fd, msg_len + 12);
	WFIFOW(fd, 0) = 0x2C1;
	WFIFOW(fd, 2) = msg_len + 12;
	WFIFOL(fd, 4) = 0;
	WFIFOL(fd, 8) = RGB2BGR(achievement_color[flag]); //either color_table or channel_table
	safestrncpy(WFIFOCP(fd, 12), msg, msg_len);
	WFIFOSET(fd, msg_len + 12);
}

// Achievement Ranking
void achievement_update_rank(int account_id)
{
	SqlStmt* stmt = SqlStmt_Malloc(mmysql_handle);

	if (SQL_ERROR == Sql_Query(mmysql_handle, "INSERT INTO `achievement_ranking` (`account_id`, `score`, `lastupdate`) VALUES (%d, 1, NOW()) ON DUPLICATE KEY UPDATE `score`=`score`+'1', `lastupdate`=NOW()", account_id)) {
		Sql_ShowDebug(mmysql_handle);
	}
	Sql_FreeResult(mmysql_handle);
}

// NPC com Hyperlink
int achievement_run_link(struct map_session_data *sd)
{
	struct npc_data *nd = npc_name2id("AchievementLink");
	char buff[200];

	if( nd == NULL ) {
		ShowError("achievement_run_link: Link NPC was not created.\n");
		return 0;
	}

	snprintf(buff, sizeof(buff), "^0000FF[Painel de Conquistas]^000000");
	clif_scriptmes(sd, nd->bl.id, buff);
#if PACKETVER >= 20130807
	snprintf(buff, sizeof(buff), "<URL>Acessar meu Perfil de Conquistas<INFO>http://%s/client/?account_id=%d&pass=%s</INFO></URL>", achievement_config.panel_link, sd->status.account_id, achievement_config.panel_pass);
	clif_scriptmes(sd, nd->bl.id, buff);
#else
	snprintf(buff, sizeof(buff), "Para acessar o Painel das Conquistas visite no seu navegador:");
	clif_scriptmes(sd, nd->bl.id, buff);
	snprintf(buff, sizeof(buff), "^337ab7%s^000000", achievement_config.panel_link);
	clif_scriptmes(sd, nd->bl.id, buff);
#endif
	clif_scriptclose(sd, nd->bl.id);
	return 1;
}

int achievement_config_read(void)
{
	char line[1024], w1[1024], w2[1024];
	const char *cfgName;
	FILE *fp;

	// Read Script
	cfgName = "conf/battle/achievement.conf";

	// Default values
	achievement_config.reward_rate = 100;
	achievement_config.reward_rate_min = 1;
	achievement_config.reward_rate_max = 10000;
	snprintf(achievement_config.panel_link, sizeof(achievement_config.panel_link), "127.0.0.1/achievement");

	fp = fopen(cfgName,"r");
	if( fp == NULL )
	{
		ShowError("Achievement configuration file not found at: %s\n", cfgName);
		ShowError("Setting configuration from achievement default values\n");
		return 0;
	}

	while( fgets(line, sizeof(line), fp) )
	{
		char* ptr;

		if( line[0] == '/' && line[1] == '/' )
			continue;
		if( (ptr = strstr(line, "//")) != NULL )
			*ptr = '\n'; //Strip comments
		if( sscanf(line, "%[^:]: %[^\t\r\n]", w1, w2) < 2 )
			continue;

		//Strip trailing spaces
		ptr = w2 + strlen(w2);
		while (--ptr >= w2 && *ptr == ' ');
		ptr++;
		*ptr = '\0';
		
		if(strcmpi(w1,"reward_rate")==0)
			achievement_config.reward_rate = atoi(w2);
		else if(strcmpi(w1, "reward_rate_min")==0)
			achievement_config.reward_rate_min = atoi(w2);
		else if (strcmpi(w1, "reward_rate_max")==0)
			achievement_config.reward_rate_max = atoi(w2);
		else if (strcmpi(w1, "panel_link")==0)
			strncpy(achievement_config.panel_link, w2, sizeof(achievement_config.panel_link));
		else if (strcmpi(w1, "panel_pass")==0)
		{
			const char *tmpstr;
			char *md5str;
			tmpstr = w2;
			md5str = (char *)aMalloc((32 + 1)*sizeof(char));
			MD5_String(tmpstr, md5str);
			strncpy(achievement_config.panel_pass, md5str, sizeof(achievement_config.panel_pass));
		}
		else
			ShowWarning("Unknown setting '%s' in file %s\n", w1, cfgName);
	}

	ShowMessage(CL_WHITE"[Info]:"CL_RESET" "CL_GREEN"Achievement Configuration File"CL_RESET" successfully read.\n");
	fclose(fp);
	return 1;
}

void do_init_achievement(void) {
	add_timer_func_list(achievement_cutin, "achievement_cutin");
	add_timer_func_list(achievement_timer, "achievement_timer");
	add_timer_func_list(achievement_countdown, "achievement_countdown");
	add_timer_interval(gettick() + 1000, achievement_countdown, 0, 0, 1000);

	achievement_config_read();
	npc_achievement_create();
	ShowMessage(CL_WHITE"[Info]:"CL_RESET" "CL_WHITE"Achievement System "CL_GREEN"(version: 3.0)"CL_RESET" successfully initialized.\n");
	ShowMessage(CL_WHITE"[Info]:"CL_RESET" by (c) CreativeSD, support in "CL_GREEN"www.creativesd.com.br"CL_RESET"\n");
}

void do_final_achievement(void) {

}