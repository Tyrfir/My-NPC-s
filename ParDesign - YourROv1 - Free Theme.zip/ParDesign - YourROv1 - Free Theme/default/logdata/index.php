<?php if (!defined('FLUX_ROOT')) exit; ?>
<div id="eALogs">
<h2>eA Logs</h2>
<p>You may view the eAthena logs here.</p>
<p>Please select the log that you would like to view from the available menus.</p>
</div>