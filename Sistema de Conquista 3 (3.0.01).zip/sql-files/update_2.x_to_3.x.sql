﻿UPDATE `achievement_db` SET `id`=`id`+1 ORDER BY `id` DESC;
UPDATE `achievement_progress` SET `achievement_id`=`achievement_id`+1 ORDER BY `achievement_id` DESC;
UPDATE `achievement_req` SET `achievement_id`=`achievement_id`+1 ORDER BY `achievement_id` DESC;
UPDATE `achievement_rewards` SET `achievement_id`=`achievement_id`+1 ORDER BY `achievement_id` DESC;
UPDATE `achievement_data` SET `achievement_id`=`achievement_id`+1 ORDER BY `achievement_id` DESC;

ALTER TABLE `achievement_db` MODIFY COLUMN `desc` VARCHAR(200) NOT NULL DEFAULT 'Sem Descrição';
ALTER TABLE `achievement_db` DROP COLUMN `reward`;
ALTER TABLE `achievement_db` ADD COLUMN `ghost` SMALLINT(6) NOT NULL DEFAULT '0' AFTER `type`;
ALTER TABLE `achievement_db` AUTO_INCREMENT=300;

UPDATE `achievement_req` SET `target`='battleground' WHERE `type`='3';
UPDATE `achievement_progress` SET `target`='battleground' WHERE `type`='3';

UPDATE `achievement_req` SET `type`='15' WHERE `type`='14';
UPDATE `achievement_progress` SET `type`='15' WHERE `type`='14';

ALTER TABLE `achievement_rewards` CHANGE `ach_id` `achievement_id` INT(5) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE `achievement_rewards` MODIFY COLUMN `value` INT(11) NOT NULL DEFAULT '0';
ALTER TABLE `achievement_rewards` ADD COLUMN `rate` SMALLINT(9) NOT NULL DEFAULT '0' AFTER `type`;
ALTER TABLE `achievement_rewards` DROP PRIMARY KEY;
ALTER TABLE `achievement_rewards` ADD COLUMN `id` INT(11) NOT NULL DEFAULT '0';
ALTER TABLE `achievement_rewards` CHANGE `id` `id` INT(11) NOT NULL FIRST;
ALTER TABLE `achievement_rewards` CHANGE `id` `id` INT(11) AUTO_INCREMENT PRIMARY KEY;
ALTER TABLE `achievement_rewards` ADD KEY(`id`);

ALTER TABLE `achievement_req` ADD COLUMN `id` INT(11) NOT NULL DEFAULT '0';
ALTER TABLE `achievement_req` CHANGE `id` `id` INT(11) NOT NULL FIRST;
ALTER TABLE `achievement_req` CHANGE `id` `id` INT(11) AUTO_INCREMENT UNIQUE KEY;

UPDATE `achievement_rewards` SET `type`='8' WHERE `type`='2';
UPDATE `achievement_rewards` SET `object`='0' WHERE `object`='bStr';
UPDATE `achievement_rewards` SET `object`='1' WHERE `object`='bVit';
UPDATE `achievement_rewards` SET `object`='2' WHERE `object`='bInt';
UPDATE `achievement_rewards` SET `object`='3' WHERE `object`='bAgi';
UPDATE `achievement_rewards` SET `object`='4' WHERE `object`='bDex';
UPDATE `achievement_rewards` SET `object`='5' WHERE `object`='bLuk';

UPDATE `achievement_rewards` SET `type`='1' WHERE `object`='Zeny';
UPDATE `achievement_rewards` SET `type`='2' WHERE `object`='#CashPoints';
UPDATE `achievement_rewards` SET `object`='CashPoints' WHERE `type`='2';
UPDATE `achievement_rewards` SET `type`='3' WHERE `object`='#KafraPoints';
UPDATE `achievement_rewards` SET `object`='KafraPoints' WHERE `type`='3';
UPDATE `achievement_rewards` SET `type`='4' WHERE `object`='BaseExp';
UPDATE `achievement_rewards` SET `type`='5' WHERE `object`='JobExp';

UPDATE `achievement_rewards` SET `rate`='7500';

ALTER TABLE `achievement_rewards` ADD COLUMN `status` SMALLINT(6) NOT NULL DEFAULT '0';
UPDATE `achievement_rewards` SET `status`='1';

ALTER TABLE `achievement_progress` DROP PRIMARY KEY, ADD PRIMARY KEY(`account_id`, `achievement_id`, `type`, `target`);

#new stuff
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (67, 'De passo em passo', 'conquista_67', 'c44', 'Ganhe um Nível de Base ou de Classe no Jogo.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (68, 'Estou pronto!', 'conquista_68', 'c45', 'Alcance o Nível 9 de Classe como Aprendiz.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (69, 'Ao infinito e Além!', 'conquista_69', 'c44', 'Alcance o Nível 99 de Base com qualquer Classe.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (70, 'Mestre em Habilidades', 'conquista_70', 'c44', 'Alcance o Nível 50 de Classe com qualquer Classe.', 8, 1);

INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (71, 'No Caminho das Espadas', 'conquista_71', 'c46', 'Torne-se um Espadachim.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (72, 'No Caminho da Mágia', 'conquista_72', 'c47', 'Torne-se um Mago.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (73, 'No Caminho das Flechas', 'conquista_73', 'c48', 'Torne-se um Arqueiro.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (74, 'No Caminho do Comércio', 'conquista_74', 'c49', 'Torne-se um Mercador.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (75, 'No Caminho das Ruas', 'conquista_75', 'c50', 'Torne-se um Gatuno.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (76, 'No Caminho da Santidade', 'conquista_76', 'c51', 'Torne-se um Noviço.', 8, 1);

INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (77, 'Um verdadeiro Cavaleiro', 'conquista_77', 'c52', 'Torne-se um Cavaleiro.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (78, 'Expresso Mágico', 'conquista_78', 'c53', 'Torne-se um Bruxo.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (79, 'Entre a Caça e o Caçador', 'conquista_79', 'c54', 'Torne-se um Caçador.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (80, 'Engenheiro de Armas', 'conquista_80', 'c55', 'Torne-se um Ferreiro.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (81, 'Guerreiro das Sombras', 'conquista_81', 'c56', 'Torne-se um Mercenário.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (82, 'Santo Graal', 'conquista_82', 'c57', 'Torne-se um Sacerdote.', 8, 1);

INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (83, 'Escudo Absoluto', 'conquista_83', 'c58', 'Torne-se um Templário.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (84, 'Aprendizagem', 'conquista_84', 'c59', 'Torne-se um Sábio.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (85, 'Ritimo da Música', 'conquista_85', 'c60', 'Torne-se um Bardo ou Odalisca.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (86, 'Troca Equivalente', 'conquista_86', 'c61', 'Torne-se um Alquimista.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (87, 'Miliante', 'conquista_87', 'c62', 'Torne-se um Arruaceiro.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (88, 'Dominio da Força', 'conquista_88', 'c63', 'Torne-se um Monge.', 8, 1);

INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (89, 'Anjo da Guarda!', 'conquista_89', 'c45', 'Torne-se um Super Aprendiz.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (90, 'Mestre em Ninjutsu', 'conquista_90', 'c64', 'Torne-se um Ninja.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (91, 'Pistoleiro', 'conquista_91', 'c65', 'Torne-se um Justiceiro.', 8, 1);

INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (92, 'Grande Guerreiro', 'conquista_92', 'c66', 'Torne-se um Lorde.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (93, 'Mestre Arcano', 'conquista_93', 'c67', 'Torne-se um Arquimago.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (94, 'Atirador de Elite', 'conquista_94', 'c68', 'Torne-se um Atirador de Elite.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (95, 'Senhor das Armas', 'conquista_95', 'c69', 'Torne-se um Mestre Ferreiro.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (96, 'Executor', 'conquista_96', 'c70', 'Torne-se um Algoz.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (97, 'Porto Seguro', 'conquista_97', 'c71', 'Torne-se um Sumo-Sacerdote.', 8, 1);

INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (98, 'Juramento da Devoção', 'conquista_98', 'c72', 'Torne-se um Paladino.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (99, 'Profundo Conhecimento', 'conquista_99', 'c73', 'Torne-se um Professor.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (100, 'Nota Certa', 'conquista_100', 'c74', 'Torne-se um Menestrel ou uma Cigana.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (101, 'Força Vital', 'conquista_101', 'c75', 'Torne-se um Criador.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (102, 'Causa da Desordem', 'conquista_102', 'c76', 'Torne-se um Desordeiro.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (103, 'Espírito Ardente', 'conquista_103', 'c77', 'Torne-se um Mestre.', 8, 1);

INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (104, 'Taekwondo', 'conquista_104', 'c78', 'Torne-se um Taekwon.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (105, 'Compreensão da Alma', 'conquista_105', 'c79', 'Torne-se um Espiritualista.', 8, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (106, 'Mestre das Artes Marciais', 'conquista_106', 'c80', 'Torne-se um Mestre Taekwon.', 8, 1);

INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (107, 'Dando o troco', 'conquista_107', 'c01', 'Colete 500 Jellopy de um Poring.', 9, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (108, 'Estamos quites', 'conquista_108', 'c01', 'Colete 1.000 Jellopy de um Poring.', 9, 1);

INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (109, 'Consumidor de Poções', 'conquista_109', 'c81', 'Mostre que você é um verdadeiro Consumidor de Poções.', 9, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (110, 'Negociador de Utilidades', 'conquista_110', 'c82', 'Compre alguns itens em Lojas de Utilidades.', 9, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (111, 'Iniciante no Comércio da Comunidade', 'conquista_111', 'c82', 'Compre 10 itens em Lojas de Jogadores.', 9, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (112, 'Intermediário no Comércio da Comunidade', 'conquista_112', 'c82', 'Compre 50 itens em Lojas de Jogadores.', 9, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (113, 'Avançado no Comércio da Comunidade', 'conquista_113', 'c82', 'Compre 100 itens em Lojas de Jogadores.', 9, 1);

INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (114, 'Entrando no Comércio da Comunidade', 'conquista_114', 'c82', 'Venda 100 itens para Jogadores.', 9, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (115, 'Contribuidor no Comércio da Comunidade', 'conquista_115', 'c82', 'Venda 500 itens para Jogadores.', 9, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (116, 'Perito no Comércio da Comunidade', 'conquista_116', 'c82', 'Venda 1.000 itens para Jogadores.', 9, 1);

INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (117, 'Iniciante em Negociação', 'conquista_117', 'c82', 'Troque 5 itens com outros jogadores.', 9, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (118, 'Intermediário em Negociação', 'conquista_118', 'c82', 'Troque 15 itens com outros jogadores.', 9, 1);
INSERT INTO `achievement_db` (`id`, `name`, `cutin`, `icon`, `desc`, `type`, `reward`, `status`) VALUES (119, 'Avançado em Negociação', 'conquista_119', 'c82', 'Troque 45 itens com outros jogadores.', 9, 1);


INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (67, 21, 'AnyLevel', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (68, 20, 'JobLevel', 9, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (68, 22, '0', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (69, 19, 'BaseLevel', 99, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (70, 20, 'JobLevel', 50, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (71, 22, '1', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (71, 22, '4002', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (71, 22, '4024', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (72, 22, '2', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (72, 22, '4003', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (72, 22, '4025', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (73, 22, '3', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (73, 22, '4004', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (73, 22, '4026', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (74, 22, '5', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (74, 22, '4006', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (74, 22, '4028', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (75, 22, '6', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (75, 22, '4007', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (75, 22, '4029', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (76, 22, '4', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (76, 22, '4005', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (76, 22, '4027', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (77, 22, '7', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (77, 22, '13', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (77, 22, '4030', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (77, 22, '4036', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (78, 22, '9', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (78, 22, '4032', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (79, 22, '11', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (79, 22, '4034', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (80, 22, '10', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (80, 22, '4033', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (81, 22, '12', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (81, 22, '4035', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (82, 22, '8', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (82, 22, '4031', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (83, 22, '15', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (83, 22, '21', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (83, 22, '4037', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (83, 22, '4044', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (84, 22, '16', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (84, 22, '4039', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (85, 22, '19', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (85, 22, '4042', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (85, 22, '20', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (85, 22, '4043', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (86, 22, '18', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (86, 22, '4041', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (87, 22, '17', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (87, 22, '4040', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (88, 22, '15', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (88, 22, '4038', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (89, 22, '23', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (89, 22, '4045', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (90, 22, '25', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (91, 22, '24', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (92, 22, '4008', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (92, 22, '4014', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (93, 22, '4010', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (94, 22, '4012', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (95, 22, '4011', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (96, 22, '4013', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (97, 22, '4009', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (98, 22, '4015', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (98, 22, '4022', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (99, 22, '4017', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (100, 22, '4020', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (100, 22, '4021', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (101, 22, '4019', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (102, 22, '4018', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (103, 22, '4016', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (104, 22, '4046', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (105, 22, '4049', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (106, 22, '4047', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (106, 22, '4048', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (107, 13, '909', 500, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (107, 14, '1002', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (108, 13, '909', 1000, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (108, 14, '1002', 1, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (109, 25, '501', 10, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (109, 25, '502', 10, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (109, 25, '504', 10, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (109, 25, '505', 10, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (109, 25, '503', 3, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (109, 25, '506', 3, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (109, 25, '545', 3, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (109, 25, '546', 3, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (109, 25, '547', 3, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (110, 26, '611', 30, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (110, 26, '601', 20, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (110, 26, '602', 20, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (111, 30, 'anyitem', 10, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (112, 30, 'anyitem', 50, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (113, 30, 'anyitem', 100, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (114, 36, 'anyitem', 100, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (115, 36, 'anyitem', 500, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (116, 36, 'anyitem', 1000, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (117, 42, 'anyitem', 5, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (118, 42, 'anyitem', 15, 1);
INSERT INTO `achievement_req` (`achievement_id`, `type`, `target`, `value`, `status`) VALUES (119, 42, 'anyitem', 45, 1);

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (67, 'BaseExp', 10000, 1, 'Experiência de Base', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (67, 'JobExp', 10000, 1, 'Experiência de Classe', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (68, '14232', 2, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (69, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (70, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (71, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (71, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (71, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (71, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (71, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (72, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (72, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (72, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (72, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (72, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (73, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (73, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (73, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (73, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (73, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (74, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (74, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (74, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (74, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (74, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (75, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (75, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (75, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (75, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (75, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (76, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (76, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (76, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (76, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (76, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (77, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (77, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (77, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (77, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (77, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (78, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (78, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (78, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (78, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (78, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (79, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (79, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (79, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (79, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (79, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (80, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (80, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (80, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (80, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (80, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (81, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (81, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (81, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (81, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (81, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (82, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (82, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (82, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (82, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (82, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (83, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (83, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (83, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (83, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (83, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (84, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (84, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (84, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (84, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (84, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (85, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (85, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (85, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (85, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (85, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (86, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (86, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (86, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (86, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (86, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (87, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (87, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (87, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (87, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (87, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (88, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (88, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (88, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (88, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (88, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (89, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (89, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (89, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (89, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (89, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (90, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (90, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (90, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (90, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (90, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (91, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (91, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (91, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (91, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (91, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (92, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (92, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (92, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (92, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (92, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (93, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (93, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (93, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (93, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (93, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (94, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (94, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (94, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (94, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (94, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (95, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (95, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (95, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (95, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (95, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (96, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (96, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (96, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (96, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (96, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (97, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (97, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (97, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (97, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (97, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (98, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (98, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (98, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (98, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (98, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (99, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (99, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (99, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (99, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (99, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (100, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (100, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (100, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (100, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (100, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (101, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (101, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (101, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (101, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (101, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (102, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (102, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (102, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (102, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (102, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (103, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (103, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (103, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (103, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (103, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (104, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (104, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (104, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (104, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (104, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (105, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (105, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (105, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (105, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (105, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (106, '14232', 10, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (106, '14232', 20, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (106, '14232', 30, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (106, '14232', 40, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (106, '14232', 50, 0, 'Caixa de Fruto de Yggdrasil', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (107, 'Zeny', 100000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (108, 'Zeny', 100000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (109, '503', 20, 0, 'Poção Amarela', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (109, '502', 20, 0, 'Poção Laranja', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (109, '501', 20, 0, 'Poção Vermelha', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (109, '504', 20, 0, 'Poção Branca', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (109, '505', 20, 0, 'Poção Azul', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (109, '506', 20, 0, 'Poção Verde', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (109, '545', 20, 0, 'Poção Vermelha Compacta', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (109, '546', 20, 0, 'Poção Amarela Compacta', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (109, '547', 20, 0, 'Poção Branca Compacta', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (110, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (110, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (110, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (110, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (111, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (111, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (111, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (111, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (112, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (112, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (112, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (112, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (113, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (113, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (113, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (113, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (114, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (114, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (114, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (114, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (115, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (115, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (115, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (115, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (116, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (116, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (116, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (116, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (117, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (117, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (117, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (117, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (118, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (118, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (118, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (118, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );

INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (119, 'Zeny', 30000, 1, 'Zeny', 7500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (119, 'Zeny', 60000, 1, 'Zeny', 5000, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (119, 'Zeny', 90000, 1, 'Zeny', 3500, 1 );
INSERT INTO `achievement_rewards` (`achievement_id`, `object`, `value`, `type`, `desc`, `rate`, `status`) VALUES (119, 'Zeny', 120000, 1, 'Zeny', 2500, 1 );

CREATE TABLE IF NOT EXISTS `achievement_ranking` (
	`account_id` INT(11) NOT NULL,
	`score` INT(11) NOT NULL DEFAULT '0',
	`lastupdate` DATETIME NULL,
  PRIMARY KEY (`account_id`),
  KEY `id` (`account_id`)
) ENGINE=MyISAM;
	
CREATE TABLE IF NOT EXISTS `creativesd_profile` (
  `account_id` INT(11) NOT NULL,
  `nickname` VARCHAR(20) NOT NULL DEFAULT 'Nick não definido',
  `name` VARCHAR(50) NOT NULL DEFAULT 'Nome não definido',
  `sex` SMALLINT(6) NOT NULL DEFAULT '0',
  `birthdate` DATE NULL,
  `country` VARCHAR(32) NOT NULL DEFAULT '',
  `state` VARCHAR(32) NOT NULL DEFAULT '',
  `email` VARCHAR(39) NOT NULL DEFAULT '',
  `skype` VARCHAR(39) NOT NULL DEFAULT '',
  `facebook` VARCHAR(32) NOT NULL DEFAULT '',
  `twitter` VARCHAR(32) NOT NULL DEFAULT '',
  `googleplus` VARCHAR(32) NOT NULL DEFAULT '',
  `instagram` VARCHAR(32) NOT NULL DEFAULT '',
  `linkedin` VARCHAR(32) NOT NULL DEFAULT '',
  `youtube` VARCHAR(32) NOT NULL DEFAULT '',
  `avatar` TEXT,
  `description` MEDIUMTEXT,
  PRIMARY KEY (`account_id`),
  KEY `id` (`account_id`)
) ENGINE=MyISAM;