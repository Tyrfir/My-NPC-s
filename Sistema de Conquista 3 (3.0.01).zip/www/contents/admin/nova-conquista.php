<?php
	if( !defined("MAIN_PAGE") )
		exit;
	
	// Get HTML Header
	require_once('contents/includes/header.php');
	require_once('contents/includes/menu.php');
	
	$filesIcon = scandir('images/icons',0);
?>
	<div class="content page">
		<div class="container-fluid">
			<div class="row">
				<div class="col-xs-12 margin-10x-top">
					<h3><span class="glyphicon glyphicon-plus" aria-hidden="true"></span>&nbsp;&nbsp; Adicionar nova Conquista</h3>
					<hr>
				</div>
			</div>
			<form id="new-achievement">
			<div class="row margin-10x-bottom">
				<div class="col-xs-12">
					<div class="alert alert-info">
						<label><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span> Orienta��es</label>
						<ul>
							<li>M�nimo de caracteres para nome � <strong><?php echo $CharRules['MIN_NAME']; ?></strong> e o M�ximo � <strong><?php echo $CharRules['MAX_NAME']; ?></strong> caracteres.</li>
							<li>Os �cones devem estar na pasta <strong>images/icons</strong> no formato <strong>PNG ou GIF</strong>.</li>
							<li>Caso voc� utilize um icone com o mesmo nome em <strong>PNG e GIF</strong>, o <strong>PNG</strong> ser� priorizado.</li>
							<li>Lembre-se de adicionar o <strong>CSS</strong> dos �cones em <strong>css/icons.css</strong>, deve seguir a classe <strong>.img-nome_do_icone</strong>.</li>
							<li>Conquista <strong>Fantasma</strong> impossibilita que seja vista pelos jogadores na <strong>Lista de Conquistas</strong>.</li>
							<li>M�nimo de caracteres para descri��o � <strong><?php echo $CharRules['MIN_DESC']; ?></strong> e o M�ximo � <strong><?php echo $CharRules['MAX_DESC']; ?></strong> caracteres.</li>
							<li>Use a <strong>Pr�-visualiza��o</strong> para visualizar como esta ficando sua conquista, isto � importante na hora de gerar seu cutin.</li>
						</ul>
					</div>
					<div class="alert-icon-help-3"></div>
				</div>
			</div>
			<div class="row margin-10x-top">
				<div class="col-xs-12">
					<div class="alert alert-danger no-display">
						<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> <strong>Erro na Opera��o</strong>
						<div></div>
					</div>
				</div>
			</div>
			<div class="row margin-10x-top">
				<div class="col-xs-8">
					<label for="name">Nome da Conquista:</label>
					<input name="name" id="name" class="form-control" maxlength="<?php echo $CharRules['MAX_NAME']; ?>">
				</div>
				<div class="col-xs-4">
					<label for="type">Tipo da Conquista:</label>
					<select name="type" id="type" class="form-control">
					<?php
						foreach( $CategoryList as $value => $name ) {
					?>
						<option value="<?php echo $value;?>"><?php echo $name; ?>
						<?php
						}
					?>
					</select>
				</div>
			</div>
			<div class="row margin-10x-top">
				<div class="col-xs-4">
					<label for="icon">Icone:</label>
					<select name="icon" id="icon" class="form-control">
					<?php
						$options = "";
						$primaryIcon = "";
						$primaryCss = "";
						for( $i=0; $i < count($filesIcon); $i++ ) {
							if( strpos($filesIcon[$i], ".gif") === false && strpos($filesIcon[$i], ".png") === false )
								continue;
							
							$iconValue = str_replace(array(".png", ".gif"), "", $filesIcon[$i]);
							if( strpos($filesIcon[$i], ".png") === true && strpos($options, "images/icons/{$iconValue}.gif") == true )
								str_replace("images/icons/{$iconValue}.gif", "images/icons/{$iconValue}.png");
							else
								$options .= "\n<option value=\"{$iconValue}\">images/icons/{$filesIcon[$i]}</option>";
						
							if( empty($primaryIcon) )
							{
								$primaryIcon = $filesIcon[$i];
								$primaryCss = $iconValue;
							}
						}
						echo $options;
					?>
					</select>
				</div>
				<div class="col-xs-4">
					<label for="ghostmode">Conquista Fantasma:</label>
					<select name="ghostmode" id="ghostmode" class="form-control">
						<option value="0">Desligada</option>
						<option value="1">Ligada</option>
					</select>
				</div>
				<div class="col-xs-4">
					<label for="status">Situa��o:</label>
					<select name="status" id="status" class="form-control">
						<option value="0">Desativada</option>
						<option value="1">Ativada</option>
					</select>
				</div>
			</div>
			<div class="row margin-10x-top">
				<div class="col-xs-12">
					<label for="desc">Descri��o:</label>
					<textarea name="desc" id="desc" class="form-control" maxlength="<?php echo $CharRules['MAX_DESC']; ?>" placeholder="Visualize a descri��o na Pr�-visualiza��o para ver como fica em sua Conquista!"></textarea>
				</div>
			</div>
			<div id="cutin-generator">
				<div class="row margin-10x-top">
					<div class="col-xs-12">
						<label>Pr�-visualiza��o:</label>
						<div class="cutin">
							<div class="table-conquest">
								<div class="base-top">Sem nome</div>
								<div class="base-image" default-icon="images/icons/<?php echo $primaryIcon; ?>" default-css="<?php echo $primaryCss; ?>"><img src="images/icons/<?php echo $primaryIcon; ?>" class="img-<?php echo $primaryCss;?>" /></div>
								<div class="base-desc" default-desc="Sem descri��o">Sem descri��o</div>
								<div class="base-bottom">&nbsp;</div>
								<div class="clear"></div>
							</div>
						</div>
					</div>
				</div>
				<div class="row margin-10x-bottom">
					<div class="col-xs-12 margin-20x-top">
						<label>Op��es de Visualiza��o:</label>
						<div class="checkbox">
							 <label><input id="defaultcutin" type="checkbox">Utilizar janela padr�o do jogo</label>
						</div>
						<div class="form-inline">
						  <label for="wdt">Largura:</label>
						  <input id="wdt" name="wdt" type="number" class="form-control" value="390">
						  <label for="hgt">Altura:</label>
						  <input id="hgt" name="hgt" type="number" class="form-control" value="137" disabled>
						</div>
					</div>
				</div>
			
			</div>
			<div class="row margin-30x-top margin-10x-bottom">
				<div class="col-xs-12 text-center">
					<button type="reset" class="btn btn-danger btn-md"><span class="glyphicon glyphicon-repeat" aria-hidden="true"></span> Refazer</button>
					<button type="submit" class="btn btn-success btn-md"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span> Salvar</button>
				</div>
			</div>
		</div>
		</form>
	</div>
	
	<script type="text/javascript" src="js/achievement-manager.js"></script>
	<script type="text/javascript" src="js/cutin-generator.js"></script>
	
<?php
	// Get HTML Bottom Header
	require_once('contents/includes/bottom.php');
?>