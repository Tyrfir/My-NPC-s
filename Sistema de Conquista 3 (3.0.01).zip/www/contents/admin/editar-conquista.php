<?php
	if( !defined("MAIN_PAGE") )
		exit;
	
	// Requer esta conectado...
	$Auth->RequireLogin();
	
	// N�o est� autorizado a visualizar a p�gina.
	if( !$Auth->CheckAccess('ACH_EDIT') ) {
		include_once('contents/errors/not-authorized.php');
		exit;
	}

	if( isset($_GET['achievement_id']) && is_numeric($_GET['achievement_id']) && ($count = $Ach->LoadFromID($_GET['achievement_id'])) > 0 )
	{
		
		// Get HTML Header
		require_once('contents/includes/header.php');
		require_once('contents/includes/menu.php');
		
		$filesIcon = scandir('images/icons',0);
?>
	<ol class="breadcrumb breadcrumb-adjust" id="submenus">
	  <li><a href="#main">Editar Conquista</a></li>
<?php
	if( $Auth->CheckAccess('GEN_CUTIN') ) {
?>
	  <li><a href="#cutin-generator">Gerar Cutin</a></li>
<?php
	}
?>
	  <li><a href="#targets">Gerenciar Alvos</a></li>
	  <li><a href="#rewards"> Gerenciar Recompensas</a></li>
	</ol>

	<div class="content page margin-xs-top-10x" id="main">
		<div class="container-fluid">
			<div class="row margin-10x-top">
				<div class="col-xs-12">
					<h3><span class="glyphicon glyphicon-cog" aria-hidden="true"></span>&nbsp;&nbsp; Gerenciar Conquista</h3>
				</div>
			</div>
			<hr>
			<div class="row margin-10x-bottom">
				<div class="col-xs-12">
					<div class="alert alert-info">
						<div class="alert-content">
							<label><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span> Orienta��es</label>
							<ul>
								<li>M�nimo de caracteres para nome � <strong><?php echo $CharRules['MIN_NAME'] ?></strong> e o M�ximo � <strong><?php echo $CharRules['MAX_NAME'] ?></strong> caracteres.</li>
								<li>Os �cones devem estar na pasta <strong>images/icons</strong> no formato <strong>PNG ou GIF</strong>.</li>
								<li>Caso voc� utilize um icone com o mesmo nome em <strong>PNG e GIF</strong>, o <strong>PNG</strong> ser� priorizado.</li>
								<li>Lembre-se de adicionar o <strong>CSS</strong> dos �cones em <strong>css/icons.css</strong>, deve seguir a classe <strong>.img-nome_do_icone</strong>.</li>
								<li>Conquista <strong>Fantasma</strong> impossibilita que seja vista pelos jogadores na <strong>Lista de Conquistas</strong>.</li>
								<li>M�nimo de caracteres para descri��o � <strong><?php echo $CharRules['MIN_DESC'] ?></strong> e o M�ximo � <strong><?php echo $CharRules['MAX_DESC'] ?></strong> caracteres.</li>
							</ul>
						</div>
						<div class="alert-icon-help-1"></div>
					</div>
				</div>
			</div>
<?php
		$aid = $Ach->achievements['id'][0];
		$aname = $Ach->achievements['name'][0];
		$type = $Ach->achievements['type'][0];
		$cutin = $Ach->achievements['cutin'][0];
		$desc = $Ach->achievements['desc'][0];
		$icon = $Ach->achievements['icon'][0];
		$rewards = "";
		
		if( $Ach->rewards[$aid]['count'] )
			$rewards = $Tpl->CreateRewardList($Ach->rewards[$aid]);
?>
			<form id="edit-achievement">
			<div class="row margin-10x-top">
				<div class="col-xs-12">
					<div class="alert alert-danger no-display">
						<a href="#" class="close">&times;</a>
						<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> <strong>Erro na Opera��o</strong>
						<div></div>
					</div>
					
					<div class="alert alert-success no-display">
						<a href="#" class="close">&times;</a>
						<span class="glyphicon glyphicon-ok aria-hidden="true"></span> <strong>Sucesso</strong>
						<div></div>
					</div>
				</div>
			</div>
			<div class="row margin-10x-top">
				<div class="col-xs-4">
					<label for="id">Identifica��o �nica:</label>
					<input type="hidden" name="achievement_id" id="achievement_id" value="<?php echo $aid; ?>">
					<input type="text" name="fake_id" name="fake_id" class="form-control" value="<?php echo $aid; ?>" disabled>
				</div>
				<div class="col-xs-8">
					<label for="name">Nome da Conquista:</label>
					<input type="text" name="name" id="name" class="form-control" value="<?php echo $aname; ?>" maxlength="<?php echo $CharRules['MAX_NAME']; ?>">
				</div>
			</div>
			<div class="row margin-10x-top">
				<div class="col-xs-4">
					<label for="type">Tipo da Conquista:</label>
					<select name="type" id="type" class="form-control">
					<?php
						foreach( $CategoryList as $value => $name ) {
					?>
						<option value="<?php echo $value;?>"<?php if( $value == $type ) { echo " selected"; }?>><?php echo $name; ?></option>
						<?php
						}
					?>
					</select>
				</div>
				<div class="col-xs-4">
					<label for="fake_cutin">Cutin:</label>
					<input type="text" name="fake_cutin" name="fake_cutin" class="form-control" value="<?php echo $cutin; ?>" disabled>
				</div>
				<div class="col-xs-4">
					<label for="icon">Icone:</label>
					<select name="icon" id="icon" class="form-control">
					<?php
						$options = "";
						$primaryIcon = "";
						$primaryCss = "";
						for( $i=0; $i < count($filesIcon); $i++ ) {
							if( strpos($filesIcon[$i], ".gif") === false && strpos($filesIcon[$i], ".png") === false )
								continue;
							
							$iconValue = str_replace(array(".png", ".gif"), "", $filesIcon[$i]);
							if( strpos($filesIcon[$i], ".png") === true && strpos($options, "images/icons/{$iconValue}.gif") == true )
								str_replace("images/icons/{$iconValue}.gif", "images/icons/{$iconValue}.png");
							else
								$options .= "\n<option value=\"{$iconValue}\"" . ($icon == $iconValue?" selected":"") . ">images/icons/{$filesIcon[$i]}</option>";
						
							if( $iconValue == $icon || empty($primaryIcon) )
							{
								$primaryIcon = $filesIcon[$i];
								$primaryCss = $iconValue;
							}
							
							
						}
						echo $options;
					?>
					</select>
				</div>
			</div>
			<div class="row margin-10x-top">
				<div class="col-xs-4">
					<label for="ghostmode">Conquista Fantasma:</label>
					<select name="ghostmode" id="ghostmode" class="form-control">
						<option value="0">Desligada</option>
						<option value="1">Ligada</option>
					</select>
				</div>
				<div class="col-xs-4">
					<label for="status">Situa��o:</label>
					<select name="status" id="status" class="form-control">
						<option value="0"<?php if( $status == 0 ) { echo " selected"; }?>>Desativada</option>
						<option value="1"<?php if( $status == 1 ) { echo " selected"; }?>>Ativada</option>
					</select>
				</div>
			</div>
			<div class="row margin-10x-top">
				<div class="col-xs-12">
					<label for="desc">Descri��o:</label>
					<textarea name="desc" id="desc" class="form-control" maxlength="<?php echo $CharRules['MAX_DESC']; ?>" placeholder="Visualize a descri��o na Pr�-visualiza��o para ver como fica em sua Conquista!"><?php echo $desc; ?></textarea>
				</div>
			</div>
			<div class="row margin-10x-top margin-10x-bottom">
				<div class="col-xs-12 text-center">
					<button type="reset" class="btn btn-danger btn-md"><span class="glyphicon glyphicon-repeat" aria-hidden="true"></span> Refazer</button>
					<button type="submit" class="btn btn-success btn-md"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span> Salvar</button>
				</div>
			</div>
			</form>
		</div>
	</div>
	
	<div class="content page no-display margin-xs-top-10x" id="cutin-generator">
		<div class="container-fluid">
			<div class="row margin-10x-top">
				<div class="col-xs-12">
					<h3><span class="glyphicon glyphicon-picture" aria-hidden="true"></span>&nbsp;&nbsp; Gerar Cutin</h3>
				</div>
			</div>
			<hr>
			<div class="row margin-10x-bottom">
				<div class="col-xs-12">
					<div class="alert alert-warning" role="alert">
					  <div class="alert-content">
						  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
						  <strong>Aten��o, para salvar seu Cutin � necess�rio que</strong>
						  <ul>
							<li>Ajuste a largura entre <strong>390 � 700 pixels</strong>, a altura � gerada automaticamente.</li>
							<li>Tire uma <strong>PrintScreen</strong> da <strong>caixa rosa</strong> abaixo.</li>
							<li>Utilize um <strong>Editor de Imagens</strong> selecionando apenas a imagem de acordo com a <strong>largura e altura</strong> informada pelo sistema.</li>
							<li>Salve o Cutin no <strong>Formato BMP</strong> e adicione na pasta <strong>Data/GRF</strong>, caso haja d�vidas acesse <a href="https://rathena.org/wiki/cutin" target="_blank">Wikip�dia do rAthena</a> que serve para qualquer emulador e patch.</li>
						  </ul>
					  </div>
					  <div class="alert-icon-help-2"></div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12">
					<label>Cutin:</label>
					<div class="cutin">
						<div class="table-conquest">
							<div class="base-top" default-name="<?php echo $aname; ?>"><?php echo $aname; ?></div>
							<div class="base-image" default-icon="images/icons/<?php echo $primaryIcon; ?>" default-css="<?php echo $primaryCss; ?>"><img src="images/icons/<?php echo $primaryIcon; ?>" class="img-<?php echo $primaryCss;?>" /></div>
							<div class="base-desc" default-desc="<?php echo $desc; ?>"><?php echo $desc; ?></div>
							<div class="base-bottom"><?php echo $rewards; ?></div>
							<div class="clear"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="row margin-10x-bottom">
				<div class="col-xs-12 margin-20x-top">
					<label>Op��es de Visualiza��o:</label>
					<div class="checkbox">
					  <label><input id="showreward" type="checkbox" checked>Mostrar recompensas</label>
					</div>
					<div class="checkbox">
					  <label><input id="showrate" type="checkbox">Mostrar chances de recompensa</label>
					</div>
					<div class="checkbox">
						 <label><input id="defaultcutin" type="checkbox">Utilizar janela padr�o do jogo</label>
					</div>
					<div class="form-inline">
					  <label for="wdt">Largura:</label>
					  <input id="wdt" name="wdt" type="number" class="form-control" value="390">
					  <label for="hgt">Altura:</label>
					  <input id="hgt" name="hgt" type="number" class="form-control" value="137" disabled>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="content page no-display margin-xs-top-10x" id="targets">
		<div class="container-fluid">
			<div class="row margin-10x-top">
				<div class="col-xs-12">
					<h3><span class="glyphicon glyphicon-screenshot" aria-hidden="true"></span>&nbsp;&nbsp; Alvos</h3>
				</div>
			</div>
			<hr>
<?php
	if( $Auth->CheckAccess('ADD_TARGET') ) {
?>
			<div class="row margin-10x-bottom">
				<div class="col-xs-12">
					<div class="alert alert-info">
						<div class="alert-content">
							<label><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span> Orienta��es</label>
							<ul>
								<li><strong>N�o � permitido duplica��es de alvos</strong>, exemplo utilizar dois alvos com o mesmo tipo, isso n�o � permitido e ir� substituir o valor do que est� inserido.</li>
								<li>Selecione o tipo do alvo e os atributos permitidos ser�o exibidos para inser��o.</li>
								<li>Para <strong>alterar o valor do alvo</strong>, basta selecionar o tipo do alvo ap�s selecionado preencher os valores de acordo com o alvo j� existente modificando somente o valor.</li>
							</ul>
						</div>
						<div class="alert-icon-help-3"></div>
					</div>
				</div>
			</div>
			<form id="add-targets">
			<input type="hidden" id="achievement_id" name="achievement_id" value="<?php echo $aid; ?>">
			<div class="row margin-10x-top">
				<div class="col-xs-12">
					<div class="alert alert-danger no-display">
						<a href="#" class="close">&times;</a>
						<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> <strong>Erro na Opera��o</strong>
						<div></div>
					</div>
					
					<div class="alert alert-success no-display">
						<a href="#" class="close">&times;</a>
						<span class="glyphicon glyphicon-ok aria-hidden="true"></span> <strong>Sucesso</strong>
						<div></div>
					</div>
				</div>
			</div>
			
			<div class="row margin-10x-top">
				<div class="col-xs-12">
					<div class="form-group">
						<label for="target_type">Tipo do Alvo:</label>
						<select id="target_type" name="target_type" class="form-control">
							<option value="">Selecione um tipo de alvo...</option>
							<?php
								foreach( $TargetTypes as $value => $name ) {
									$enabledopts = "";
									if( isset($TargetOptions[$value]) )
									{
										for( $i = 0; $i < count($TargetOptions[$value]); $i++ )
											$enabledopts .= $TargetOptions[$value][$i].($i+1<count($TargetOptions[$value])?",":"");
									}
							?>
							<option value="<?php echo $value;?>"<?php if(!empty($enabledopts)) { echo ' enabledOpts="'.$enabledopts.'"'; } if( !is_null($target_type) && $target_type == $value ) { echo " selected"; } ?>><?php echo $name; ?></option>
							<?php
								}
							?>
						</select>
					</div>
				</div>
			</div>
			<div class="row margin-10x-top">
				<div class="col-xs-6" id="primary-group">
					<div class="form-group no-display" id="add_target">
						<label for="target">Alvo:</label>
						<input id="target" name="target" class="form-control" type="text" maxlength="<?php echo $CharRules['MAX_TARGET']; ?>" autocomplete="off" disabled>
					</div>
					
					<div class="form-group no-display" id="add_hour">
						<label for="hour">Hor�rio:</label>
								
						<input id="hour" name="hour" class="form-control" type="number" min="00" max="24" placeholder="hh" disabled>
						<div id="hour_separate">:</div>
						<input id="minute" name="minute" class="form-control" type="number" min="00" max="60" placeholder="mm" disabled>
						<div class="clear"></div>
					</div>
					
					<div class="form-group no-display" id="add_timer">
						<label for="timer">Tempo:</label>
						<input id="timer" name="timer" class="form-control" type="number" disabled>
						<small>O tempo deve ser informado em minutos.</small>
					 </div>
				</div>
				<div class="col-xs-6" id="secundary-group">
					<div class="form-group no-display" id="add_amount">
						<label>Quantidade:</label>
						<input id="amount" name="amount" class="form-control" type="number" min="<?php echo $CharRules['MIN_TARGET_VALUE'] ?>" max="<?php echo $CharRules['MAX_TARGET_VALUE']; ?>" disabled>
					</div>
				</div>
			</div>
			<div class="row margin-10x-top">
				<div class="col-xs-12 text-center">
					<button type="reset" class="btn btn-danger btn-md" disabled><span class="glyphicon glyphicon-repeat" aria-hidden="true"></span> Refazer</button>
					<button type="submit" class="btn btn-success btn-md" disabled><span class="glyphicon glyphicon-ok" aria-hidden="true"></span> Salvar</button>
				</div>
			</div>
			</form>
<?php
	}
?>
			<div class="row margin-10x-top">
				<div class="col-xs-12" id="target-list">
					<div class="panel panel-primary filterable">
						<div class="panel-heading">
							<h3 class="panel-title">Lista de Alvos</h3>
							<div class="pull-right">
								<button class="btn btn-default btn-xs btn-filter"><span class="glyphicon glyphicon-filter"></span> Filtro</button>
							</div>
						</div>
						<table class="table">
							<thead>
								<tr class="filters">
									<th><input type="text" class="form-control" placeholder="Alvo" disabled></th>
									<th><input type="text" class="form-control" placeholder="Tipo" disabled></th>
									<th><input type="text" class="form-control" placeholder="Descri��o" disabled></th>
									<th><input type="text" class="form-control" placeholder="Valor" disabled></th>
									<th><input type="text" class="form-control" placeholder="Situa��o" disabled></th>
									<th>&nbsp;</th>
								</tr>
							</thead>
							<tbody>
							<?php
								$count_targets = isset($Ach->targets[$aid]['count'])?$Ach->targets[$aid]['count']:0;
								if( $count_targets ) {
									for( $i=0; $i < $count_targets; $i++ ) {
										$id = $Ach->targets[$aid]['id'][$i];
										$target = $Ach->targets[$aid]['target'][$i];
										$type = $Ach->targets[$aid]['type'][$i];
										$value = $Ach->targets[$aid]['value'][$i];
										$status = $Ach->targets[$aid]['status'][$i];
										
										if( !isset($TargetTypes[$type]) )
											$desc = "Desconhecido";
										else
											$desc = $TargetTypes[$type];
										
										switch($type)
										{
											case 0:
											case 1:
											case 2:
											case 3:
												$target_desc = "Jogador";
												break;
											case 4:
												$target_desc = "Emperium";
												break;
											case 5:
											case 6:
											case 7:
											case 18:
											case 44:
											case 45:
											case 46:
											case 47:
												$target_desc = "Zeny";
												break;
											case 8:
											case 50:
												$target_desc = "Runa Guardi�";
												break;
											case 9:
											case 49:
												$target_desc = "Barricada";
												break;
											case 10:
												$target_desc = Numbers::calc_timer($value);
												break;
											case 11:
											case 15:
												$target_desc = $Ach->getmapname($target) . " # " . $target;
												break;
											case 12:
											case 14:
												$target_desc = $Ach->getmobname($target) . " # " . $target;
												break;
											case 13:
											case 25:
											case 26:
											case 27:
											case 28:
											case 32:
											case 33:
											case 34:
											case 38:
											case 39:
											case 40:
											case 48:
												$target_desc = $Ach->getitemname($target) . " # " . $target;
												break;
											case 16:
												$target_desc = "MvP";
												break;
											case 17:
												$target_desc = "Hor�rio # " . $target;
												break;
											case 19:
												$target_desc = "N�vel";
												break;
											case 20:
												$target_desc = "N�vel";
												break;
											case 21:
												$target_desc = "N�vel";
												break;
											case 22:
											case 23:
											case 24:
												$target_desc = $JobNames[$target] . " # " . $target;
												break;
											case 29:
											case 30:
											case 31:
											case 35:
											case 36:
											case 37:
											case 41:
											case 42:
											case 43:
												$target_desc = "Qualquer Item";
												break;
											case 51:
												$target_desc = "Contagem Regressiva";
												break;
											case 52:
												$name = $Ach->getInfo($target, 'name');
												$target_desc = $name . " # " . $target;
												break;
											default:
												$target_desc = $target;
												break;
										}
							?>
								<tr data-target="<?php echo $id; ?>">
									<td><?php echo $target_desc; ?></td>
									<td><?php echo $type; ?></td>
									<td><?php echo $desc; ?></td>
									<td><?php echo $value; ?></td>
									<td><?php echo $status?"Ativado":"Desativado" ?></td>
									<td>
							<?php
								if( $Auth->CheckAccess('REM_TARGET') ) {
							?>
										<button class="btn btn-danger btn-xs" data-action="remove" data-target="<?php echo $id; ?>" data-toggle="tooltip" data-placement="top" title="Remover"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
							<?php
								}
							
								if( $Auth->CheckAccess('CHG_TARGET') ) {
							?>
										<button class="btn btn-primary btn-xs" data-action="<?php echo $status ? "disable" : "enable" ?>" data-target="<?php echo $id; ?>" data-toggle="tooltip" data-placement="top" title="Ativar ou Desativar"><span class="glyphicon glyphicon-refresh" aria-hidden="true"></span></button>
							<?php
								}
							?>
									</td>
								</tr>
							<?php
									}
								}
								else {
							?>
								<tr class="no-result text-center"><td colspan="5">Nenhum alvo cadastrado!</td></tr>
							<?php
								}
							?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="content page no-display margin-xs-top-10x" id="rewards">
		<div class="container-fluid">
			<div class="row margin-10x-top">
				<div class="col-xs-12">
					<h3><span class="glyphicon glyphicon-gift" aria-hidden="true"></span>&nbsp;&nbsp; Recompensas</h3>
				</div>
			</div>
			<hr>
<?php
	if( $Auth->CheckAccess('ADD_REWARD') ) {
?>
			<div class="row margin-10x-bottom">
				<div class="col-xs-12">
					<div class="alert alert-info">
						<div class="alert-content">
							<label><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span> Orienta��es</label>
							<ul>
								<li>Voc� pode adicionar <strong>quantas recompensas achar necess�rio</strong>.</li>
								<li>As recompensas ser�o entregue <strong>de acordo como est� configurado na conquista</strong>, sendo <strong>todas configurada</strong> ou de <strong>modo aleat�rio</strong>.</li>
								<li>A descri��es � utilizado somente em <strong>Itens</strong>, ela serve caso o seu item n�o tenha no <strong>banco de dados de itens</strong> para identific�-lo como <strong>nome padr�o</strong>.</li>
								<li>� poss�vel configurar uma <strong>chance</strong> para ganhar a recompensa, segue abaixo os valores equivalente as chances:
									<ul>
										<li><strong>1:</strong> 0.01%</li>
										<li><strong>100:</strong> 1%</li>
										<li><strong>1000:</strong> 10%</li>
										<li><strong>10000:</strong> 100%</li>
									</ul>
								</li>
							</ul>
						</div>
						<div class="alert-icon-help-4"></div>
					</div>
				</div>
			</div>
			
			<form id="add-rewards">
			<input type="hidden" id="achievement_id" name="achievement_id" value="<?php echo $aid; ?>">
			<div class="row margin-10x-top">
				<div class="col-xs-12">
					<div class="alert alert-danger no-display">
						<a href="#" class="close">&times;</a>
						<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> <strong>Erro na Opera��o</strong>
						<div></div>
					</div>
					
					<div class="alert alert-success no-display">
						<a href="#" class="close">&times;</a>
						<span class="glyphicon glyphicon-ok aria-hidden="true"></span> <strong>Sucesso</strong>
						<div></div>
					</div>
				</div>
			</div>
			
			<div class="row margin-10x-top">
				<div class="col-xs-12">
					<div class="form-group">
						<label for="reward_type">Tipo da Recompensa:</label>
						<select id="reward_type" name="reward_type" class="form-control">
							<option value="">Selecione o tipo da recompensa...</option>
							<?php
								foreach( $RewardsType as $value => $name ) {
									$enabledopts = "";
									if( isset($TargetOptions[$value]) )
									{
										for( $i = 0; $i < count($TargetOptions[$value]); $i++ )
											$enabledopts .= $TargetOptions[$value][$i].($i+1<count($TargetOptions[$value])?",":"");
									}
							?>
							<option value="<?php echo $value;?>"<?php if(!empty($enabledopts)) { echo ' enabledOpts="'.$enabledopts.'"'; } if( !is_null($target_type) && $target_type == $value ) { echo " selected"; } ?>><?php echo $name; ?>
							<?php
								}
							?>
						</select>
					</div>
				</div>
			</div>
			<div class="row" id="reward_row_bonus">
				<div class="col-xs-12">
					<div class="form-group no-display" id="add_bonus_type">
						<label for="reward_btype">Tipo do B�nus:</label>
						<select id="reward_btype" name="reward_btype" class="form-control">
							<option value="">Selecione o tipo do b�nus...</option>
							<?php
								foreach( $BonusStatusList as $value => $name ) {
							?>
							<option value="<?php echo $value;?>"><?php echo $name; ?></option>
							<?php
								}
							?>
						</select>
					</div>
				</div>
			</div>
			<div class="row margin-10x-top">
				<div class="col-xs-12 col-sm-6">
					<div class="form-group" id="add_object">
						<label for="reward_object">Recompensa:</label>
						<input id="reward_object" name="reward_object" class="form-control" type="text" maxlength="<?php echo $CharRules['MAX_OBJECT']; ?>" autocomplete="off" disabled>
					</div>
				</div>
				
				<div class="col-xs-6">
					<div class="form-group" id="add_rw_amount">
						<label for="reward_amount">Quantidade:</label>
						<input id="reward_amount" name="reward_amount" class="form-control" type="number" min="<?php echo $CharRules['MIN_OBJECT_VALUE']; ?>" max="<?php echo $CharRules['MAX_OBJECT_VALUE']; ?>" autocomplete="off" disabled>
					</div>
				</div>
			</div>
			<div class="row margin-10x-top">
				<div class="col-xs-12 col-sm-6">
					<div class="form-group" id="add_rw_rate">
						<label for="reward_rate">Chance:</label>
						<input id="reward_rate" name="reward_rate" class="form-control" type="number" min="1" max="10000" autocomplete="off" disabled>
					</div>
				</div>
				
				<div class="col-xs-12 col-sm-6">
					<div class="form-group" id="add_rw_desc">
						<label for="reward_desc">Descri��o:</label>
						<input id="reward_desc" name="reward_desc" class="form-control" type="text" maxlength="<?php echo $CharRules['MAX_OBJECT_DESC']; ?>" autocomplete="off" disabled>
					</div>
				</div>
			</div>
			<div class="row margin-10x-top">
				<div class="col-xs-12 text-center">
					<button type="reset" class="btn btn-danger btn-md" disabled><span class="glyphicon glyphicon-repeat" aria-hidden="true"></span> Refazer</button>
					<button type="submit" class="btn btn-success btn-md" disabled><span class="glyphicon glyphicon-ok" aria-hidden="true"></span> Salvar</button>
				</div>
			</div>
			</form>
<?php
	}
?>		
			<div class="row margin-10x-top">
				<div class="col-xs-12" id="reward-list">
					<div class="panel panel-primary filterable">
						<div class="panel-heading">
							<h3 class="panel-title">Lista de Recompensas</h3>
							<div class="pull-right">
								<button class="btn btn-default btn-xs btn-filter"><span class="glyphicon glyphicon-filter"></span> Filtro</button>
							</div>
						</div>
						<table class="table">
							<thead>
								<tr class="filters">
									<th><input type="text" class="form-control" placeholder="Recompensa" disabled></th>
									<th><input type="text" class="form-control" placeholder="Descri��o" disabled></th>
									<th><input type="text" class="form-control" placeholder="Quantidade" disabled></th>
									<th><input type="text" class="form-control" placeholder="Chance" disabled></th>
									<th><input type="text" class="form-control" placeholder="Situa��o" disabled></th>
									<th>&nbsp;</th>
								</tr>
							</thead>
							<tbody>
							<?php
								$count_rewards = isset($Ach->rewards[$aid]['count'])?$Ach->rewards[$aid]['count']:0;
								if( $count_rewards ) {
									for( $i=0; $i < $count_rewards; $i++ ) {
										$id = $Ach->rewards[$aid]['id'][$i];
										$object = $Ach->rewards[$aid]['object'][$i];
										$type = $Ach->rewards[$aid]['type'][$i];
										$amount = $Ach->rewards[$aid]['value'][$i];
										$rate = $Ach->rewards[$aid]['rate'][$i];
										$name = "";
										$desc = isset($RewardsType[$type])?$RewardsType[$type]:"Desconhecido";
										$status = $Ach->rewards[$aid]['status'][$i];
										
										
										if( $type == 0 ) {
											$name = $Ach->getitemname($object);
											if( empty($name) )
												$name = "Desconhecido";
											$name .= " # " . $object;
										}
										else if( $type == 8 )
											$name = isset($BonusStatusList[$object])?$BonusStatusList[$object]:"Desconhecido";
										else
											$name = $desc;
							?>
								<tr data-target="<?php echo $id; ?>">
									<td><?php echo $name; ?></td>
									<td><?php echo $desc; ?></td>
									<td><?php echo $amount; ?></td>
									<td><?php echo $rate; ?></td>
									<td><?php echo $status?"Ativado":"Desativado" ?></td>
									<td>
							<?php
								if( $Auth->CheckAccess('REM_REWARD') ) {
							?>
										<button class="btn btn-danger btn-xs" data-action="remove" data-target="<?php echo $id; ?>" data-toggle="tooltip" data-placement="top" title="Remover"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
							<?php
								}
								
								if( $Auth->CheckAccess('CHG_REWARD') ) {
							?>
										<button class="btn btn-primary btn-xs" data-action="<?php echo $status ? "disable" : "enable" ?>" data-target="<?php echo $id; ?>" data-toggle="tooltip" data-placement="top" title="Ativar ou Desativar"><span class="glyphicon glyphicon-refresh" aria-hidden="true"></span></button>
							<?php
								}
							?>
									</td>
								</tr>
							<?php
									}
								}
								else {
							?>
								<tr class="no-result text-center"><td colspan="5">Nenhuma conquista cadastrada!</td></tr>
							<?php
								}
							?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<script type="text/javascript" src="js/table-filter.js"></script>
	<script type="text/javascript" src="js/achievement-manager.js"></script>
	<script type="text/javascript" src="js/edit-achievement.js"></script>
	<script type="text/javascript" src="js/form-targets.js"></script>
	<script type="text/javascript" src="js/form-rewards.js"></script>
	<script type="text/javascript" src="js/cutin-generator.js"></script>
	<script type="text/javascript">
		$count_targets = <?php echo $count_targets; ?>;
		$count_rewards = <?php echo $count_rewards; ?>
	</script>
	
<?php
		// Get HTML Bottom Header
		require_once('contents/includes/bottom.php');
	}
	else {
		$ErrorMessage = '<p>Conquista n�o encontrada.<br/> Aguarde, voc� est� sendo redirecionado...</p>';
		require_once('contents/errors/not-found.php');
	}
?>