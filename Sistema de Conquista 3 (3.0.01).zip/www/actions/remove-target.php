<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  .---------------------------------------------------------------.
  .                    A��o de Remo��o de Alvos                   .
  *---------------------------------------------------------------*/
// Required Files
require_once('../config/Config.php');
require_once('../lib/Sql.class.php');
require_once('../lib/Achievement.class.php');
require_once('../lib/Account.class.php');

	$Ach = new Achievements();
	$Auth = new Account();
	
	if( !$Auth->CheckAccess('REM_TARGET') )
		$result = array("error", utf8_encode("Voc� n�o tem autoriza��o para remover alvos."));
	else if( !isset($_POST['id']) || !is_numeric($_POST['id']) )
		$result = array("error", utf8_encode("Identifica��o n�o sinalizada."));
	else if( $Ach->RemoveTarget($_POST['id']) == false )
		$result = array("error", utf8_encode("Erro ao remover o alvo selecionado"));
	else
		$result = array("success", $_POST['id']);
	
	// Return Results
	echo json_encode($result);
	exit;
?>