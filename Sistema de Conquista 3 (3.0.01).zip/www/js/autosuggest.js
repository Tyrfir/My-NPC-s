/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 1.0  .
  .---------------------------------------------------------------.
  .            Script de Sugest�o com JQuery Ajax e PHP           .
  *---------------------------------------------------------------*/
$elementAS=null,$hxrAS=null,jQuery.fn.AutoSuggest=function(e,t){key=e.keyCode||e.which,key>=16&&key<=17||20==key||144==key||key>=37&&key<=40||($elementAS=$(this),$sendAS=null,null!==t&&($sendAS=t),setTimeout(function(){$elementAS.bind("focusout",function(){null!=$hxrAS&&($hxrAS.abort(),$hxrAS=null),1==$(".autosuggest").is(":visible")&&$(".autosuggest").fadeOut("fast")}),$elementAS.AutoSuggestSend("actions/suggest-target.php",$sendAS)},100))},jQuery.fn.AutoSuggestSend=function(e,t){options="search="+$(this).val(),null!==t&&(options+="&"+t);$.ajax({url:e,type:"POST",async:!0,cache:!1,data:options,success:function(e){return offset=$elementAS.offset(),"none"==e||""==e?void(1==$(".autosuggest").is(":visible")&&$(".autosuggest").fadeOut("fast")):($(".autosuggest .boxcontent").html(e),0==$(".autosuggest").is(":visible")&&$(".autosuggest").fadeIn("medium"),$(".autosuggest").css("min-width",$elementAS.width()+24),$(".autosuggest").css("top",offset.top+25),$(".autosuggest").css("left",offset.left),void $(".autosuggest .boxcontent a").bind("click",function(e){e.preventDefault(),nvalue=$(this).attr("value"),$elementAS.val(nvalue)}))},error:function(e,t,s){1==$(".autosuggest").is(":visible")&&$(".autosuggest").fadeOut("medium"),console.log(arguments)}})};