/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 1.0  .
  .---------------------------------------------------------------.
  .            Script de Sugest�o com JQuery Ajax e PHP           .
  *---------------------------------------------------------------*/
$elementAS = null;
$hxrAS = null;
jQuery.fn.AutoSuggest = function(e, args = null) {
	key = e.keyCode || e.which;
	if( (key >= 16 && key <= 17) || key == 20 || key == 144 || (key >= 37 && key <= 40) )
		return;
	
	$elementAS = $(this);
	
	$sendAS = null;
	if( args !== null )
		$sendAS = args;
		
	setTimeout(function() {
		$elementAS.bind("focusout",function() {
			if( $hxrAS != null ) {
				$hxrAS.abort();
				$hxrAS = null;
			}
			if( $(".autosuggest").is(":visible") == true )
				$(".autosuggest").fadeOut("fast");
		});
		
		$elementAS.AutoSuggestSend('actions/suggest-target.php',$sendAS);
	},100);
}

jQuery.fn.AutoSuggestSend = function(file_url, args = null) {
	options = "search="+$(this).val();
	if( args !== null )
		options += "&"+args;
	
	var $hxrAS = $.ajax({
		url: file_url,
		type: 'POST',
		async: true,
		cache: false,
		data: options,
		success: function(result) {
			offset = $elementAS.offset();
			if( result == 'none' || result == '' )
			{
				if( $(".autosuggest").is(":visible") == true )
					$(".autosuggest").fadeOut("fast");
				return;
			}
			
			$(".autosuggest .boxcontent").html(result);
			if( $(".autosuggest").is(":visible") == false )
				$(".autosuggest").fadeIn("medium");
			
			$(".autosuggest").css("min-width",$elementAS.width()+24);
			$(".autosuggest").css("top",offset.top+25);
			$(".autosuggest").css("left",offset.left);
			
			$(".autosuggest .boxcontent a").bind("click", function(e) {
				e.preventDefault();
				nvalue = $(this).attr("value");
				$elementAS.val(nvalue);
			});
		},
		error: function(request, status, error) {
			if( $(".autosuggest").is(":visible") == true )
				$(".autosuggest").fadeOut("medium");
			console.log(arguments);
		}
	});
};