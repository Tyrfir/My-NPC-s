<?php
	if( !defined("MAIN_PAGE") )
		exit;
	
	// Requer esta conectado...
	$Auth->RequireLogin();
	
	// Get Account_id
	$account_id = $Auth->account_id;
	
	// Get HTML Header
	require_once('contents/includes/header.php');
	require_once('contents/includes/menu.php');
?>
	<ol class="breadcrumb breadcrumb-adjust" id="submenus">
	  <li><a href="#main">Informa��es Pessoais</a></li>
	  <li><a href="#contacts">Contato e Redes Sociais</a></li>
	  <li><a href="#customize">Personaliza��o</a></li>
	</ol>
	
	<div class="content page margin-xs-top-10x">
		<div class="container-fluid">
			<div class="row margin-10x-top" id="customize">
				<div class="col-xs-12">
					<h3><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span>&nbsp;&nbsp;Orienta��es</h3>
				</div>
			</div>
			<hr>
			<div class="row margin-20x-top margin-10x-bottom">
				<div class="col-xs-12">
					<div class="alert alert-info">
						<div class="alert-content">
							<label><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span> Ajuda das Kafras</label>
							<p class="no-margin"><strong>Est� com d�vidas sobre as altera��es do seu perfil?</strong></p>
							<p class="no-margin">Clique em Saiba mais e veja o que � necess�rio para estar criando seu perfil.</p>
							<ul class="no-display" id="profile-help">
								<li>M�nimo de caracteres para <strong>Nome</strong> � <strong><?php echo $CharRules['MIN_PROFILE_NAME'] ?></strong> e o M�ximo � <strong><?php echo $CharRules['MAX_PROFILE_NAME'] ?></strong> caracteres.</li>
								<li>M�nimo de caracteres para <strong>Nickname</strong> � <strong><?php echo $CharRules['MIN_PROFILE_NICK'] ?></strong> e o M�ximo � <strong><?php echo $CharRules['MAX_PROFILE_NICK'] ?></strong> caracteres.</li>
								<li>M�nimo de caracteres para <strong>Descri��o</strong> � <strong><?php echo $CharRules['MIN_PROFILE_DESC'] ?></strong> e o M�ximo � <strong><?php echo $CharRules['MAX_PROFILE_DESC'] ?></strong> caracteres.</li>
								<li>O <strong>Avatar</strong> deve estar no m�ximo na resolu��o <strong><?php echo $ProfileCfg['MAX_AVATAR_WIDTH'] ?>x<?php echo $ProfileCfg['MAX_AVATAR_HEIGHT'] ?> pixels</strong>, evite utilizar avatares menores que esta resolu��o para n�o haver aspecto de imagem esticada. As <strong>extens�es</strong> permitida s�o:
									<ul>
								<?php
									foreach( $ProfileCfg['AVATAR_EXTENSIONS'] as $key => $value )
										echo "<li><strong>" . strtoupper($key) . "</strong></li>";
								?>
									</ul>
								</li>
								<li>A <strong>Data de Nascimento</strong> � no formato <strong>DD/MM/AAAA</strong>.</li>
								<li>O <strong>Estado</strong> aonde voc� habita ser� listado de acordo com o <strong>Pa�s</strong>.</li>
								<li>Em campos de <strong>Rede Social</strong> n�o � necess�rio colocar a URL Completa, apenas suas refer�ncia.</li>
							</ul>
							<a href="#" class="profile-help pull-right"><span class="glyphicon glyphicon-plus"></span> Saiba mais</a>
							<div class="clear"></div>
						</div>
						<div class="alert-icon-help-1"></div>
					</div>
				</div>
			</div>
			
			<form id="edit-profile">
			<div class="row margin-10x-top">
				<div class="col-xs-12">
					<div class="alert alert-danger no-display">
						<a href="#" class="close">&times;</a>
						<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> <strong>Erro na Opera��o</strong>
						<div></div>
					</div>
					
					<div class="alert alert-success no-display">
						<a href="#" class="close">&times;</a>
						<span class="glyphicon glyphicon-ok aria-hidden="true"></span> <strong>Sucesso</strong>
						<div></div>
					</div>
				</div>
			</div>
			<div class="row margin-20x-top" id="main">
				<div class="col-xs-12">
					<h3><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;&nbsp;Informa��es Pessoais</h3>
				</div>
			</div>
			<hr>
			<div class="row">
				<div class="col-xs-8">
					<label for="name"><i class="fa fa-address-card" aria-hidden="true"></i> Nome Completo:</label>
					<input type="text" name="name" id="name" class="form-control" value="<?php echo $Profile->name ?>" maxlength="<?php echo $CharRules['MAX_PROFILE_NAME'] ?>" required>
				</div>
				<div class="col-xs-4">
					<label for="type"><i class="fa fa-venus-mars" aria-hidden="true"></i> Sexo:</label>
					<select name="sex" id="sex" class="form-control">
						<option value="0">Masculino</option>
						<option value="1"<?php if( $Profile->sex == 1 ) { echo " selected"; }?>>Feminino</option>
					</select>
				</div>
			</div>
			<div class="row margin-20x-top">
				<div class="col-xs-4">
					<label for="birthdate"><i class="fa fa-calendar" aria-hidden="true"></i> Data de Nascimento:</label>
					<?php
						$birthdate = date_create($Profile->birthdate);
						$birthdate = date_format($birthdate, "Y-m-d");
					?>
					<input type="date" name="birthdate" id="birthdate" class="form-control" value="<?php echo $birthdate; ?>" required>
				</div>
				<div class="col-xs-4">
					<label for="country"><i class="fa fa-globe" aria-hidden="true"></i> Pa�s:</label>
					<select name="country" id="country" class="form-control">
					<?php
						$default_country = $Profile->country;
						foreach( $Country as $key => $value ) {
							if( $default_country === null )
								$default_country = $key;
					?>
						<option value="<?php echo $key?>"<?php if( $Profile->country == $key ) { echo " selected"; }?>><?php echo $key?></option>
					<?php
						}
					?>
					</select>
				</div>
				<div class="col-xs-4">
					<label for="state"><i class="fa fa-globe" aria-hidden="true"></i> Estado:</label>
					<select name="state" id="state" class="form-control">
					<?php
						foreach( $Country as $key => $value ) {
							foreach( $Country[$key] as $key2 => $value2 ) {
								$state = $value2 . " - " .$key2;
								
					?>
						<option value="<?php echo $state ?>"<?php if( $key != $default_country ) { echo ' class="no-display"'; } ?> parent="<?php echo $key ?>""<?php if( $Profile->state == $state ) { echo " selected"; }?>><?php echo $state ?></option>
					<?php
							}
						}
					?>
					</select>
				</div>
			</div>
			
			<div class="row margin-30x-top" id="contacts">
				<div class="col-xs-12">
					<h3><i class="fa fa-share-alt"></i>&nbsp;&nbsp;Contato e Redes Sociais</h3>
				</div>
			</div>
			<hr>
			
			<div class="row">
				<div class="col-xs-4">
					<label for="email"><i class="fa fa-envelope" aria-hidden="true"></i> Email:</label>
					<input type="email" name="email" id="email" class="form-control" maxlength="<?php echo $CharRules['MAX_EMAIL'] ?>" value="<?php echo $Profile->email ?>">
				</div>
				<div class="col-xs-4">
					<label for="skype"><i class="fa fa-skype" aria-hidden="true"></i> Skype:</label>
					<input type="text" name="skype" id="skype" class="form-control" maxlength="<?php echo $CharRules['MAX_SKYPE'] ?>" value="<?php echo $Profile->skype ?>">
				</div>
				<div class="col-xs-4">
					<label for="facebook"><i class="fa fa-facebook-official" aria-hidden="true"></i> Facebook:</label>
					<div class="input-group">
					  <span class="input-group-addon">ID</span>
					  <input type="text" name="facebook" id="facebook" class="form-control" maxlength="<?php echo $CharRules['MAX_FACEBOOK'] ?>" value="<?php echo $Profile->facebook ?>">
					</div>
				</div>
			</div>
			<div class="row margin-20x-top">
				<div class="col-xs-4">
					<label for="twitter"><i class="fa fa-twitter-square" aria-hidden="true"></i> Twitter:</label>
					<div class="input-group">
					  <span class="input-group-addon">@</span>
					  <input type="text" name="twitter" id="twitter" class="form-control" maxlength="<?php echo $CharRules['MAX_TWITTER'] ?>" value="<?php echo $Profile->twitter ?>">
					</div>
				</div>
				<div class="col-xs-4">
					<label for="gplus"><i class="fa fa-google-plus-official" aria-hidden="true"></i> Google+:</label>
					<div class="input-group">
					  <span class="input-group-addon">Perfil</span>
					  <input type="text" name="gplus" id="gplus" class="form-control" max="<?php echo $CharRules['MAX_GOOGLEPLUS']; ?>" value="<?php echo $Profile->googleplus ?>">
					</div>
				</div>
				<div class="col-xs-4">
					<label for="instagram"><i class="fa fa-instagram" aria-hidden="true"></i> Instagram:</label>
					<div class="input-group">
					  <span class="input-group-addon">Perfil</span>
					  <input type="text" name="instagram" id="instagram" class="form-control" max="<?php echo $CharRules['MAX_INSTAGRAM']; ?>" value="<?php echo $Profile->instagram ?>">
					</div>
				</div>
			</div>
			<div class="row margin-20x-top">
				<div class="col-xs-4">
					<label for="linkedin"><i class="fa fa-linkedin-square" aria-hidden="true"></i> Linkedin:</label>
					<div class="input-group">
					  <span class="input-group-addon">Perfil</span>
					  <input type="text" name="linkedin" id="linkedin" class="form-control" maxlength="<?php echo $CharRules['MAX_LINKEDIN'] ?>" value="<?php echo $Profile->linkedin ?>">
					</div>
				</div>
				<div class="col-xs-4">
					<label for="youtube"><i class="fa fa-youtube-square" aria-hidden="true"></i> Youtube:</label>
					<div class="input-group">
					  <span class="input-group-addon">Canal</span>
					  <input type="text" name="youtube" id="youtube" class="form-control" maxlength="<?php echo $CharRules['MAX_YOUTUBE'] ?>" value="<?php echo $Profile->youtube ?>">
					</div>
				</div>
			</div>
			
			<div class="row margin-30x-top" id="customize">
				<div class="col-xs-12">
					<h3><i class="fa fa-paint-brush" aria-hidden="true"></i>&nbsp;&nbsp;Personaliza��o</h3>
				</div>
			</div>
			<hr>
			
			<div class="row margin-20x-top">
				<div class="col-xs-4">
					<label for="name"><i class="fa fa-address-card" aria-hidden="true"></i> Nickname:</label>
					<input type="text" name="nickname" id="nickname" class="form-control" value="<?php echo $Profile->nickname; ?>" maxlength="<?php echo $CharRules['MAX_PROFILE_NICK']; ?>" required>
				</div>
				<div class="col-xs-8">
					<label for="url_avatar"><i class="fa fa-picture-o" aria-hidden="true"></i> Endere�o do Avatar:</label>
					<div id="current_avatar" class="form-control">
						<?php echo $Profile->avatar_url ?>
					</div>
					<div id="avatar_from_url" class="no-display">
						<input type="text" name="url_avatar" id="url_avatar" class="form-control" disabled>
					</div>
					<div id="avatar_upload" class="no-display" >
						<input type="file" name="upload_avatar" id="upload_avatar" class="form-control" disabled>
					</div>
					<label class="radio-inline"><input type="radio" id="avatar_by_url" name="avatar_upload_type" value="0" checked><small>N�o fazer altera��es</small></label>
					<label class="radio-inline"><input type="radio" id="avatar_by_url" name="avatar_upload_type" value="1"><small>Importar de uma URL</small></label>
				<?php
					if( $ProfileCfg['UPLOAD_AVATAR'] ) {
				?>
					<label class="radio-inline"><input type="radio" id="avatar_by_url" name="avatar_upload_type" value="2"><small>Fazer Upload</small></label>
				<?php
					}
				?>
				</div>
			</div>
			<div class="row margin-20x-top">
				<div class="col-xs-12">
					<label for="desc"><i class="fa fa-commenting-o" aria-hidden="true"></i> Descri��o:</label>
					<textarea name="desc" id="desc" class="form-control" maxlength="<?php echo $CharRules['MAX_PROFILE_DESC']; ?>" placeholder="Descreva um pouco mais sobre voc�..." rows="10"><?php echo $Profile->description; ?></textarea>
					<small id="desc_char" class="pull-right">Caracteres: <span>0</span>/<?php echo $CharRules['MAX_PROFILE_DESC'] ?></small>
				</div>
			</div>
			<div class="row margin-20x-top">
				<div class="col-xs-12 text-center">
					<button type="reset" class="btn btn-danger btn-md"><span class="glyphicon glyphicon-repeat" aria-hidden="true"></span> Refazer</button>
					<button type="submit" class="btn btn-success btn-md"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span> Salvar</button>
				</div>
			</div>
			</form>
		</div>
	</div>
	
	<script src="js/nicEdit/nicEdit.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/edit-profile.js"></script>
	<script type="text/javascript">
		$description_max_char = <?php echo $CharRules['MAX_PROFILE_DESC'] ?>;
	</script>
	
	<div class="modal fade upload-loading-bar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-keyboard="false">
	  <div class="modal-dialog">
		<div class="modal-content">
		  <div class="modal-header">
			<h3 class="modal-title">Aguarde!</h3>
		  </div>
		  <div class="modal-body">
			<p>Estamos enviado seu avatar e processando informa��es...</p>
			<div class="progress progress-popup">
				<div class="progress-bar"></div>
			</div>
		  </div>
		</div>
	  </div>
	</div>
	
<?php
	// Get HTML Bottom Header
	require_once('contents/includes/bottom.php');
?>