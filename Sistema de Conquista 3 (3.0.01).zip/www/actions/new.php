<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  .---------------------------------------------------------------.
  .                   A��o de Nova de Conquista                   .
  *---------------------------------------------------------------*/
// Required Files
require_once('../config/Config.php');
require_once('../lib/Sql.class.php');
require_once('../lib/Achievement.class.php');
require_once('../lib/Account.class.php');

$CategoryList = require_once('../config/Category.php');
$CharRules = require_once('../config/CharRules.php');

	$Ach = new Achievements();
	$Auth = new Account();
	
	if( !$Auth->CheckAccess('ACH_NEW') )
		$result = array("error", utf8_encode("Voc� n�o tem autoriza��o para adicionar uma conquista."));
	else if( !isset($_POST['name']) || !trim($_POST['name']) )
		$result = array("name", utf8_encode("Voc� deve entrar com um nome para Conquista."));
	else if( strlen($_POST['name']) < $CharRules['MIN_NAME'] || strlen($_POST['name']) > $CharRules['MAX_NAME'] )
		$result = array("name", utf8_encode(sprintf("Voc� deve entrar entre <strong>%d a %d caracteres</strong> no nome da Conquista.", $CharRules['MIN_NAME'], $CharRules['MAX_NAME'])));
	else if( !isset($_POST['type']) || !is_numeric($_POST['type']) || !array_key_exists($_POST['type'], $CategoryList) )
		$result = array("type", utf8_encode("Voc� deve selecionar um tipo v�lido em sua Conquista."));
	else if( !isset($_POST['icon']) || !trim($_POST['icon']) )
		$result = array("icon", utf8_encode(sprintf("Voc� deve selecionar um �cone v�lido!")));
	else if( !file_exists("../images/icons/{$_POST['icon']}.gif") && !file_exists("../images/icons/{$_POST['icon']}.png") )
		$result = array("icon", utf8_encode("O �cone <strong>{$_POST['icon']}</strong> n�o encontra-se em <strong>images/icons</strong> no formato <strong>PNG ou GIF</strong>."));
	else if( !isset($_POST['ghostmode']) || ($_POST['ghostmode'] < 0 || $_POST['ghostmode'] > 1) )
		$result = array("ghostmode", utf8_encode("Voc� deve selecionar se <strong>Conquista � Fantasma</strong>!"));
	else if( !isset($_POST['status']) || ($_POST['status'] < 0 || $_POST['status'] > 1) )
		$result = array("status", utf8_encode("Voc� deve selecionar a <strong>Situa��o da Conquista</strong>!"));
	else if( !isset($_POST['desc']) )
		$result = array("desc", utf8_encode("Voc� deve entrar com a descri��o da Conquista."));
	else if( strlen($_POST['desc']) < $CharRules['MIN_DESC'] || strlen($_POST['desc']) > $CharRules['MAX_DESC'] )
		$result = array("desc", utf8_encode(sprintf("Voc� deve entrar entre <strong>%d a %d caracteres</strong> na descri��o da Conquista.", $CharRules['MIN_DESC'], $CharRules['MAX_DESC'])));
	else if( ($new_id = $Ach->Create(utf8_decode($_POST['name']), utf8_decode($_POST['icon']), utf8_decode($_POST['desc']), $_POST['type'], $_POST['ghostmode'], $_POST['status'])) != false )
		$result = array("success", utf8_encode("?p=admin/editar-conquista&achievement_id=".$new_id));
	else
		$result = array("submit", utf8_encode("Houve um erro ao inserir a nova conquista."));

	// Return Results
	echo json_encode($result);
	exit;
?>