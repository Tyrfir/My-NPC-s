<?php
@session_start();
@header('Content-type: text/html; charset=iso-8859-1', true);
@ini_set('display_errors',1);
@ini_set('display_startup_erros',1);
date_default_timezone_set('America/Sao_Paulo');
@error_reporting(E_ALL);
class Config {
	/*
		Configura��es do Banco de Dados
	*/
	protected static $sqlServer = array(
			'host' => 'localhost',			// Local aonde est� alocado o Banco de Dados do seu Servidor.
			'user' => 'ragnarok',			// Usu�rio de Conex�o.
			'pass' => 'ragnarok',			// Senha do Usu�rio de Conex�o.
			'base' => 'ragnarok'			// Nome do Banco de Dados.
	);
	
	/*
		Senha de autentica��o do Painel In-Game
		Deve ser a mesma que esteja em achievement.conf
	*/
	public static $ClientPanelPass = 'ACHCSD02122016';
	
	/*
		Configura��es de Previl�gios e Tabelas.
	*/
	public static $groups = array(
			'column' => 'level',			// Coluna da tabela login referente ao n�vel de privil�gio (gamemaster level). Emuladores antigos utiliza o campo level, emuladores novos o campo group_id, verifique na sua tabela login.
			'admin' => 99					// N�vel de Administra��o para Gerenciamento de Conquistas.
	);
	
	/*
		Usar Md5 para Autentica��o de Senha?
			0: Desativado
			1: Ativado
	*/
	public static $useMD5 = 0;
	
	/*
		M�ximo de resultados de conquistas exibido por P�ginas
	*/
	public static $max_rows = 10;
	
	/*
		M�ximo de resultados de ranking exibido por P�ginas
	*/
	public static $rank_max_rows = 30;
	
	/*
		Configura��es de entrega das Recompensas
		Deve estar de acordo com seu servidor, 100 � 100%.
	*/
	public static $reward_rate = 100;
	
	/*
		Mostrar sempre as recompensas em mesmo quando as conquistas n�o est�o descobertas?
			1: sim
			0: n�o
	*/
	public static $show_rewards = 1;
	
	/*
		Mostrar sempre os progressos e objetivos mesmo quando as conquistas n�o est�o descobertas?
			1: sim
			0: n�o
	*/
	public static $show_objetive = 1;
	
	/*
		Endere�o Principal do Site
		Isto inclui a pasta aonde se encontra o Painel de Conquista!
	*/
	public static $WebSite = 'http://127.0.0.1/achievementsv2';
	
	/*
		Links:
			- Registro
			- Recupera��o de Senha
	*/
	public static $CPLinks = array(
		'register' => 'http://127.0.0.1/FluxCP/?module=account&action=create',
		'recovery' => 'http://127.0.0.1/FluxCP/?module=account&action=resetpass'
	);

	/*
		Rela��o a DataBase On-line para Refer�ncia
		Est� pr�-configurado para funcionar com o FluxCP.
	*/
	public static $roDB = array(
		'url' => 'http://127.0.0.1/FluxCP/',			// Endere�o do Seu FluxCP (Adicione / no final).
		'item' => '?module=item&action=view&id=',		// Par�metros de URL para visualiza��o de itens.
		'mob' => '?module=monster&action=view&id=',		// Par�metros de URL para visualiza��o de monstros.
	);
	
	/*
		M�ximo de Sugest�es em Formul�rios de Cadastro/Pesquisa
	*/
	public static $MaxSuggest = 10;
	
	/*
		Prefixo para o nome de Cutins de Conquistas.
		Exemplo:
			* conquista_<n_gerado>
	*/
	public static $cutin_prefix = 'conquista_';
	
	/*
		Template
	*/
	public static $TemplateDefault = 'OrangeGreen';
}
?>