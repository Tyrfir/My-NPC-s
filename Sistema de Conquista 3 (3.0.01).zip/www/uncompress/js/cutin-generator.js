/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  .---------------------------------------------------------------.
  .                       Gerador de Cutin                        .
  *---------------------------------------------------------------*/
$("#cutin-generator #wdt").bind("change focusout", function() {
	$(this).CutinResize();
});

$("#cutin-generator #wdt").keydown(function(e) {
	if( e.keyCode == 8 || e.keyCode == 37 || e.keyCode == 38 || e.keyCode == 39 || e.keyCode == 40 )
		return true;
	
	setTimeout(function() { 
		$(this).CutinResize();
	},300);
});

$("#cutin-generator #showreward").change(function() {
	$(this).ShowReward();
});

$("#cutin-generator #showrate").change(function() {
	$(this).ShowRate();
});

$("#cutin-generator #defaultcutin").change(function() {
	$(this).DefaultCutin();
});

$("#cutin-generator #achievement_id").change(function() {
	$('#reload-cutin').ReloadCutin($(this).val());
});

$cutin_min_width = 390;
$cutin_max_width = 700;

jQuery.fn.ShowReward = function() {
	if( ($(this).is(":checked") == false && $("#cutin-generator .table-conquest .base-bottom .table-reward").is(":visible") == true) || ($(this).is(":checked") == true && $("#cutin-generator .table-conquest .base-bottom .table-reward").is(":visible") == false) ) {
		$("#cutin-generator .table-conquest .base-bottom p").slideToggle("medium");
		$("#cutin-generator .table-conquest .base-bottom .table-reward").slideToggle("medium");
		$cutin_min_width = 390;
		
		if( $("#cutin-generator #showrate").is(":checked") == true )
			$cutin_min_width = 480;
	}
	
	setTimeout(function() { 
		$(this).CutinResize();
	},300);
}

jQuery.fn.ShowRate = function() {
	if( $(this).is(":checked") == false )
	{
		$cutin_min_width = 390;
		$('#cutin-generator .table-conquest .base-bottom .table-reward').find('span[class="drop_chance"]').each(function(){
			if( $(this).is(":visible") == true )
				$(this).fadeOut(0);
		});
	}
	else {
		$cutin_min_width = 480;
		$('#cutin-generator .table-conquest .base-bottom .table-reward').find('span[class="drop_chance"]').each(function(){
			if( $(this).is(":visible") == false )
				$(this).fadeIn(0);
		});
	}
	
	setTimeout(function() { 
		$(this).CutinResize();
	},300);
}

jQuery.fn.DefaultCutin = function() {
	if( $(this).is(":checked") == false )
		$("#cutin-generator .table-conquest").removeClass("game-window-cutin");
	else
		$("#cutin-generator .table-conquest").addClass("game-window-cutin");

	setTimeout(function() { 
		$(this).CutinResize();
	},300);
}

jQuery.fn.CutinResize = function() {
	$wdt = $("#cutin-generator #wdt").val();
	$hgt = $(".cutin .table-conquest").height()+2;

	if( $wdt < $cutin_min_width )
		$wdt = $cutin_min_width;
	if( $wdt > $cutin_max_width )
		$wdt = $cutin_max_width;
	
	$bdesc = $wdt-90;
	
	$("#cutin-generator #wdt").val($wdt);
	
	$(".cutin .table-conquest").css("width", $wdt+"px");
	$(".cutin .table-conquest .base-desc").css("width", $bdesc+"px");
	$("#cutin-generator #hgt").val($hgt);
}

$reloadCutinElement = null;
jQuery.fn.ReloadCutinReward = function(id) {
	if( $reloadCutinElement != null )
		return false;
	
	$reloadCutinElement = $(this);
	if( $reloadCutinElement == null )
		return false;
	
	$.ajax({
		url: 'actions/reload-cutin-rewards.php',
		type: 'POST',
		async: true,
		cache: false,
		data: 'achievement_id='+id,
		success: function(result) {
			if( result == "error" )
				return false;
			
			$reloadCutinElement.html(result);
			$reloadCutinElement = null;
			return true;
		},
		error: function(request, status, error) {
			$reloadCutinElement = null;
			console.log(arguments);
			return false;
		}
	});
}

jQuery.fn.ReloadCutin = function(id) {
	if( $reloadCutinElement != null )
		return false;
	
	$reloadCutinElement = $(this);
	if( $reloadCutinElement == null )
		return false;
	
	$.ajax({
		url: 'actions/reload-cutin.php',
		type: 'POST',
		async: true,
		cache: false,
		data: 'achievement_id='+id,
		success: function(result) {
			if( result == "error" )
				return false;
			
			$reloadCutinElement.html(result);
			$reloadCutinElement = null;
			$(this).CutinResize();
			$("#showreward").ShowReward();
			$("#showrate").ShowRate();
			$("#defaultcutin").DefaultCutin();
			return true;
		},
		error: function(request, status, error) {
			$reloadCutinElement = null;
			console.log(arguments);
			return false;
		}
	});
}

$('#cutin-generator .table-conquest .base-bottom .table-reward').find('span[class="drop_chance"]').each(function(){
	$(this).fadeOut(0);
});

$("#cutin-generator .table-conquest").ready(function() {
	$(this).CutinResize();
});