<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  .---------------------------------------------------------------.
  .                 A��o de Remo��o de Conquistas                 .
  *---------------------------------------------------------------*/
// Required Files
require_once('../config/Config.php');
require_once('../lib/Sql.class.php');
require_once('../lib/Achievement.class.php');
require_once('../lib/Account.class.php');

	$Ach = new Achievements();
	$Auth = new Account();
	
	if( !$Auth->CheckAccess('ACH_REMOVE') )
		$result = array("error", utf8_encode("Voc� n�o tem autoriza��o para remover conquistas."));
	else if( !isset($_POST['id']) || !is_numeric($_POST['id']) )
		$result = array("error", utf8_encode("Identifica��o n�o sinalizada."));
	else {
		$ach_name = $Ach->getInfo($_POST['id'], 'name');
		$errors = $Ach->Remove($_POST['id']);
		
		if( in_array(0, $errors) )
		{
			$result = array("error", utf8_encode(sprintf("<p>Erro ao remover a <strong>conquista %s</strong> da tabela de banco de dados.</p>", $ach_name)));
			echo json_encode($result);
			exit;
		}
		
		$message_tbl = array('Remo��o da Conquista', 'Atualiza��o de Ranking', 'Remo��o de Dados de Jogadores.', 'Remo��o de Progresso de Jogadores.', 'Remo��o de Requisitos.', 'Remo��o de Recompensas.');
		$result_msg = "";
		for( $i=0; $i < count($message_tbl); $i++ )
			$result_msg .= sprintf("<li><span class=\"glyphicon %s\" aria-hidden=\"true\"></span> %s</li>", (in_array($i,$errors)?"glyphicon-remove":"glyphicon-ok"), $message_tbl[$i]);
		
		$result_msg = sprintf("<p>Progresso de remo��o da Conquista <strong>%s</strong> conclu�do: <ul>%s</ul></p>", $ach_name, $result_msg);
		$result = array("success", utf8_encode($result_msg));
	}
	
	// Return Results
	echo json_encode($result);
	exit;
?>