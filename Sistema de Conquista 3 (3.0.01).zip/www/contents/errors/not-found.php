<?php
	if( !defined("MAIN_PAGE") )
		exit;
	
	require_once('contents/includes/header.php');
	
	$help_rand = rand(1,6);
?>
	<div class="container margin-20x-top">
		<div class="row">
			<div class="col-xs-12 col-sm-6 col-sm-push-3">
				<div class="alert alert-warning" role="alert">
					 <h4><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> Ooops!</h4>
					 <?php echo $ErrorMessage; ?>
				</div>
				<div class="alert-icon-help-<?php echo $help_rand; ?>"></div>
			</div>
		</div>
	</div>
	
	<script type="text/javascript">
		setTimeout(function() {
			window.location = "?p=perfil/visualizar";
		},5000);
	</script>
  </body>	
</html>
	