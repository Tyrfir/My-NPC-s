<?php
	if( !defined("MAIN_PAGE") )
		exit;

	if( !$Auth->CheckSession() )
		$Auth->RequireLogin();
	
	$account_id = $_SESSION['account_id'];
	
	// Get HTML Header
	require_once("includes/header.php");
	require_once("includes/menu.php");
	
	// Paginator
	$paginator = !isset($_GET['page']) || $_GET['page'] == 0 ? 1 : $_GET['page'];
	
	// Load Achievements
	$ghost = $Auth->CheckAccess('ACH_VIEW_GHOST')?2:0;
	$init = ($paginator-1)*Config::$max_rows;
	$vstatus = $Auth->CheckAccess('ACH_VIEW_DISABLE')?2:1;
	$Ach->Load($account_id,$key,$vstatus,$status,$type,$target_type,$target_ref,$target_opt,$target_value,$ghost,$init);

	if( $Ach->achievements_count )
	{
?>
	<div class="content" id="achievement-list">
<?php
		for( $i=0, $a = 0; $i < $Ach->achievements_count; $i++ )
		{
			// Preparando Exibi��o da Conquista no Painel.
			$achievement_id = $Ach->achievements['id'][$i];
			$achievement_type = $Ach->achievements['type'][$i];
			$data_status = $Ach->achievements['status'][$i];
			$date = $Ach->achievements['date'][$i];
							
			$icon = $Ach->achievements['icon'][$i];
				
			if( file_exists("images/icons/{$icon}.png") )
				$img = "images/icons/{$icon}.png";
			else if( file_exists("images/icons/{$icon}.gif") )
				$img = "images/icons/{$icon}.gif";
			else
				$img = "images/null.png";
					
			$rewards = "";
			$targets = "";
					
			if( $Ach->rewards[$achievement_id]['count'] )
				$rewards = $Tpl->CreateRewardList($Ach->rewards[$achievement_id]);
			
			if( $Ach->targets[$achievement_id]['count'] )
				$targets = $Tpl->CreateTargetList($Ach->targets[$achievement_id]);
							
?>
			<div class="row">
				<div class="col-xs-12">
					<div class="table-conquest">
						<div class="base-top"><?php echo $Ach->achievements['name'][$i]; ?></div>
						<div class="base-image"><img src="<?php echo $img; ?>" class="img-<?php echo $Ach->achievements['icon'][$i];?>" /></div>
						<div class="base-desc"><?php echo $Ach->achievements['desc'][$i]; ?></div>
						<div class="base-bottom">
						<?php if( Config::$show_rewards || $data_status > -1 ) { ?>
							<a class="pull-left" data-toggle="modal" data-target="#reward-<?php echo $achievement_id ?>">Recompensas</a>
						<?php } ?>
						<?php if( Config::$show_objetive || $data_status > -1 ) { ?>
							<a class="pull-right" data-toggle="modal" data-target="#targets-<?php echo $achievement_id ?>"><?php echo $data_status>=0?"Completada em: <span class=\"reset-color\">{$date}</span>":"Progresso"; ?></a>
						<?php } ?>
						</div>
		<?php
			if( $Auth->CheckSession() && ($Auth->CheckAccess('ACH_EDIT') || $Auth->CheckAccess('ACH_REMOVE')) ) {
		?>
						<div class="base-tools">
							<ul>
		<?php
				if( $Auth->CheckAccess('ACH_EDIT') ) {
		?>
								<li><a href="?p=admin/editar-conquista&achievement_id=<?php echo $achievement_id ?>"><span class="glyphicon glyphicon-cog"></span></a></li>
		<?php
				}
				
				if( $Auth->CheckAccess('ACH_REMOVE') ) {
		?>
								<li><a href="#" action="remove-achievement" data-target="<?php echo $achievement_id ?>" data-name="<?php echo $Ach->achievements['name'][$i]; ?>"><span class="glyphicon glyphicon-trash"></span></a></a></li>
		<?php
				}
		?>
							</ul>
						</div>
		<?php
			}
		?>
						<div class="clear"></div>
					</div>
					
		
		<?php if( Config::$show_rewards || $data_status > -1 ) { ?>
					<div id="reward-<?php echo $achievement_id ?>" class="modal fade modal-reward">
					   <div class="modal-dialog">
							<!-- Modal content-->
							<div class="modal-content">
							  <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">&times;</button>
								<h4>Recompensas: <?php echo $Ach->achievements['name'][$i]; ?></h4>
							  </div>
							  <div class="modal-body">
								<?php echo $rewards; ?>
							  </div>
							</div>
						</div>
					</div>
		<?php } ?>
		
		<?php if( Config::$show_objetive || $data_status > -1 ) { ?>
					<div id="targets-<?php echo $achievement_id ?>" class="modal fade modal-reward">
					   <div class="modal-dialog">
						<!-- Modal content-->
							<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal">&times;</button>
									<h4>Objetivos: <?php echo $Ach->achievements['name'][$i]; ?></h4>
								</div>
								<div class="modal-body">
									<p><?php echo $TargetInfo[$achievement_type] ?></p>
									<?php echo $targets; ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php } ?>
<?php
		}
	}
	else {
		$help_rand = rand(1,6);
?>
		<div class="content no-background margin-20x-top">
			<div class="row">
				<div class="col-xs-12">
					<div class="alert alert-warning" role="alert">
						 <h4><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> Ooops!</h4>
						 <p>O que voc� procura n�o foi encontrado.<br/> Por favor, redefina sua busca...</p>
					</div>
					<div class="alert-icon-help-<?php echo $help_rand; ?>"></div>
				</div>
			</div>
		</div>
<?php
	}
?>
	</div>
<?php
	if( $Auth->CheckAccess('ACH_REMOVE') ) {
?>
	<div id="remove-achievement" class="modal-remove modal fade" role="dialog">
	  <div class="modal-dialog">

		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<h4 class="modal-title">Confirme a opera��o!</h4>
		  </div>
		  <div class="modal-body">
			<p>Tem certeza que deseja remover a conquista <strong id="remove-name"></strong>?</p>
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-success">Sim</button>
			<button type="button" class="btn btn-danger" data-dismiss="modal">N�o</button>
		  </div>
		</div>

	  </div>
	</div>
	
	<div id="remove-result" class="modal fade" role="dialog">
	  <div class="modal-dialog">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<h4 class="modal-title"></h4>
		  </div>
		  <div class="modal-body"></div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
		  </div>
		</div>

	  </div>
	</div>
	
	<script type="text/javascript" src="js/achievement-manager.js"></script>
<?php
	}
?>
	<div class="content no-background">
		<div class="row">
			<div class="col-xs-12 text-center navbar">
			<?php
				// CreateNavBar
				if( $Ach->achievements_total > Config::$max_rows ) {
					$Tpl->createNavBar($paginator,$Ach->achievements_total,Config::$max_rows,$_GET);
					$Tpl->showNavigation();
				}
			?>
			</div>
		</div>
	</div>
	
<?php
	// Include Footer
	require_once("includes/bottom.php");
?>