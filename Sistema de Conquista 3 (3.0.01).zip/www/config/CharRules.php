<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  *---------------------------------------------------------------*/
// Regras de Caracteres utilizado em formul�rios.
//
// ! As regras de caracteres existe para prevenir que campos de formul�rios
//   ultrapasse dos valores aceit�veis de colunas nas Tabelas do SQL.
//	 Preste muita aten��o ao alterar esses valores. !
return array(
	'MIN_NAME'        => 4,				// M�nimo de Caracteres para Nome de Conquistas.
	'MAX_NAME'         => 50,			// M�ximo de Caracteres para Nome de Conquistas.
	'MIN_DESC'         => 10,			// M�nimo de Caracteres para Descri��o de Conquistas.
	'MAX_DESC'         => 200,			// M�ximo de Caracteres para Descri��o de Conquistas.
	'MIN_TARGET'       => 1,			// M�nimo de Caracteres para Alvos de Conquistas.
	'MAX_TARGET'       => 50,			// M�ximo de Caracteres para Alvos de Conquistas.
	'MIN_TARGET_VALUE' => 1,			// Valor m�nimo para valores de Alvos.
	'MAX_TARGET_VALUE' => 99999999999,	// Valor m�ximo para valores de Alvos.
	'MIN_OBJECT'       => 1,			// M�nimo de Caracteres para Objetos de Recompensa.
	'MAX_OBJECT'       => 32,			// M�nimo de Caracteres para Objetos de Recompensa.
	'MIN_OBJECT_VALUE' => 1,			// Valor m�nimo para valores de Objetos.
	'MAX_OBJECT_VALUE' => 99999999999,	// Valor m�ximo para valores de Objetos.
	'MIN_OBJECT_DESC'  => 4,			// M�nimo de Caracteres para Descri��o de Objetos.
	'MAX_OBJECT_DESC'  => 50,			// M�ximo de Caracteres para Descri��o de Objetos.
	'MIN_PROFILE_NAME' => 4,			// M�nimo de Caracteres para o Nome no Perfil.
	'MAX_PROFILE_NAME' => 50,			// M�ximo de Caracteres para o Nome no Perfil.
	'MIN_PROFILE_NICK' => 4,			// M�nimo de Caracteres para o Nick no Perfil.
	'MAX_PROFILE_NICK' => 20,			// M�ximo de Caracteres para o Nick no Perfil.
	'MIN_PROFILE_DESC' => 10,			// M�nimo de Caracteres para a Descri��o no Perfil.
	'MAX_PROFILE_DESC' => 400,			// M�ximo de Caracteres para a Descri��o no Perfil.
	
	// Outros
	'MAX_EMAIL'        => 36,			// M�ximo de Caracteres em E-mail.
	'MAX_SKYPE'        => 36,			// M�ximo de Caracteres de ID do Facebook.
	'MAX_FACEBOOK'     => 32,			// M�ximo de Caracteres de ID do Facebook.
	'MAX_TWITTER'      => 32,			// M�ximo de Caracteres de ID do Twitter.
	'MAX_GOOGLEPLUS'   => 32,			// M�ximo de Caracteres de ID do Google Plus.
	'MAX_INSTAGRAM'    => 32,			// M�ximo de Caracteres de ID do Google Plus.
	'MAX_LINKEDIN'     => 32,			// M�ximo de Caracteres de ID do Linkedin.
	'MAX_YOUTUBE'      => 32,			// M�ximo de Caracteres de ID do Youtube.
);