<?php
/*.---------------------------------------------------------------.
  .   ____                          __                            .
  .  /\  _`\                       /\ \__  __                     .
  .  \ \ \/\_\  _ __    __     __  \ \ ,_\/\_\  __  __     __     .
  .   \ \ \/_/_/\`'__\/'__`\ /'__`\ \ \ \/\/\ \/\ \/\ \  /'__`\   .
  .    \ \ \s\ \ \ \//\  __//\ \s\.\_\ \ \_\ \ \ \ \_/ |/\  __/   .
  .     \ \____/\ \_\\ \____\ \__/.\_\\ \__\\ \_\ \___/ \ \____\  .
  .      \/___/  \/_/ \/____/\/__/\/_/ \/__/ \/_/\/__/   \/____/  .
  .                                                               .
  .          2014~2016 � Creative Services and Developent         .
  .                    www.creativesd.com.br                      .
  .---------------------------------------------------------------.
  .                    Sistema de Conquistas                      .
  .---------------------------------------------------------------.
  . Autor: Romulo SM (sbk_)                          Vers�o: 3.0  .
  .---------------------------------------------------------------.
  .                       Edi��o de Perfil                        .
  *---------------------------------------------------------------*/
// Required Files
require_once('../config/Config.php');
require_once('../lib/Sql.class.php');
require_once('../lib/Achievement.class.php');
require_once('../lib/Numbers.class.php');
require_once('../lib/Account.class.php');
require_once('../lib/Profile.class.php');

$RewardsType = require_once('../config/RewardsType.php');
$BonusStatus = require_once('../config/BonusStatus.php');
$CharRules = require_once('../config/CharRules.php');
$ProfileCfg = require_once('../config/Profile.php');

	$Ach = new Achievements();
	$Auth = new Account();
	$Profile = new Profile();
	
	$result = array();

	$Auth = new Account();
	
	if( !$Auth->CheckSession() )
		$result = array("error", utf8_encode("Voc� n�o est� conectado para efetuar edi��o no seu perfil."));
	else if( !isset($_POST['name']) || !trim($_POST['name']) )
		$result = array("name", utf8_encode("Voc� deve entrar com seu <strong>nome</strong>."));
	else if( strlen($_POST['name']) < $CharRules['MIN_PROFILE_NAME'] || strlen($_POST['name']) > $CharRules['MAX_PROFILE_NAME'] )
		$result = array("name", utf8_encode(sprintf("O seu <strong>nome</strong> deve conter entre <strong>%d a %d</strong> caracteres.", $CharRules['MIN_PROFILE_NAME'], $CharRules['MAX_PROFILE_NAME'])));
	else if( !isset($_POST['sex']) || !is_numeric($_POST['sex']) || $_POST['sex'] < 0 || $_POST['sex'] > 1 )
		$result = array("sex", utf8_encode("Voc� deve selecionar um <strong>sexo</strong> v�lido."));
	else if( !isset($_POST['birthdate']) || strlen($_POST['birthdate']) < 10 )
		$result = array("birthdate", utf8_encode("Voc� deve entrar com uma <strong>data de nascimento</strong> v�lida no formato <strong>DD/MM/AAAA</strong>."));
	else if( isset($_POST['email']) && strlen($_POST['email']) > $CharRules['MAX_EMAIL'] )
		$result = array("email", utf8_encode(sprintf("O <strong>E-mail</strong> do seu <strong>Perfil</strong> deve conter no m�ximo <strong>%d caracteres</strong>.", $CharRules['MAX_EMAIL'])));
	else if( isset($_POST['email']) && substr_count($_POST['email'], ' ') > 0 )
		$result = array("email", utf8_encode("Voc� n�o pode utilizar espa�o no seu <strong>E-mail</strong>."));
	else if( isset($_POST['email']) && trim($_POST['email']) && (substr_count($_POST['email'], '@') >= 2 || substr_count($_POST['email'], '@') <= 0)  )
		$result = array("email", utf8_encode("Voc� deve entrar com um <strong>E-mail</strong> v�lido."));
	else if( isset($_POST['skype']) && strlen($_POST['skype']) > $CharRules['MAX_SKYPE'] )
		$result = array("skype", utf8_encode(sprintf("O <strong>Contato</strong> do seu <strong>Skype</strong> deve conter no m�ximo <strong>%d caracteres</strong>.", $CharRules['MAX_SKYPE'])));
	else if( isset($_POST['skype']) && substr_count($_POST['skype'], ' ') > 0 )
		$result = array("skype", utf8_encode("Voc� n�o pode utilizar espa�o no seu <strong>Contato de Skype</strong>."));
	else if( isset($_POST['facebook']) && strlen($_POST['facebook']) > $CharRules['MAX_FACEBOOK'] )
		$result = array("facebook", utf8_encode(sprintf("O <strong>ID</strong> do seu <strong>Perfil do Facebook</strong> deve conter no m�ximo <strong>%d caracteres</strong>.", $CharRules['MAX_FACEBOOK'])));
	else if( isset($_POST['facebook']) && substr_count($_POST['facebook'], ' ') > 0 )
		$result = array("facebook", utf8_encode("Voc� n�o pode utilizar espa�o no seu <strong>Perfil do Facebook</strong>."));
	else if( isset($_POST['twitter']) && strlen($_POST['twitter']) > $CharRules['MAX_TWITTER'] )
		$result = array("twitter", utf8_encode(sprintf("O <strong>ID</strong> do seu <strong>Perfil do Twitter</strong> deve conter no m�ximo <strong>%d caracteres</strong>.", $CharRules['MAX_TWITTER'])));
	else if( isset($_POST['twitter']) && substr_count($_POST['twitter'], ' ') > 0 )
		$result = array("twitter", utf8_encode("Voc� n�o pode utilizar espa�o no seu <strong>Perfil do Twitter</strong>."));
	else if( isset($_POST['gplus']) && strlen($_POST['gplus']) > $CharRules['MAX_GOOGLEPLUS'] )
		$result = array("gplus", utf8_encode(sprintf("O <strong>ID</strong> do seu <strong>Perfil do Google+</strong> deve conter no m�ximo <strong>%d caracteres</strong>.", $CharRules['MAX_GOOGLEPLUS'])));
	else if( isset($_POST['gplus']) && substr_count($_POST['gplus'], ' ') > 0 )
		$result = array("gplus", utf8_encode("Voc� n�o pode utilizar espa�o no seu <strong>Perfil do Google+</strong>."));
	else if( isset($_POST['gplus']) && trim($_POST['gplus']) && !is_numeric($_POST['gplus']) )
		$result = array("gplus", utf8_encode("Voc� deve utilizar somente n�meros para o seu <strong>Perfil do Google+</strong>."));
	else if( isset($_POST['instagram']) && strlen($_POST['instagram']) > $CharRules['MAX_INSTAGRAM'] )
		$result = array("instagram", utf8_encode(sprintf("O <strong>ID</strong> do seu <strong>Perfil do Instagram</strong> deve conter no m�ximo <strong>%d caracteres</strong>.", $CharRules['MAX_INSTAGRAM'])));
	else if( isset($_POST['instagram']) && substr_count($_POST['instagram'], ' ') > 0 )
		$result = array("instagram", utf8_encode("Voc� n�o pode utilizar espa�o no seu <strong>Perfil do Instagram</strong>."));
	else if( isset($_POST['linkedin']) && strlen($_POST['linkedin']) > $CharRules['MAX_LINKEDIN'] )
		$result = array("linkedin", utf8_encode(sprintf("O <strong>ID</strong> do seu <strong>Perfil do Linkedin</strong> deve conter no m�ximo <strong>%d caracteres</strong>.", $CharRules['MAX_LINKEDIN'])));
	else if( isset($_POST['linkedin']) && substr_count($_POST['linkedin'], ' ') > 0 )
		$result = array("linkedin", utf8_encode("Voc� n�o pode utilizar espa�o no seu <strong>Perfil do Linkedin</strong>."));
	else if( !isset($_POST['nickname']) || !trim($_POST['nickname']) )
		$result = array("nickname", utf8_encode("Voc� deve entrar com seu <strong>nick</strong>."));
	else if( strlen($_POST['nickname']) < $CharRules['MIN_PROFILE_NICK'] || strlen($_POST['nickname']) > $CharRules['MAX_PROFILE_NICK'] )
		$result = array("nickname", utf8_encode(sprintf("O seu <strong>nick</strong> deve conter entre <strong>%d a %d</strong> caracteres.", $CharRules['MIN_PROFILE_NICK'], $CharRules['MAX_PROFILE_NICK'])));
	else {
		// Obtem algumas informa��es.
		$account_id = $Auth->account_id;
		
		// Continua checando os requisitos
		$name = $_POST['name'];
		$nickname = $_POST['nickname'];
		$sex = $_POST['sex'];
		$birthdate = $_POST['birthdate'];
		$country = isset($_POST['country'])&&trim($_POST['country'])?$_POST['country']:null;
		$state = isset($_POST['state'])&&trim($_POST['state'])?$_POST['state']:null;
		$email = isset($_POST['email'])&&trim($_POST['email'])?$_POST['email']:null;
		$skype = isset($_POST['skype'])&&trim($_POST['skype'])?$_POST['skype']:null;
		$facebook = isset($_POST['facebook'])&&trim($_POST['facebook'])?$_POST['facebook']:null;
		$twitter = isset($_POST['twitter'])&&trim($_POST['twitter'])?str_replace("@", "", $_POST['twitter']):null;
		$googlep = isset($_POST['gplus'])&&trim($_POST['gplus'])?$_POST['gplus']:null;
		$instagram = isset($_POST['instagram'])&&trim($_POST['instagram'])?$_POST['instagram']:null;
		$linkedin = isset($_POST['linkedin'])&&trim($_POST['linkedin'])?$_POST['linkedin']:null;
		$youtube = isset($_POST['youtube'])&&trim($_POST['youtube'])?$_POST['youtube']:null;
		
		if( !$ProfileCfg['DUPLICATE']['NAME'] && $Profile->CheckDuplicate($account_id, 0, $name) )
		{
			$result = array("name", utf8_encode("Este <strong>nome</strong> j� est� sendo utilizado por outro jogador."));
			echo json_encode($result);
			exit;
		}
		
		if( !$ProfileCfg['DUPLICATE']['NICKNAME'] && $Profile->CheckDuplicate($account_id, 1, $nickname) )
		{
			$result = array("nickname", utf8_encode("Este <strong>nickname</strong> j� est� sendo utilizado por outro jogador."));
			echo json_encode($result);
			exit;
		}
		
		if( !$ProfileCfg['DUPLICATE']['EMAIL'] && $email !== null && $Profile->CheckDuplicate($account_id, 2, $email) )
		{
			$result = array("email", utf8_encode("Este <strong>E-mail</strong> j� est� sendo utilizado por outro jogador."));
			echo json_encode($result);
			exit;
		}
		
		if( !$ProfileCfg['DUPLICATE']['SKYPE'] && $skype !== null && $Profile->CheckDuplicate($account_id, 3, $skype) )
		{
			$result = array("gplus", utf8_encode("Este <strong>Skype</strong> j� est� sendo utilizado por outro jogador."));
			echo json_encode($result);
			exit;
		}
		
		if( !$ProfileCfg['DUPLICATE']['FACEBOOK'] && $facebook !== null && $Profile->CheckDuplicate($account_id, 4, $facebook) )
		{
			$result = array("facebook", utf8_encode("Este <strong>Facebook</strong> j� est� sendo utilizado por outro jogador."));
			echo json_encode($result);
			exit;
		}
		
		if( !$ProfileCfg['DUPLICATE']['TWITTER'] && $twitter !== null && $Profile->CheckDuplicate($account_id, 5, $twitter) )
		{
			$result = array("twitter", utf8_encode("Este <strong>Perfil do Twitter</strong> j� est� sendo utilizado por outro jogador."));
			echo json_encode($result);
			exit;
		}
		
		if( !$ProfileCfg['DUPLICATE']['GOOGLEP'] && $googlep !== null && $Profile->CheckDuplicate($account_id, 6, $googlep) )
		{
			$result = array("gplus", utf8_encode("Este <strong>Perfil do Google+</strong> j� est� sendo utilizado por outro jogador."));
			echo json_encode($result);
			exit;
		}
		
		if( !$ProfileCfg['DUPLICATE']['GOOGLEP'] && $instagram !== null && $Profile->CheckDuplicate($account_id, 7, $instagram) )
		{
			$result = array("gplus", utf8_encode("Este <strong>Instagram</strong> j� est� sendo utilizado por outro jogador."));
			echo json_encode($result);
			exit;
		}
		
		if( !$ProfileCfg['DUPLICATE']['LINKEDIN'] && $linkedin !== null && $Profile->CheckDuplicate($account_id, 8, $linkedin) )
		{
			$result = array("linkedin", utf8_encode("Este <strong>Perfil do Linkedin</strong> j� est� sendo utilizado por outro jogador."));
			echo json_encode($result);
			exit;
		}
		
		if( !$ProfileCfg['DUPLICATE']['YOUTUBE'] && $youtube !== null && $Profile->CheckDuplicate($account_id, 9, $youtube) )
		{
			$result = array("youtube", utf8_encode("Este <strong>Canal de Youtube</strong> j� est� sendo utilizado por outro jogador."));
			echo json_encode($result);
			exit;
		}
		
		$description = isset($_POST['desc']) ? urldecode($_POST['desc']) : null;
		$description_text = strip_tags($description);
		$description_text = preg_replace("/&#?[a-z0-9]+;/i","",$description_text);
		
		if( $description && trim($description_text) )
		{
			if( strlen($description_text) < $CharRules['MIN_PROFILE_DESC'] || strlen($description_text) > $CharRules['MAX_PROFILE_DESC'] )
			{
				$result = array(".nicEdit-main", utf8_encode(sprintf("Sua <strong>descri��o</strong> deve conter entre <strong>%d a %d caracteres</strong>.", $CharRules['MIN_PROFILE_DESC'], $CharRules['MAX_PROFILE_DESC'])));
				echo json_encode($result);
				exit;
			}
		}
		
		if( !trim($description_text) )
			$description = null;
		
		// Upload de Avatares
		if( isset($_POST['avatar_upload_type']) )
		{
			$upload_type = $_POST['avatar_upload_type'];
			$url_avatar = $old_avatar = $Profile->getInfo($account_id, 'avatar');
			if( $upload_type == 1 )
			{
				// Checa se o Avatar � valido.
				if( isset($_POST['url_avatar']) && trim($_POST['url_avatar']) )
				{
					$url_avatar = urldecode($_POST['url_avatar']);
					if( parse_url($url_avatar, PHP_URL_SCHEME) === null )
						$url_avatar = "http://".$url_avatar;
					
					@list($width,$height,$type) = getimagesize($url_avatar);
					if( !$type ) {
						if( strpos($url_avatar,"http") )
							$url_avatar = str_replace("http://", "https://", $url_avatar);
						else
							$url_avatar = str_replace("https://", "http://", $url_avatar);
						
						@list($width,$height,$type) = getimagesize($url_avatar);
						if( !$type ) {
							$result = array("url_avatar", utf8_encode("Voc� deve entrar com um endere�o v�lido do seu <strong>avatar</strong>."));
							echo json_encode($result);
							exit;
						}
					}
					
					if( $width > $ProfileCfg['MAX_AVATAR_WIDTH'] || $height > $ProfileCfg['MAX_AVATAR_HEIGHT'] )
					{
						$result = array("url_avatar", utf8_encode(sprintf("Seu <strong>avatar</strong> deve conter no m�ximo <strong>%dx%d pixels</strong>.", $ProfileCfg['MAX_AVATAR_WIDTH'], $ProfileCfg['MAX_AVATAR_HEIGHT'])));
						echo json_encode($result);
						exit;
					}
					
					$extension = null;
					foreach( $ProfileCfg['AVATAR_EXTENSIONS'] as $ext => $ext_type ) {
						if( $ext_type == $type )
						{
							$extension = $ext;
							break;
						}
					}
					
					if( $extension === null )
					{
						$result = array("url_avatar", utf8_encode("N�o � permitido este tipo de imagem em seu <strong>avatar</strong>"));
						echo json_encode($result);
						exit;
					}
					
					$url_avatar = sprintf('%s/%s.%s', $ProfileCfg['PATH_AVATAR'], $account_id, $extension);
					if( $ProfileCfg['IMPORT_AVATAR'] )
					{
						$copydest = sprintf('../%s/%s.%s', $ProfileCfg['PATH_AVATAR'], $account_id, $extension);
						if( !@copy($url_avatar, $copydest) )
						{
							$result = array("url_avatar", utf8_encode("Houve um erro ao copiar o avatar para o destino v�lido."));
							echo json_encode($result);
							exit;
						}
						
						if( $url_avatar != $old_avatar )
						{
							if( substr_count($old_avatar,Config::$WebSite) )
							{
								$unlink = str_replace(sprintf("%s/", Config::$WebSite), "", $old_avatar);
								@unlink("../".$unlink);
							}
						}
					}
					
				}
			}
			else if( $upload_type == 2 )
			{
				if( isset($_FILES['upload_avatar']) && count($_FILES['upload_avatar']) )
				{
					@list($width,$height,$type) = getimagesize($_FILES['upload_avatar']['tmp_name']);
					
					if( $width > $ProfileCfg['MAX_AVATAR_WIDTH'] || $height > $ProfileCfg['MAX_AVATAR_HEIGHT'] )
					{
						$result = array("url_avatar", utf8_encode(sprintf("Seu <strong>avatar</strong> deve conter no m�ximo <strong>%dx%d pixels</strong>.", $ProfileCfg['MAX_AVATAR_WIDTH'], $ProfileCfg['MAX_AVATAR_HEIGHT'])));
						echo json_encode($result);
						exit;
					}
					
					$extension = null;
					foreach( $ProfileCfg['AVATAR_EXTENSIONS'] as $ext => $ext_type ) {
						if( $ext_type == $type )
						{
							$extension = $ext;
							break;
						}
					}
					
					if( $extension === null )
					{
						$result = array("url_avatar", utf8_encode("N�o � permitido este tipo de imagem em seu <strong>avatar</strong>"));
						echo json_encode($result);
						exit;
					}
					
					$copydest = sprintf('../%s/%s.%s', $ProfileCfg['PATH_AVATAR'], $account_id, $extension);
					
					if( !move_uploaded_file($_FILES['upload_avatar']['tmp_name'], $copydest) )
					{
						$result = array("url_avatar", utf8_encode("Erro ao fazer upload do seu avatar, reporte aos Desenvolvedores."));
						echo json_encode($result);
						exit;
					}
					
					$url_avatar = sprintf("%s/%s/%s.%s",Config::$WebSite,$ProfileCfg['PATH_AVATAR'],$account_id,$extension);
					
					if( $url_avatar != $old_avatar )
					{
						if( substr_count($old_avatar,Config::$WebSite) )
						{
							$unlink = str_replace(sprintf("%s/", Config::$WebSite), "", $old_avatar);
							@unlink("../".$unlink);
						}
					}
				}
			}	
		}
		
		if( !$Profile->Create($account_id, utf8_decode($nickname), utf8_decode($name), $sex, $birthdate, utf8_decode($country), utf8_decode($state), array('facebook' => $facebook, 'skype' => $skype, 'twitter' => $twitter, 'googleplus' => $googlep, 'instagram' => $instagram, 'linkedin' => $linkedin, 'youtube' => $youtube), $email, $url_avatar, $description) )
			$result = array("error", "Houve um erro ao atualizar seu perfil, reporte aos Desenvolvedores.");
		else {
			$Profile->RequestData($account_id);
			$result = array("success", "Perfil atualizado com sucesso!", utf8_encode($Profile->firstname), utf8_encode($Profile->nickname), $Profile->age, $Profile->birthdate, ($Profile->sex?"Feminino":"Masculino"), utf8_encode($Profile->avatar_url));
		}
	}
	// Return Results
	echo json_encode($result);
	exit;
?>