<?php
	if( !defined("MAIN_PAGE") )
		exit;
	
	if( isset($_GET['code']) && $_GET['code'] == 'logout' )
		$Auth->Logout();
	
	if( $Auth->CheckSession() )
	{
?>
<script>
	window.location = "?p=lista";
</script>
<?php
	}
	// Get HTML Header
	require_once('contents/includes/header.php');
?>
	
	<div class="login-logo"></div>
	<form id="form-login" class="login-content">
		<div class="row">
			<div class="col-xs-12">
				<div class="alert alert-success<?php if( !isset($_GET['code']) || $_GET['code'] != 'logout' ) { echo " no-display"; } ?>">
					<a href="#" class="close">&times;</a>
					<div><?php if( isset($_GET['code']) && $_GET['code'] == 'logout' ) { echo "<strong>Desconectado com sucesso!</strong>"; } ?></div>
				</div>
				
				<div class="alert alert-danger<?php if( !isset($_GET['code']) || $_GET['code'] != 'error' ) { echo " no-display"; } ?>">
					<a href="#" class="close">&times;</a>
					<div><?php if( isset($_GET['code']) && $_GET['code'] == 'error' ) { echo "<strong>Por favor, entre na sess�o!</strong>"; } ?></div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-12">
				<div class="form-group">
					<label for="username">Usu�rio</label>
					<input id="username" name="username" class="form-control" type="text" placeholder="Entre com seu Usu�rio" required>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-12">
				<div class="form-group">
					<label for="password">Senha</label>
					<input id="password" name="password" class="form-control" type="password" placeholder="Entre com sua Senha" required>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-12 text-center">
				<div class="form-group">
					<button type="submit" class="btn btn-default btn-md"><span class="glyphicon glyphicon-log-in"></span> Entrar</button>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-12 register-links text-center">
				<a href="<?php echo Config::$CPLinks['register']; ?>" target="_blank">Cadastro</a> <a href="<?php echo Config::$CPLinks['recovery']; ?>" target="_blank">Recuperar Senha</a>
			</div>
		</div>
<?php
	if( isset($_GET['continue']) && trim($_GET['continue']) ) {
?>
		<input type="hidden" name="continue" id="continue" value="<?php echo urldecode($_GET['continue']); ?>" />
<?php
	}
?>
	</form>
	
	<div class="login-footer text-center">
		<p>Sistema de Conquistas 3.0</p>
		<p>2014 - <?=date("Y")?> &copy; <a href="http://www.creativesd.com.br" target="_blank">Creative Services and Development</a></p>
		<p>Desenvolvido por <a href="mailto:sbk@creativesd.com.br">Romulo de Sousa Mangueira</a></p>
		<p>Todos os Direitos Reservado</p>
	</div>
  </body>
</html>